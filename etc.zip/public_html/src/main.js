// Bushra MVP - Main JavaScript File

// DOM Elements
document.addEventListener('DOMContentLoaded', function() {
  // Initialize components based on current page
  const currentPath = window.location.pathname;
  
  // Common components for all pages
  initializeNavigation();
  
  // Page-specific initializations
  if (currentPath.includes('index.html') || currentPath === '/' || currentPath === '') {
    initializeLandingPage();
  } else if (currentPath.includes('dashboard.html')) {
    initializeUserDashboard();
  } else if (currentPath.includes('advertiser-dashboard.html')) {
    initializeAdvertiserDashboard();
  } else if (currentPath.includes('advertiser-new-campaign.html')) {
    initializeNewCampaign();
  }
});

// Navigation functionality
function initializeNavigation() {
  // Mobile menu toggle
  const mobileMenuButton = document.querySelector('.mobile-menu-toggle');
  const navbarNav = document.querySelector('.navbar-nav');
  
  if (mobileMenuButton && navbarNav) {
    mobileMenuButton.addEventListener('click', function() {
      navbarNav.classList.toggle('show');
    });
  }
  
  // Language switcher
  const languageSwitcher = document.querySelector('.language-switcher');
  if (languageSwitcher) {
    languageSwitcher.addEventListener('click', function() {
      const html = document.querySelector('html');
      if (html.getAttribute('dir') === 'rtl') {
        html.setAttribute('dir', 'ltr');
        html.setAttribute('lang', 'en');
        languageSwitcher.textContent = 'العربية';
      } else {
        html.setAttribute('dir', 'rtl');
        html.setAttribute('lang', 'ar');
        languageSwitcher.textContent = 'English';
      }
    });
  }
}

// Landing page functionality
function initializeLandingPage() {
  // Waitlist form submission
  const waitlistForm = document.querySelector('.waitlist-form');
  if (waitlistForm) {
    waitlistForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const email = waitlistForm.querySelector('input[type="email"]').value;
      if (validateEmail(email)) {
        // Simulate form submission
        const submitButton = waitlistForm.querySelector('button[type="submit"]');
        const originalText = submitButton.textContent;
        submitButton.textContent = 'جاري التسجيل...';
        submitButton.disabled = true;
        
        // Simulate API call
        setTimeout(function() {
          waitlistForm.innerHTML = '<div class="alert alert-success">شكراً لتسجيلك! سنتواصل معك قريباً.</div>';
        }, 1500);
      } else {
        // Show validation error
        const emailInput = waitlistForm.querySelector('input[type="email"]');
        emailInput.classList.add('is-invalid');
        
        // Create error message if it doesn't exist
        let errorMessage = waitlistForm.querySelector('.error-message');
        if (!errorMessage) {
          errorMessage = document.createElement('div');
          errorMessage.className = 'error-message text-danger mt-2';
          errorMessage.textContent = 'يرجى إدخال بريد إلكتروني صحيح';
          emailInput.parentNode.appendChild(errorMessage);
        }
      }
    });
  }
  
  // Absher login button
  const absherButton = document.querySelector('.absher-button');
  if (absherButton) {
    absherButton.addEventListener('click', function() {
      // Simulate Absher OAuth redirect
      showModal('absher-login-modal');
    });
  }
}

// User dashboard functionality
function initializeUserDashboard() {
  // Ad interaction
  const adButtons = document.querySelectorAll('.ad-card .btn');
  adButtons.forEach(button => {
    button.addEventListener('click', function(e) {
      e.preventDefault();
      const adCard = this.closest('.ad-card');
      const adTitle = adCard.querySelector('.ad-card-title').textContent;
      const adReward = adCard.querySelector('.ad-card-reward').textContent;
      
      // Simulate ad viewing
      if (this.textContent.includes('مشاهدة')) {
        showAdModal(adTitle, adReward);
      } 
      // Simulate survey participation
      else if (this.textContent.includes('المشاركة')) {
        showSurveyModal(adTitle, adReward);
      }
    });
  });
  
  // Withdrawal button
  const withdrawButton = document.querySelector('.earnings-actions .btn');
  if (withdrawButton) {
    withdrawButton.addEventListener('click', function(e) {
      e.preventDefault();
      showWithdrawalModal();
    });
  }
}

// Advertiser dashboard functionality
function initializeAdvertiserDashboard() {
  // Campaign edit buttons
  const editButtons = document.querySelectorAll('.btn-primary.btn-sm');
  editButtons.forEach(button => {
    button.addEventListener('click', function(e) {
      e.preventDefault();
      const campaignCard = this.closest('.card');
      const campaignTitle = campaignCard.querySelector('h4').textContent;
      
      // Redirect to edit campaign page (simulated)
      window.location.href = 'advertiser-edit-campaign.html?campaign=' + encodeURIComponent(campaignTitle);
    });
  });
  
  // New campaign button
  const newCampaignButton = document.querySelector('.btn-secondary');
  if (newCampaignButton) {
    newCampaignButton.addEventListener('click', function(e) {
      e.preventDefault();
      window.location.href = 'advertiser-new-campaign.html';
    });
  }
}

// New campaign page functionality
function initializeNewCampaign() {
  // Campaign form submission
  const campaignForm = document.querySelector('.campaign-form');
  if (campaignForm) {
    campaignForm.addEventListener('submit', function(e) {
      e.preventDefault();
      
      // Validate form
      let isValid = true;
      const requiredFields = campaignForm.querySelectorAll('[required]');
      requiredFields.forEach(field => {
        if (!field.value.trim()) {
          field.classList.add('is-invalid');
          isValid = false;
        } else {
          field.classList.remove('is-invalid');
        }
      });
      
      if (isValid) {
        // Simulate form submission
        const submitButton = campaignForm.querySelector('button[type="submit"]');
        const originalText = submitButton.textContent;
        submitButton.textContent = 'جاري الإنشاء...';
        submitButton.disabled = true;
        
        // Simulate API call
        setTimeout(function() {
          window.location.href = 'advertiser-dashboard.html?success=true';
        }, 2000);
      }
    });
  }
}

// Simulated Absher integration
function simulateAbsherLogin() {
  // This would be replaced with actual Absher OAuth in production
  const absherModal = document.getElementById('absher-login-modal');
  const absherForm = absherModal.querySelector('form');
  
  absherForm.addEventListener('submit', function(e) {
    e.preventDefault();
    const nationalId = absherForm.querySelector('#national-id').value;
    const password = absherForm.querySelector('#password').value;
    
    if (nationalId && password) {
      // Simulate authentication
      const submitButton = absherForm.querySelector('button[type="submit"]');
      submitButton.textContent = 'جاري تسجيل الدخول...';
      submitButton.disabled = true;
      
      setTimeout(function() {
        // Redirect to dashboard after successful login
        window.location.href = 'dashboard.html';
      }, 2000);
    }
  });
}

// Modal functionality
function showModal(modalId) {
  const modal = document.getElementById(modalId);
  if (!modal) {
    // Create modal if it doesn't exist
    createModal(modalId);
  } else {
    modal.style.display = 'block';
  }
}

function hideModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.style.display = 'none';
  }
}

function createModal(modalId) {
  // Create different modals based on ID
  let modalContent = '';
  
  if (modalId === 'absher-login-modal') {
    modalContent = `
      <div id="absher-login-modal" class="modal">
        <div class="modal-content">
          <span class="close" onclick="hideModal('absher-login-modal')">&times;</span>
          <div class="text-center mb-4">
            <img src="images/absher-logo.png" alt="Absher Logo" style="height: 60px;">
            <h3 class="mt-3">تسجيل الدخول باستخدام أبشر</h3>
          </div>
          <form>
            <div class="form-group">
              <label for="national-id">رقم الهوية الوطنية</label>
              <input type="text" id="national-id" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="password">كلمة المرور</label>
              <input type="password" id="password" class="form-control" required>
            </div>
            <div class="text-center mt-4">
              <button type="submit" class="btn btn-primary">تسجيل الدخول</button>
            </div>
          </form>
          <div class="text-center mt-3">
            <p class="text-muted">هذا محاكاة لتسجيل الدخول بأبشر للأغراض التجريبية فقط</p>
          </div>
        </div>
      </div>
    `;
  } else if (modalId === 'ad-view-modal') {
    modalContent = `
      <div id="ad-view-modal" class="modal">
        <div class="modal-content">
          <span class="close" onclick="hideModal('ad-view-modal')">&times;</span>
          <h3 id="ad-title">عنوان الإعلان</h3>
          <div class="ad-content text-center my-4">
            <img src="images/ad-placeholder.png" alt="Ad Content" style="max-width: 100%;">
          </div>
          <div class="text-center">
            <p>يرجى مشاهدة الإعلان بالكامل للحصول على المكافأة</p>
            <div class="progress-bar-container mt-3 mb-3">
              <div id="ad-progress" class="progress-bar" style="width: 0%;"></div>
            </div>
            <button id="confirm-view-btn" class="btn btn-primary" disabled>تأكيد المشاهدة</button>
          </div>
        </div>
      </div>
    `;
  } else if (modalId === 'survey-modal') {
    modalContent = `
      <div id="survey-modal" class="modal">
        <div class="modal-content">
          <span class="close" onclick="hideModal('survey-modal')">&times;</span>
          <h3 id="survey-title">عنوان الاستبيان</h3>
          <div class="survey-content my-4">
            <form id="survey-form">
              <div class="form-group">
                <label>1. كم مرة تتسوق عبر الإنترنت شهرياً؟</label>
                <div class="mt-2">
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="q1" id="q1-1" value="1">
                    <label class="form-check-label" for="q1-1">لا أتسوق عبر الإنترنت</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="q1" id="q1-2" value="2">
                    <label class="form-check-label" for="q1-2">1-2 مرات</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="q1" id="q1-3" value="3">
                    <label class="form-check-label" for="q1-3">3-5 مرات</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="q1" id="q1-4" value="4">
                    <label class="form-check-label" for="q1-4">أكثر من 5 مرات</label>
                  </div>
                </div>
              </div>
              <div class="form-group mt-3">
                <label>2. ما هي منصات التسوق الإلكتروني التي تستخدمها؟</label>
                <div class="mt-2">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="q2" id="q2-1" value="noon">
                    <label class="form-check-label" for="q2-1">نون</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="q2" id="q2-2" value="amazon">
                    <label class="form-check-label" for="q2-2">أمازون</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="q2" id="q2-3" value="jarir">
                    <label class="form-check-label" for="q2-3">جرير</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="q2" id="q2-4" value="other">
                    <label class="form-check-label" for="q2-4">أخرى</label>
                  </div>
                </div>
              </div>
              <div class="text-center mt-4">
                <button type="submit" class="btn btn-primary">إرسال الاستبيان</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    `;
  } else if (modalId === 'withdrawal-modal') {
    modalContent = `
      <div id="withdrawal-modal" class="modal">
        <div class="modal-content">
          <span class="close" onclick="hideModal('withdrawal-modal')">&times;</span>
          <h3>سحب الرصيد</h3>
          <div class="my-4">
            <p>رصيدك الحالي: <strong>75.50 ر.س</strong></p>
            <form id="withdrawal-form">
              <div class="form-group">
                <label for="withdrawal-amount">المبلغ المراد سحبه</label>
                <input type="number" id="withdrawal-amount" class="form-control" min="50" max="75.50" value="50" required>
                <small class="text-muted">الحد الأدنى للسحب هو 50 ر.س</small>
              </div>
              <div class="form-group mt-3">
                <label for="bank-account">الحساب المصرفي</label>
                <select id="bank-account" class="form-control" required>
                  <option value="">اختر الحساب المصرفي</option>
                  <option value="alahli">البنك الأهلي السعودي</option>
                  <option value="alrajhi">مصرف الراجحي</option>
                  <option value="samba">سامبا</option>
                  <option value="riyadh">بنك الرياض</option>
                </select>
              </div>
              <div class="text-center mt-4">
                <button type="submit" class="btn btn-primary">تأكيد السحب</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    `;
  }
  
  // Append modal to body
  document.body.insertAdjacentHTML('beforeend', modalContent);
  
  // Initialize modal functionality
  const modal = document.getElementById(modalId);
  const closeBtn = modal.querySelector('.close');
  
  closeBtn.addEventListener('click', function() {
    hideModal(modalId);
  });
  
  // Close modal when clicking outside
  window.addEventListener('click', function(event) {
    if (event.target === modal) {
      hideModal(modalId);
    }
  });
  
  // Initialize specific modal functionality
  if (modalId === 'absher-login-modal') {
    simulateAbsherLogin();
  } else if (modalId === 'ad-view-modal') {
    simulateAdViewing();
  } else if (modalId === 'survey-modal') {
    initializeSurvey();
  } else if (modalId === 'withdrawal-modal') {
    initializeWithdrawal();
  }
  
  // Show the modal
  modal.style.display = 'block';
}

// Ad viewing simulation
function showAdModal(adTitle, adReward) {
  // Create modal if it doesn't exist
  if (!document.getElementById('ad-view-modal')) {
    createModal('ad-view-modal');
  }
  
  // Update modal content
  const modal = document.getElementById('ad-view-modal');
  modal.querySelector('#ad-title').textContent = adTitle;
  
  // Show modal
  modal.style.display = 'block';
  
  // Start ad progress
  simulateAdViewing();
}

function simulateAdViewing() {
  const progressBar = document.getElementById('ad-progress');
  const confirmButton = document.getElementById('confirm-view-btn');
  let progress = 0;
  
  // Reset progress
  progressBar.style.width = '0%';
  confirmButton.disabled = true;
  
  // Simulate ad progress
  const progressInterval = setInterval(function() {
    progress += 5;
    progressBar.style.width = progress + '%';
    
    if (progress >= 100) {
      clearInterval(progressInterval);
      confirmButton.disabled = false;
      
      // Add event listener to confirm button
      confirmButton.addEventListener('click', function() {
        hideModal('ad-view-modal');
        showRewardNotification();
      });
    }
  }, 500); // 10 seconds total for 100% progress
}

// Survey simulation
function showSurveyModal(surveyTitle, surveyReward) {
  // Create modal if it doesn't exist
  if (!document.getElementById('survey-modal')) {
    createModal('survey-modal');
  }
  
  // Update modal content
  const modal = document.getElementById('survey-modal');
  modal.querySelector('#survey-title').textContent = surveyTitle;
  
  // Show modal
  modal.style.display = 'block';
  
  // Initialize survey
  initializeSurvey(surveyReward);
}

function initializeSurvey(surveyReward) {
  const surveyForm = document.getElementById('survey-form');
  
  surveyForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Validate form
    let isValid = true;
    const radioGroups = surveyForm.querySelectorAll('input[type="radio"]');
    const radioGroupNames = new Set();
    
    radioGroups.forEach(radio => {
      radioGroupNames.add(radio.name);
    });
    
    radioGroupNames.forEach(name => {
      const checkedRadio = surveyForm.querySelector(`input[name="${name}"]:checked`);
      if (!checkedRadio) {
        isValid = false;
      }
    });
    
    if (isValid) {
      hideModal('survey-modal');
      showRewardNotification(surveyReward);
    } else {
      alert('يرجى الإجابة على جميع الأسئلة');
    }
  });
}

// Withdrawal functionality
function showWithdrawalModal() {
  // Create modal if it doesn't exist
  if (!document.getElementById('withdrawal-modal')) {
    createModal('withdrawal-modal');
  }
  
  // Show modal
  document.getElementById('withdrawal-modal').style.display = 'block';
  
  // Initialize withdrawal
  initializeWithdrawal();
}

function initializeWithdrawal() {
  const withdrawalForm = document.getElementById('withdrawal-form');
  
  withdrawalForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const amount = document.getElementById('withdrawal-amount').value;
    const bank = document.getElementById('bank-account').value;
    
    if (amount >= 50 && amount <= 75.50 && bank) {
      // Simulate withdrawal
      const submitButton = withdrawalForm.querySelector('button[type="submit"]');
      submitButton.textContent = 'جاري تنفيذ العملية...';
      submitButton.disabled = true;
      
      setTimeout(function() {
        hideModal('withdrawal-modal');
        alert(`تم تقديم طلب سحب بمبلغ ${amount} ر.س إلى حسابك المصرفي بنجاح. سيتم تنفيذ العملية خلال 1-3 أيام عمل.`);
        
        // Update balance display
        const newBalance = (75.50 - parseFloat(amount)).toFixed(2);
        document.querySelector('.earnings-amount').textContent = newBalance + ' ر.س';
      }, 2000);
    }
  });
}

// Utility functions
function validateEmail(email) {
  const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(String(email).toLowerCase());
}

function showRewardNotification(reward = '2.00 ر.س') {
  // Create notification element
  const notification = document.createElement('div');
  notification.className = 'reward-notification';
  notification.innerHTML = `
    <div class="reward-content">
      <i class="fas fa-check-circle"></i>
      <p>تم إضافة ${reward} إلى رصيدك!</p>
    </div>
  `;
  
  // Add to body
  document.body.appendChild(notification);
  
  // Show notification
  setTimeout(function() {
    notification.classList.add('show');
  }, 100);
  
  // Hide and remove after 3 seconds
  setTimeout(function() {
    notification.classList.remove('show');
    setTimeout(function() {
      document.body.removeChild(notification);
    }, 300);
  }, 3000);
  
  // Update earnings display if on dashboard
  const earningsAmount = document.querySelector('.earnings-amount');
  if (earningsAmount) {
    const currentAmount = parseFloat(earningsAmount.textContent.replace(' ر.س', ''));
    const rewardAmount = parseFloat(reward.replace(' ر.س', ''));
    const newAmount = (currentAmount + rewardAmount).toFixed(2);
    earningsAmount.textContent = newAmount + ' ر.س';
  }
}

// Add CSS for modals and notifications
const customStyles = `
  /* Modal Styles */
  .modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0,0,0,0.4);
  }
  
  .modal-content {
    background-color: #fff;
    margin: 10% auto;
    padding: 20px;
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-lg);
    width: 80%;
    max-width: 500px;
    position: relative;
  }
  
  .close {
    position: absolute;
    right: 20px;
    top: 10px;
    font-size: 28px;
    font-weight: bold;
    cursor: pointer;
  }
  
  [dir="rtl"] .close {
    right: auto;
    left: 20px;
  }
  
  /* Reward Notification */
  .reward-notification {
    position: fixed;
    top: 20px;
    right: 20px;
    background-color: var(--success);
    color: white;
    padding: 15px 20px;
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-md);
    z-index: 1001;
    transform: translateX(120%);
    transition: transform 0.3s ease;
  }
  
  [dir="rtl"] .reward-notification {
    right: auto;
    left: 20px;
    transform: translateX(-120%);
  }
  
  .reward-notification.show {
    transform: translateX(0);
  }
  
  .reward-content {
    display: flex;
    align-items: center;
  }
  
  .reward-content i {
    margin-right: 10px;
    font-size: 20px;
  }
  
  [dir="rtl"] .reward-content i {
    margin-right: 0;
    margin-left: 10px;
  }
  
  /* Form validation */
  .is-invalid {
    border-color: var(--danger) !important;
  }
  
  .error-message {
    font-size: 0.875rem;
    color: var(--danger);
  }
  
  /* Mobile menu */
  @media (max-width: 768px) {
    .navbar-nav {
      display: none;
      flex-direction: column;
      width: 100%;
      margin-top: 15px;
    }
    
    .navbar-nav.show {
      display: flex;
    }
    
    .nav-item {
      margin: 5px 0;
    }
    
    .mobile-menu-toggle {
      display: block;
    }
  }
`;

// Add styles to head
const styleElement = document.createElement('style');
styleElement.textContent = customStyles;
document.head.appendChild(styleElement);
