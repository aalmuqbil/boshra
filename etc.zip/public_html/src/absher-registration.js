// Absher registration functionality for Bushra website
// This script handles user registration through Absher integration

// Store references to DOM elements
const absherRegisterButton = document.getElementById('absher-register-button');
const registerForm = document.getElementById('register-form');
const registerError = document.getElementById('register-error');

// Initialize the Absher registration functionality
function initAbsherRegistration() {
  // Add event listener to Absher register button if it exists
  if (absherRegisterButton) {
    absherRegisterButton.addEventListener('click', handleAbsherRegistration);
  }
  
  // Add event listener to register form if it exists
  if (registerForm) {
    registerForm.addEventListener('submit', handleRegisterFormSubmit);
  }
}

// Handle Absher registration button click
function handleAbsherRegistration(event) {
  event.preventDefault();
  
  // Show loading state
  absherRegisterButton.disabled = true;
  absherRegisterButton.textContent = 'جاري التحقق...';
  
  // Simulate Absher authentication process
  setTimeout(() => {
    // In a real implementation, this would connect to the Absher API
    // For the MVP, we'll simulate a successful authentication
    const absherUserData = {
      id: 'user' + Math.floor(Math.random() * 1000),
      name: 'مستخدم أبشر',
      nationalId: '10xxxxxxxx',
      phone: '05xxxxxxxx',
      email: 'user@example.com',
      region: 'الرياض',
      age: 30,
      gender: 'ذكر'
    };
    
    // Show registration form with pre-filled data from Absher
    showRegistrationForm(absherUserData);
    
    // Reset button state
    absherRegisterButton.disabled = false;
    absherRegisterButton.textContent = 'سجل باستخدام أبشر';
  }, 2000);
}

// Show registration form with pre-filled data from Absher
function showRegistrationForm(userData) {
  const registrationFormContainer = document.getElementById('registration-form-container');
  if (!registrationFormContainer) return;
  
  // Show the form container
  registrationFormContainer.style.display = 'block';
  
  // Pre-fill form fields with Absher data
  const nameInput = document.getElementById('register-name');
  const emailInput = document.getElementById('register-email');
  const phoneInput = document.getElementById('register-phone');
  const regionInput = document.getElementById('register-region');
  
  if (nameInput) nameInput.value = userData.name;
  if (emailInput) emailInput.value = userData.email;
  if (phoneInput) phoneInput.value = userData.phone;
  if (regionInput) nameInput.value = userData.region;
  
  // Store Absher data in session storage for form submission
  sessionStorage.setItem('absherUserData', JSON.stringify(userData));
}

// Handle registration form submission
function handleRegisterFormSubmit(event) {
  event.preventDefault();
  
  // Get form data
  const username = document.getElementById('register-username').value.trim();
  const password = document.getElementById('register-password').value;
  const confirmPassword = document.getElementById('register-confirm-password').value;
  
  // Basic validation
  if (!username || !password || !confirmPassword) {
    showRegisterError('الرجاء إدخال جميع البيانات المطلوبة');
    return;
  }
  
  if (password !== confirmPassword) {
    showRegisterError('كلمة المرور وتأكيد كلمة المرور غير متطابقين');
    return;
  }
  
  // Get Absher data from session storage
  const absherUserData = JSON.parse(sessionStorage.getItem('absherUserData') || '{}');
  
  // Create new user object
  const newUser = {
    id: absherUserData.id || 'user' + Math.floor(Math.random() * 1000),
    username: username,
    password: password,
    name: absherUserData.name || document.getElementById('register-name').value.trim(),
    email: absherUserData.email || document.getElementById('register-email').value.trim(),
    phone: absherUserData.phone || document.getElementById('register-phone').value.trim(),
    region: absherUserData.region || document.getElementById('register-region').value.trim(),
    age: absherUserData.age || 30,
    gender: absherUserData.gender || 'ذكر',
    interests: [],
    education: 'غير محدد',
    wallet: {
      balance: 50.00, // Registration bonus
      total_earned: 50.00,
      pending: 0.00
    },
    preferences: {
      max_daily_ads: 5,
      categories: []
    },
    stats: {
      ads_viewed: 0,
      surveys_completed: 0,
      avg_engagement: 0
    }
  };
  
  // In a real implementation, this would send the data to the server
  // For the MVP, we'll simulate a successful registration
  setTimeout(() => {
    // Store the new user in localStorage for demo purposes
    const existingUsers = JSON.parse(localStorage.getItem('bushraUsers') || '[]');
    existingUsers.push(newUser);
    localStorage.setItem('bushraUsers', JSON.stringify(existingUsers));
    
    // Clear Absher data from session storage
    sessionStorage.removeItem('absherUserData');
    
    // Show success message
    showRegisterSuccess();
    
    // Automatically log in the new user after 2 seconds
    setTimeout(() => {
      // Create login info
      const loginInfo = {
        id: newUser.id,
        username: newUser.username,
        name: newUser.name,
        type: 'user',
        loggedIn: true,
        loginTime: new Date().toISOString()
      };
      
      // Store login information in localStorage
      localStorage.setItem('bushraLoginInfo', JSON.stringify(loginInfo));
      
      // Redirect to ads-surveys page
      window.location.href = 'ads-surveys.html';
    }, 2000);
  }, 1500);
}

// Show registration error message
function showRegisterError(message) {
  if (registerError) {
    registerError.textContent = message;
    registerError.style.display = 'block';
    
    // Hide error after 3 seconds
    setTimeout(() => {
      registerError.style.display = 'none';
    }, 3000);
  }
}

// Show registration success message
function showRegisterSuccess() {
  const registerFormContainer = document.getElementById('register-form-container');
  const registerSuccessContainer = document.getElementById('register-success-container');
  
  if (registerFormContainer) registerFormContainer.style.display = 'none';
  if (registerSuccessContainer) {
    registerSuccessContainer.style.display = 'block';
    registerSuccessContainer.innerHTML = `
      <div class="success-message">
        <i class="fas fa-check-circle"></i>
        <h3>تم التسجيل بنجاح!</h3>
        <p>تم إنشاء حسابك بنجاح وإضافة 50 ريال كمكافأة تسجيل.</p>
        <p>جاري تسجيل الدخول تلقائياً...</p>
      </div>
    `;
  }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', initAbsherRegistration);

// Export functions for use in other scripts
window.bushraAbsher = {
  initAbsherRegistration,
  handleAbsherRegistration
};
