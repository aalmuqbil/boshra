// Audience targeting module for Bushra
// This script provides audience targeting functionality for campaign creation

window.bushra = window.bushra || {};

window.bushra.targeting = (function() {
  // Default targeting criteria
  const defaultTargeting = {
    age_min: 18,
    age_max: 65,
    gender: [],
    cities: [],
    interests: []
  };
  
  // Current targeting criteria
  let currentTargeting = {...defaultTargeting};
  
  // Set targeting criteria
  function setTargeting(targeting) {
    currentTargeting = {
      ...defaultTargeting,
      ...targeting
    };
    
    // Update UI if available
    updateTargetingUI();
    
    // Update audience estimate
    updateAudienceEstimate();
    
    return currentTargeting;
  }
  
  // Get current targeting criteria
  function getTargeting() {
    return {...currentTargeting};
  }
  
  // Reset targeting to defaults
  function resetTargeting() {
    currentTargeting = {...defaultTargeting};
    
    // Update UI if available
    updateTargetingUI();
    
    // Update audience estimate
    updateAudienceEstimate();
    
    return currentTargeting;
  }
  
  // Update age range
  function setAgeRange(minAge, maxAge) {
    currentTargeting.age_min = minAge;
    currentTargeting.age_max = maxAge;
    
    // Update UI if available
    updateAgeRangeUI();
    
    // Update audience estimate
    updateAudienceEstimate();
    
    return currentTargeting;
  }
  
  // Update gender targeting
  function setGenderTargeting(genders) {
    currentTargeting.gender = Array.isArray(genders) ? genders : [genders];
    
    // Update UI if available
    updateGenderUI();
    
    // Update audience estimate
    updateAudienceEstimate();
    
    return currentTargeting;
  }
  
  // Update city targeting
  function setCityTargeting(cities) {
    currentTargeting.cities = Array.isArray(cities) ? cities : [cities];
    
    // Update UI if available
    updateCityUI();
    
    // Update audience estimate
    updateAudienceEstimate();
    
    return currentTargeting;
  }
  
  // Update interest targeting
  function setInterestTargeting(interests) {
    currentTargeting.interests = Array.isArray(interests) ? interests : [interests];
    
    // Update UI if available
    updateInterestUI();
    
    // Update audience estimate
    updateAudienceEstimate();
    
    return currentTargeting;
  }
  
  // Get audience size estimate
  function getAudienceEstimate() {
    if (!window.bushra.data) {
      return 0;
    }
    
    return window.bushra.data.getAudienceSizeEstimate(currentTargeting);
  }
  
  // Update UI elements based on targeting criteria
  function updateTargetingUI() {
    updateAgeRangeUI();
    updateGenderUI();
    updateCityUI();
    updateInterestUI();
  }
  
  // Update age range UI
  function updateAgeRangeUI() {
    const minAgeInput = document.getElementById('age-min');
    const maxAgeInput = document.getElementById('age-max');
    const ageRangeText = document.getElementById('age-range-text');
    
    if (minAgeInput) {
      minAgeInput.value = currentTargeting.age_min;
    }
    
    if (maxAgeInput) {
      maxAgeInput.value = currentTargeting.age_max;
    }
    
    if (ageRangeText) {
      ageRangeText.textContent = `${currentTargeting.age_min} - ${currentTargeting.age_max}`;
    }
  }
  
  // Update gender UI
  function updateGenderUI() {
    const maleCheckbox = document.getElementById('gender-male');
    const femaleCheckbox = document.getElementById('gender-female');
    const genderText = document.getElementById('gender-text');
    
    if (maleCheckbox) {
      maleCheckbox.checked = currentTargeting.gender.includes('Male');
    }
    
    if (femaleCheckbox) {
      femaleCheckbox.checked = currentTargeting.gender.includes('Female');
    }
    
    if (genderText) {
      if (currentTargeting.gender.length === 0) {
        genderText.textContent = document.documentElement.lang === 'ar' ? 'الجميع' : 'All';
      } else if (currentTargeting.gender.length === 2) {
        genderText.textContent = document.documentElement.lang === 'ar' ? 'ذكور وإناث' : 'Male and Female';
      } else if (currentTargeting.gender.includes('Male')) {
        genderText.textContent = document.documentElement.lang === 'ar' ? 'ذكور فقط' : 'Male only';
      } else {
        genderText.textContent = document.documentElement.lang === 'ar' ? 'إناث فقط' : 'Female only';
      }
    }
  }
  
  // Update city UI
  function updateCityUI() {
    const citySelect = document.getElementById('city-select');
    const cityText = document.getElementById('city-text');
    
    if (citySelect) {
      // Update selected options
      Array.from(citySelect.options).forEach(option => {
        option.selected = currentTargeting.cities.includes(option.value);
      });
    }
    
    if (cityText) {
      if (currentTargeting.cities.length === 0) {
        cityText.textContent = document.documentElement.lang === 'ar' ? 'جميع المدن' : 'All cities';
      } else if (currentTargeting.cities.length === 1) {
        cityText.textContent = currentTargeting.cities[0];
      } else {
        cityText.textContent = document.documentElement.lang === 'ar' 
          ? `${currentTargeting.cities.length} مدن` 
          : `${currentTargeting.cities.length} cities`;
      }
    }
  }
  
  // Update interest UI
  function updateInterestUI() {
    const interestSelect = document.getElementById('interest-select');
    const interestText = document.getElementById('interest-text');
    
    if (interestSelect) {
      // Update selected options
      Array.from(interestSelect.options).forEach(option => {
        option.selected = currentTargeting.interests.includes(option.value);
      });
    }
    
    if (interestText) {
      if (currentTargeting.interests.length === 0) {
        interestText.textContent = document.documentElement.lang === 'ar' ? 'جميع الاهتمامات' : 'All interests';
      } else if (currentTargeting.interests.length === 1) {
        interestText.textContent = currentTargeting.interests[0];
      } else {
        interestText.textContent = document.documentElement.lang === 'ar' 
          ? `${currentTargeting.interests.length} اهتمامات` 
          : `${currentTargeting.interests.length} interests`;
      }
    }
  }
  
  // Update audience estimate UI
  function updateAudienceEstimate() {
    const audienceEstimateElement = document.getElementById('audience-estimate');
    
    if (audienceEstimateElement) {
      const estimate = getAudienceEstimate();
      audienceEstimateElement.textContent = estimate.toLocaleString();
      
      // Update reach percentage
      const reachPercentElement = document.getElementById('reach-percentage');
      if (reachPercentElement && window.bushra.data) {
        const totalUsers = window.bushra.data.getUserData().length;
        const percentage = totalUsers > 0 ? (estimate / totalUsers) * 100 : 0;
        reachPercentElement.textContent = percentage.toFixed(1) + '%';
      }
    }
  }
  
  // Initialize targeting UI elements
  function initializeTargetingUI() {
    // Age range inputs
    const minAgeInput = document.getElementById('age-min');
    const maxAgeInput = document.getElementById('age-max');
    
    if (minAgeInput) {
      minAgeInput.addEventListener('change', function() {
        const minAge = parseInt(this.value, 10);
        const maxAge = parseInt(maxAgeInput.value, 10);
        
        if (minAge > maxAge) {
          maxAgeInput.value = minAge;
        }
        
        setAgeRange(minAge, parseInt(maxAgeInput.value, 10));
      });
    }
    
    if (maxAgeInput) {
      maxAgeInput.addEventListener('change', function() {
        const minAge = parseInt(minAgeInput.value, 10);
        const maxAge = parseInt(this.value, 10);
        
        if (maxAge < minAge) {
          minAgeInput.value = maxAge;
        }
        
        setAgeRange(parseInt(minAgeInput.value, 10), maxAge);
      });
    }
    
    // Gender checkboxes
    const maleCheckbox = document.getElementById('gender-male');
    const femaleCheckbox = document.getElementById('gender-female');
    
    if (maleCheckbox) {
      maleCheckbox.addEventListener('change', function() {
        const genders = [];
        
        if (maleCheckbox.checked) {
          genders.push('Male');
        }
        
        if (femaleCheckbox && femaleCheckbox.checked) {
          genders.push('Female');
        }
        
        setGenderTargeting(genders);
      });
    }
    
    if (femaleCheckbox) {
      femaleCheckbox.addEventListener('change', function() {
        const genders = [];
        
        if (maleCheckbox && maleCheckbox.checked) {
          genders.push('Male');
        }
        
        if (femaleCheckbox.checked) {
          genders.push('Female');
        }
        
        setGenderTargeting(genders);
      });
    }
    
    // City select
    const citySelect = document.getElementById('city-select');
    
    if (citySelect) {
      citySelect.addEventListener('change', function() {
        const selectedCities = Array.from(this.selectedOptions).map(option => option.value);
        setCityTargeting(selectedCities);
      });
      
      // Populate city options if empty
      if (citySelect.options.length === 0 && window.bushra.data) {
        const stats = window.bushra.data.getTargetingStats();
        
        if (stats && stats.city_distribution) {
          const cities = Object.keys(stats.city_distribution);
          
          cities.forEach(city => {
            const option = document.createElement('option');
            option.value = city;
            option.textContent = city;
            citySelect.appendChild(option);
          });
        }
      }
    }
    
    // Interest select
    const interestSelect = document.getElementById('interest-select');
    
    if (interestSelect) {
      interestSelect.addEventListener('change', function() {
        const selectedInterests = Array.from(this.selectedOptions).map(option => option.value);
        setInterestTargeting(selectedInterests);
      });
      
      // Populate interest options if empty
      if (interestSelect.options.length === 0 && window.bushra.data) {
        const stats = window.bushra.data.getTargetingStats();
        
        if (stats && stats.interest_distribution) {
          const interests = Object.keys(stats.interest_distribution);
          
          interests.forEach(interest => {
            const option = document.createElement('option');
            option.value = interest;
            option.textContent = interest;
            interestSelect.appendChild(option);
          });
        }
      }
    }
    
    // Reset button
    const resetButton = document.getElementById('reset-targeting');
    
    if (resetButton) {
      resetButton.addEventListener('click', function() {
        resetTargeting();
      });
    }
    
    // Initialize with default values
    updateTargetingUI();
    
    // Update audience estimate when data is loaded
    document.addEventListener('bushra:data:loaded', function() {
      updateAudienceEstimate();
    });
  }
  
  // Initialize the targeting module
  function initialize() {
    document.addEventListener('DOMContentLoaded', function() {
      initializeTargetingUI();
    });
  }
  
  // Public API
  return {
    initialize,
    setTargeting,
    getTargeting,
    resetTargeting,
    setAgeRange,
    setGenderTargeting,
    setCityTargeting,
    setInterestTargeting,
    getAudienceEstimate,
    updateAudienceEstimate
  };
})();

// Initialize targeting when DOM is loaded
window.bushra.targeting.initialize();
