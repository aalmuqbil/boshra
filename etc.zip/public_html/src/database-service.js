// Database API service for Bushra website
// This file provides methods to interact with the database

// Import the database structure
const DATABASE = require('./database.js');

// Database service object
const DatabaseService = {
  // User-related methods
  users: {
    // Get all users
    getAll: function() {
      return DATABASE.users;
    },
    
    // Get user by ID
    getById: function(userId) {
      return DATABASE.users.find(user => user.id === userId);
    },
    
    // Get user by National ID (for authentication)
    getByNationalId: function(nationalId) {
      return DATABASE.users.find(user => user.nationalId === nationalId);
    },
    
    // Create new user
    create: function(userData) {
      // Generate a new ID
      const newId = `u${1000 + DATABASE.users.length + 1}`;
      
      // Create user object with defaults
      const newUser = {
        id: newId,
        createdAt: new Date().toISOString(),
        lastLogin: new Date().toISOString(),
        wallet: {
          balance: 0,
          currency: "SAR",
          transactions: []
        },
        viewedAds: [],
        completedSurveys: [],
        preferences: {
          maxDailyAds: 5,
          language: "ar",
          notificationEnabled: true,
          adCategories: []
        },
        ...userData
      };
      
      // Add to database
      DATABASE.users.push(newUser);
      
      return newUser;
    },
    
    // Update user
    update: function(userId, updates) {
      const userIndex = DATABASE.users.findIndex(user => user.id === userId);
      
      if (userIndex === -1) {
        return null;
      }
      
      // Apply updates
      DATABASE.users[userIndex] = {
        ...DATABASE.users[userIndex],
        ...updates
      };
      
      return DATABASE.users[userIndex];
    },
    
    // Update user preferences
    updatePreferences: function(userId, preferences) {
      const user = this.getById(userId);
      
      if (!user) {
        return null;
      }
      
      user.preferences = {
        ...user.preferences,
        ...preferences
      };
      
      return user;
    },
    
    // Add viewed ad
    addViewedAd: function(userId, adId) {
      const user = this.getById(userId);
      
      if (!user) {
        return null;
      }
      
      if (!user.viewedAds.includes(adId)) {
        user.viewedAds.push(adId);
      }
      
      return user;
    },
    
    // Add completed survey
    addCompletedSurvey: function(userId, surveyId) {
      const user = this.getById(userId);
      
      if (!user) {
        return null;
      }
      
      if (!user.completedSurveys.includes(surveyId)) {
        user.completedSurveys.push(surveyId);
      }
      
      return user;
    }
  },
  
  // Advertiser-related methods
  advertisers: {
    // Get all advertisers
    getAll: function() {
      return DATABASE.advertisers;
    },
    
    // Get advertiser by ID
    getById: function(advertiserId) {
      return DATABASE.advertisers.find(advertiser => advertiser.id === advertiserId);
    },
    
    // Get advertiser by industry
    getByIndustry: function(industry) {
      return DATABASE.advertisers.filter(advertiser => advertiser.industry === industry);
    },
    
    // Create new advertiser
    create: function(advertiserData) {
      // Generate a new ID
      const newId = `adv${1000 + DATABASE.advertisers.length + 1}`;
      
      // Create advertiser object with defaults
      const newAdvertiser = {
        id: newId,
        createdAt: new Date().toISOString(),
        campaigns: [],
        ...advertiserData
      };
      
      // Add to database
      DATABASE.advertisers.push(newAdvertiser);
      
      return newAdvertiser;
    },
    
    // Update advertiser
    update: function(advertiserId, updates) {
      const advertiserIndex = DATABASE.advertisers.findIndex(advertiser => advertiser.id === advertiserId);
      
      if (advertiserIndex === -1) {
        return null;
      }
      
      // Apply updates
      DATABASE.advertisers[advertiserIndex] = {
        ...DATABASE.advertisers[advertiserIndex],
        ...updates
      };
      
      return DATABASE.advertisers[advertiserIndex];
    }
  },
  
  // Campaign-related methods
  campaigns: {
    // Get all campaigns
    getAll: function() {
      return DATABASE.campaigns;
    },
    
    // Get campaign by ID
    getById: function(campaignId) {
      return DATABASE.campaigns.find(campaign => campaign.id === campaignId);
    },
    
    // Get campaigns by advertiser
    getByAdvertiser: function(advertiserId) {
      return DATABASE.campaigns.filter(campaign => campaign.advertiserId === advertiserId);
    },
    
    // Get campaigns by type
    getByType: function(type) {
      return DATABASE.campaigns.filter(campaign => campaign.type === type);
    },
    
    // Get campaigns by status
    getByStatus: function(status) {
      return DATABASE.campaigns.filter(campaign => campaign.status === status);
    },
    
    // Get active campaigns
    getActive: function() {
      const now = new Date().toISOString();
      return DATABASE.campaigns.filter(campaign => 
        campaign.status === "active" && 
        campaign.startDate <= now && 
        campaign.endDate >= now
      );
    },
    
    // Create new campaign
    create: function(campaignData) {
      // Generate a new ID
      const newId = `c${1000 + DATABASE.campaigns.length + 1}`;
      
      // Create campaign object with defaults
      const newCampaign = {
        id: newId,
        status: "pending",
        impressions: 0,
        interactions: 0,
        spent: 0,
        createdAt: new Date().toISOString(),
        ...campaignData
      };
      
      // Add to database
      DATABASE.campaigns.push(newCampaign);
      
      // Add to advertiser's campaigns
      const advertiser = this.advertisers.getById(newCampaign.advertiserId);
      if (advertiser) {
        advertiser.campaigns.push(newId);
      }
      
      return newCampaign;
    },
    
    // Update campaign
    update: function(campaignId, updates) {
      const campaignIndex = DATABASE.campaigns.findIndex(campaign => campaign.id === campaignId);
      
      if (campaignIndex === -1) {
        return null;
      }
      
      // Apply updates
      DATABASE.campaigns[campaignIndex] = {
        ...DATABASE.campaigns[campaignIndex],
        ...updates
      };
      
      return DATABASE.campaigns[campaignIndex];
    },
    
    // Match campaigns to user
    matchToUser: function(userId) {
      const user = this.users.getById(userId);
      
      if (!user) {
        return [];
      }
      
      // Get active campaigns
      const activeCampaigns = this.getActive();
      
      // Filter campaigns based on targeting criteria
      return activeCampaigns.filter(campaign => {
        const targeting = campaign.targeting;
        
        // Check age
        if (user.age < targeting.ageRange[0] || user.age > targeting.ageRange[1]) {
          return false;
        }
        
        // Check gender
        if (!targeting.gender.includes(user.gender)) {
          return false;
        }
        
        // Check city
        if (!targeting.cities.includes(user.city)) {
          return false;
        }
        
        // Check interests (at least one match)
        const hasMatchingInterest = user.interests.some(interest => 
          targeting.interests.includes(interest)
        );
        
        if (!hasMatchingInterest) {
          return false;
        }
        
        // Check if user already viewed this ad
        if (campaign.type === "ad" && user.viewedAds.includes(campaign.id)) {
          return false;
        }
        
        // Check if user already completed this survey
        if (campaign.type === "survey" && user.completedSurveys.includes(campaign.id)) {
          return false;
        }
        
        return true;
      });
    }
  },
  
  // Transaction-related methods
  transactions: {
    // Get all transactions
    getAll: function() {
      return DATABASE.transactions;
    },
    
    // Get transaction by ID
    getById: function(transactionId) {
      return DATABASE.transactions.find(transaction => transaction.id === transactionId);
    },
    
    // Get transactions by user
    getByUser: function(userId) {
      return DATABASE.transactions.filter(transaction => transaction.userId === userId);
    },
    
    // Create new transaction
    create: function(transactionData) {
      // Generate a new ID
      const newId = `t${1000 + DATABASE.transactions.length + 1}`;
      
      // Create transaction object with defaults
      const newTransaction = {
        id: newId,
        status: "completed",
        timestamp: new Date().toISOString(),
        ...transactionData
      };
      
      // Add to database
      DATABASE.transactions.push(newTransaction);
      
      // Update user wallet
      const user = this.users.getById(newTransaction.userId);
      
      if (user) {
        // Add transaction to user's transactions
        user.wallet.transactions.push(newId);
        
        // Update balance
        if (newTransaction.type === "earning") {
          user.wallet.balance += newTransaction.amount;
        } else if (newTransaction.type === "withdrawal") {
          user.wallet.balance -= newTransaction.amount;
        }
      }
      
      return newTransaction;
    },
    
    // Create earning transaction for ad view
    createAdViewEarning: function(userId, campaignId) {
      const user = this.users.getById(userId);
      const campaign = this.campaigns.getById(campaignId);
      
      if (!user || !campaign) {
        return null;
      }
      
      // Create transaction
      const transaction = this.create({
        userId: userId,
        type: "earning",
        amount: campaign.reward,
        source: {
          type: "ad_view",
          campaignId: campaignId
        }
      });
      
      // Update campaign stats
      campaign.impressions += 1;
      campaign.interactions += 1;
      campaign.spent += campaign.reward;
      
      // Add to user's viewed ads
      this.users.addViewedAd(userId, campaignId);
      
      return transaction;
    },
    
    // Create earning transaction for survey completion
    createSurveyEarning: function(userId, campaignId) {
      const user = this.users.getById(userId);
      const campaign = this.campaigns.getById(campaignId);
      
      if (!user || !campaign) {
        return null;
      }
      
      // Create transaction
      const transaction = this.create({
        userId: userId,
        type: "earning",
        amount: campaign.reward,
        source: {
          type: "survey_completion",
          campaignId: campaignId
        }
      });
      
      // Update campaign stats
      campaign.impressions += 1;
      campaign.interactions += 1;
      campaign.spent += campaign.reward;
      
      // Add to user's completed surveys
      this.users.addCompletedSurvey(userId, campaignId);
      
      return transaction;
    },
    
    // Create withdrawal transaction
    createWithdrawal: function(userId, amount, destination) {
      const user = this.users.getById(userId);
      
      if (!user) {
        return null;
      }
      
      // Check if user has enough balance
      if (user.wallet.balance < amount) {
        return {
          error: "Insufficient balance",
          requiredAmount: amount,
          currentBalance: user.wallet.balance
        };
      }
      
      // Check minimum withdrawal amount
      if (amount < DATABASE.settings.minimumWithdrawal) {
        return {
          error: "Below minimum withdrawal amount",
          minimumAmount: DATABASE.settings.minimumWithdrawal,
          requestedAmount: amount
        };
      }
      
      // Create transaction
      return this.create({
        userId: userId,
        type: "withdrawal",
        amount: amount,
        destination: destination
      });
    }
  },
  
  // Settings-related methods
  settings: {
    // Get all settings
    getAll: function() {
      return DATABASE.settings;
    },
    
    // Get reward rates
    getRewardRates: function() {
      return DATABASE.settings.rewardRates;
    },
    
    // Get reward rate for specific industry and type
    getRewardRate: function(industry, type) {
      return DATABASE.settings.rewardRates[industry][type];
    },
    
    // Get languages
    getLanguages: function() {
      return DATABASE.settings.languages;
    },
    
    // Get default language
    getDefaultLanguage: function() {
      return DATABASE.settings.defaultLanguage;
    },
    
    // Get minimum withdrawal amount
    getMinimumWithdrawal: function() {
      return DATABASE.settings.minimumWithdrawal;
    },
    
    // Get maximum daily ads
    getMaxDailyAds: function() {
      return DATABASE.settings.maxDailyAds;
    },
    
    // Get approval process settings
    getApprovalProcess: function() {
      return DATABASE.settings.approvalProcess;
    }
  }
};

// Add cross-references for easier access
DatabaseService.users.advertisers = DatabaseService.advertisers;
DatabaseService.users.campaigns = DatabaseService.campaigns;
DatabaseService.users.transactions = DatabaseService.transactions;

DatabaseService.advertisers.users = DatabaseService.users;
DatabaseService.advertisers.campaigns = DatabaseService.campaigns;
DatabaseService.advertisers.transactions = DatabaseService.transactions;

DatabaseService.campaigns.users = DatabaseService.users;
DatabaseService.campaigns.advertisers = DatabaseService.advertisers;
DatabaseService.campaigns.transactions = DatabaseService.transactions;

DatabaseService.transactions.users = DatabaseService.users;
DatabaseService.transactions.advertisers = DatabaseService.advertisers;
DatabaseService.transactions.campaigns = DatabaseService.campaigns;

// Export the database service
if (typeof module !== 'undefined' && module.exports) {
  module.exports = DatabaseService;
}
