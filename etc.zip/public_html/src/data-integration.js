// This script integrates the processed Excel data into the website
// It loads the JSON data files and provides functions to access the data

// Initialize the Bushra data namespace
window.bushra = window.bushra || {};

// Data integration module
window.bushra.data = (function() {
  // Store loaded data
  let userData = null;
  let targetingStats = null;
  let campaigns = null;
  let sampleMatches = null;
  
  // Load all data files
  async function loadAllData() {
    try {
      const userResponse = await fetch('/data/users.json');
      userData = await userResponse.json();
      
      const statsResponse = await fetch('/data/targeting_stats.json');
      targetingStats = await statsResponse.json();
      
      const campaignsResponse = await fetch('/data/campaigns.json');
      campaigns = await campaignsResponse.json();
      
      const matchesResponse = await fetch('/data/sample_matches.json');
      sampleMatches = await matchesResponse.json();
      
      console.log('All data loaded successfully');
      return true;
    } catch (error) {
      console.error('Error loading data:', error);
      return false;
    }
  }
  
  // Get user data
  function getUserData() {
    return userData;
  }
  
  // Get targeting statistics
  function getTargetingStats() {
    return targetingStats;
  }
  
  // Get campaigns
  function getCampaigns() {
    return campaigns;
  }
  
  // Get sample matches
  function getSampleMatches() {
    return sampleMatches;
  }
  
  // Get campaigns by industry
  function getCampaignsByIndustry(industry) {
    if (!campaigns) return [];
    return campaigns.filter(campaign => campaign.industry === industry);
  }
  
  // Get campaigns by type
  function getCampaignsByType(type) {
    if (!campaigns) return [];
    return campaigns.filter(campaign => campaign.type === type);
  }
  
  // Get user by ID
  function getUserById(userId) {
    if (!userData) return null;
    return userData.find(user => user.id === userId);
  }
  
  // Match campaigns to user
  function matchCampaignsToUser(userId) {
    const user = getUserById(userId);
    if (!user || !campaigns) return [];
    
    return campaigns.filter(campaign => {
      const targeting = campaign.targeting;
      
      // Check age
      if (user.age < targeting.age_min || user.age > targeting.age_max) {
        return false;
      }
      
      // Check gender
      if (!targeting.gender.includes(user.gender)) {
        return false;
      }
      
      // Check city
      if (!targeting.cities.includes(user.city)) {
        return false;
      }
      
      // Check interests (at least one match)
      const userInterests = user.interests.map(i => i.toLowerCase());
      const campaignInterests = targeting.interests.map(i => i.toLowerCase());
      
      return userInterests.some(interest => campaignInterests.includes(interest));
    });
  }
  
  // Get audience size estimate for targeting criteria
  function getAudienceSizeEstimate(targeting) {
    if (!userData) return 0;
    
    const matchingUsers = userData.filter(user => {
      // Check age
      if (user.age < targeting.age_min || user.age > targeting.age_max) {
        return false;
      }
      
      // Check gender
      if (targeting.gender.length > 0 && !targeting.gender.includes(user.gender)) {
        return false;
      }
      
      // Check cities
      if (targeting.cities.length > 0 && !targeting.cities.includes(user.city)) {
        return false;
      }
      
      // Check interests
      if (targeting.interests.length > 0) {
        const userInterests = user.interests.map(i => i.toLowerCase());
        const targetInterests = targeting.interests.map(i => i.toLowerCase());
        
        if (!userInterests.some(interest => targetInterests.includes(interest))) {
          return false;
        }
      }
      
      return true;
    });
    
    return matchingUsers.length;
  }
  
  // Initialize the data module
  async function initialize() {
    const loaded = await loadAllData();
    if (loaded) {
      // Dispatch event when data is loaded
      const event = new CustomEvent('bushra:data:loaded');
      document.dispatchEvent(event);
    }
    return loaded;
  }
  
  // Public API
  return {
    initialize,
    getUserData,
    getTargetingStats,
    getCampaigns,
    getSampleMatches,
    getCampaignsByIndustry,
    getCampaignsByType,
    getUserById,
    matchCampaignsToUser,
    getAudienceSizeEstimate
  };
})();

// Initialize data when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
  window.bushra.data.initialize();
});
