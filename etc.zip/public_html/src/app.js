document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const mainNav = document.querySelector('.main-nav');
    
    if (mobileMenuToggle && mainNav) {
        mobileMenuToggle.addEventListener('click', function() {
            mainNav.classList.toggle('active');
            document.body.classList.toggle('menu-open');
        });
    }
    
    // Initialize language preference
    initializeLanguage();
    
    // Initialize database connection
    if (typeof initDatabase === 'function') {
        initDatabase();
    }
    
    // Initialize page-specific functionality
    initPageSpecificFunctions();
});

function initPageSpecificFunctions() {
    const currentPage = window.location.pathname.split('/').pop();
    
    switch(currentPage) {
        case 'index.html':
        case '':
            initHomePage();
            break;
        case 'dashboard.html':
            initDashboard();
            break;
        case 'ads-surveys.html':
            initAdsSurveys();
            break;
        case 'merchant-campaign.html':
            initMerchantCampaign();
            break;
        case 'advertiser-dashboard.html':
            initAdvertiserDashboard();
            break;
        case 'approval-dashboard.html':
            initApprovalDashboard();
            break;
    }
}

function initHomePage() {
    // Add any home page specific initialization
    console.log('Home page initialized');
    
    // Example: Animate hero section
    const heroTitle = document.querySelector('.hero-title');
    const heroSubtitle = document.querySelector('.hero-subtitle');
    
    if (heroTitle && heroSubtitle) {
        heroTitle.style.opacity = '0';
        heroSubtitle.style.opacity = '0';
        
        setTimeout(() => {
            heroTitle.style.transition = 'opacity 0.8s ease-in-out';
            heroTitle.style.opacity = '1';
            
            setTimeout(() => {
                heroSubtitle.style.transition = 'opacity 0.8s ease-in-out';
                heroSubtitle.style.opacity = '1';
            }, 400);
        }, 300);
    }
}

function initDashboard() {
    // Initialize dashboard functionality
    console.log('Dashboard initialized');
    
    // Load user data
    loadUserData();
    
    // Initialize charts if any
    initCharts();
}

function loadUserData() {
    // Simulate loading user data from database
    console.log('Loading user data...');
    
    // In a real implementation, this would fetch data from the server
    // For now, we'll just update some UI elements with mock data
    
    const balanceElement = document.getElementById('user-balance');
    if (balanceElement) {
        balanceElement.textContent = '125.50';
    }
    
    const completedAdsElement = document.getElementById('completed-ads');
    if (completedAdsElement) {
        completedAdsElement.textContent = '18';
    }
    
    const completedSurveysElement = document.getElementById('completed-surveys');
    if (completedSurveysElement) {
        completedSurveysElement.textContent = '7';
    }
}

function initCharts() {
    // Initialize any charts on the dashboard
    console.log('Initializing charts...');
    
    // This would use a charting library in a real implementation
}

function initAdsSurveys() {
    // Initialize ads and surveys page
    console.log('Ads and Surveys page initialized');
    
    // Set up filter functionality
    setupFilters();
    
    // Load available ads and surveys
    loadAvailableContent();
}

function setupFilters() {
    // Set up filter functionality for ads and surveys
    const filterSelects = document.querySelectorAll('.filter-select');
    
    filterSelects.forEach(select => {
        select.addEventListener('change', function() {
            // In a real implementation, this would filter the content
            console.log('Filter changed:', this.value);
            
            // For demo purposes, we'll just reload the content
            loadAvailableContent();
        });
    });
}

function loadAvailableContent() {
    // Load available ads and surveys
    console.log('Loading available content...');
    
    // This would fetch data from the server in a real implementation
}

function initMerchantCampaign() {
    // Initialize merchant campaign page
    console.log('Merchant Campaign page initialized');
    
    // Set up wizard functionality
    setupWizard();
    
    // Set up campaign type selection
    setupCampaignTypeSelection();
    
    // Initialize audience targeting
    initAudienceTargeting();
}

function setupWizard() {
    // Set up wizard functionality
    const wizardSteps = document.querySelectorAll('.wizard-step');
    const wizardContents = document.querySelectorAll('.wizard-step-content');
    const nextButtons = document.querySelectorAll('.btn-next');
    const prevButtons = document.querySelectorAll('.btn-prev');
    
    let currentStep = 0;
    
    // Initialize wizard
    if (wizardSteps.length > 0 && wizardContents.length > 0) {
        wizardSteps[currentStep].classList.add('active');
        wizardContents[currentStep].classList.add('active');
        
        // Set up next buttons
        nextButtons.forEach(button => {
            button.addEventListener('click', function() {
                // Validate current step (would be implemented in a real app)
                
                // Move to next step
                wizardSteps[currentStep].classList.remove('active');
                wizardContents[currentStep].classList.remove('active');
                
                currentStep++;
                
                wizardSteps[currentStep].classList.add('active');
                wizardContents[currentStep].classList.add('active');
                
                // Scroll to top of wizard
                const wizardContainer = document.querySelector('.wizard-container');
                if (wizardContainer) {
                    wizardContainer.scrollIntoView({ behavior: 'smooth' });
                }
            });
        });
        
        // Set up previous buttons
        prevButtons.forEach(button => {
            button.addEventListener('click', function() {
                wizardSteps[currentStep].classList.remove('active');
                wizardContents[currentStep].classList.remove('active');
                
                currentStep--;
                
                wizardSteps[currentStep].classList.add('active');
                wizardContents[currentStep].classList.add('active');
                
                // Scroll to top of wizard
                const wizardContainer = document.querySelector('.wizard-container');
                if (wizardContainer) {
                    wizardContainer.scrollIntoView({ behavior: 'smooth' });
                }
            });
        });
    }
}

function setupCampaignTypeSelection() {
    // Set up campaign type selection
    const campaignTypeCards = document.querySelectorAll('.campaign-type-card');
    
    campaignTypeCards.forEach(card => {
        card.addEventListener('click', function() {
            // Remove selected class from all cards
            campaignTypeCards.forEach(c => c.classList.remove('selected'));
            
            // Add selected class to clicked card
            this.classList.add('selected');
            
            // Update hidden input with selected campaign type
            const campaignTypeInput = document.getElementById('campaign-type');
            if (campaignTypeInput) {
                campaignTypeInput.value = this.dataset.type;
            }
        });
    });
}

function initAudienceTargeting() {
    // Initialize audience targeting functionality
    console.log('Initializing audience targeting...');
    
    // Set up age range slider
    setupRangeSlider();
    
    // Set up location selection
    setupLocationSelection();
    
    // Update audience size estimate when targeting changes
    updateAudienceEstimate();
}

function setupRangeSlider() {
    // Set up range slider for age targeting
    const minAgeInput = document.getElementById('min-age');
    const maxAgeInput = document.getElementById('max-age');
    const minAgeValue = document.getElementById('min-age-value');
    const maxAgeValue = document.getElementById('max-age-value');
    
    if (minAgeInput && maxAgeInput && minAgeValue && maxAgeValue) {
        // Update displayed values when inputs change
        minAgeInput.addEventListener('input', function() {
            minAgeValue.textContent = this.value;
            updateAudienceEstimate();
        });
        
        maxAgeInput.addEventListener('input', function() {
            maxAgeValue.textContent = this.value;
            updateAudienceEstimate();
        });
    }
}

function setupLocationSelection() {
    // Set up location selection
    const locationCheckboxes = document.querySelectorAll('.location-checkbox');
    
    locationCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            updateAudienceEstimate();
        });
    });
}

function updateAudienceEstimate() {
    // Update audience size estimate based on targeting options
    console.log('Updating audience estimate...');
    
    // In a real implementation, this would calculate the audience size
    // based on the selected targeting options
    
    // For demo purposes, we'll just update the UI with a random number
    const audienceSizeElement = document.getElementById('audience-size-value');
    if (audienceSizeElement) {
        const randomSize = Math.floor(Math.random() * 500000) + 100000;
        audienceSizeElement.textContent = randomSize.toLocaleString();
    }
    
    const audienceMatchElement = document.getElementById('audience-match-value');
    if (audienceMatchElement) {
        const randomMatch = Math.floor(Math.random() * 30) + 70;
        audienceMatchElement.textContent = randomMatch + '%';
    }
}

function initAdvertiserDashboard() {
    // Initialize advertiser dashboard
    console.log('Advertiser Dashboard initialized');
    
    // Load campaign data
    loadCampaignData();
    
    // Initialize analytics charts
    initAnalyticsCharts();
}

function loadCampaignData() {
    // Load campaign data
    console.log('Loading campaign data...');
    
    // This would fetch data from the server in a real implementation
}

function initAnalyticsCharts() {
    // Initialize analytics charts
    console.log('Initializing analytics charts...');
    
    // This would use a charting library in a real implementation
}

function initApprovalDashboard() {
    // Initialize approval dashboard
    console.log('Approval Dashboard initialized');
    
    // Load pending campaigns
    loadPendingCampaigns();
    
    // Set up approval/rejection functionality
    setupApprovalActions();
}

function loadPendingCampaigns() {
    // Load pending campaigns
    console.log('Loading pending campaigns...');
    
    // This would fetch data from the server in a real implementation
}

function setupApprovalActions() {
    // Set up approval/rejection functionality
    const reviewButtons = document.querySelectorAll('[data-translate="review_campaign"]');
    
    reviewButtons.forEach(button => {
        button.addEventListener('click', function() {
            // In a real implementation, this would open a modal or navigate to a review page
            alert('Review functionality would open here');
        });
    });
}

// Language switching functionality
function initializeLanguage() {
    // Check if language preference is stored
    const storedLanguage = localStorage.getItem('language') || 'ar';
    
    // Set initial language
    document.documentElement.lang = storedLanguage;
    document.documentElement.dir = storedLanguage === 'ar' ? 'rtl' : 'ltr';
    
    // Update language toggle button text
    updateLanguageToggleText(storedLanguage);
    
    // Translate the page
    translatePage(storedLanguage);
}

function toggleLanguage() {
    const currentLang = document.documentElement.lang;
    const newLang = currentLang === 'ar' ? 'en' : 'ar';
    
    // Update HTML attributes
    document.documentElement.lang = newLang;
    document.documentElement.dir = newLang === 'ar' ? 'rtl' : 'ltr';
    
    // Store preference
    localStorage.setItem('language', newLang);
    
    // Update language toggle button text
    updateLanguageToggleText(newLang);
    
    // Translate the page
    translatePage(newLang);
}

function updateLanguageToggleText(language) {
    const toggleButtons = document.querySelectorAll('.language-toggle');
    
    toggleButtons.forEach(button => {
        button.textContent = language === 'ar' ? 'English' : 'العربية';
    });
}

function translatePage(language) {
    // Fetch the appropriate translation file
    fetch(`../translations/${language}.json`)
        .then(response => response.json())
        .then(translations => {
            // Get all elements with data-translate attribute
            const elements = document.querySelectorAll('[data-translate]');
            
            // Update each element with the appropriate translation
            elements.forEach(element => {
                const key = element.getAttribute('data-translate');
                if (translations[key]) {
                    element.textContent = translations[key];
                }
            });
            
            // Update placeholders for input elements
            const inputs = document.querySelectorAll('input[data-translate-placeholder]');
            inputs.forEach(input => {
                const key = input.getAttribute('data-translate-placeholder');
                if (translations[key]) {
                    input.placeholder = translations[key];
                }
            });
        })
        .catch(error => {
            console.error('Error loading translations:', error);
        });
}
