// Campaign management module for Bushra
// This script provides campaign creation and management functionality

window.bushra = window.bushra || {};

window.bushra.campaigns = (function() {
  // Campaign types
  const CAMPAIGN_TYPES = {
    AD: 'ad',
    SURVEY: 'survey',
    AWARENESS: 'awareness'
  };
  
  // Campaign statuses
  const CAMPAIGN_STATUSES = {
    DRAFT: 'draft',
    PENDING: 'pending',
    ACTIVE: 'active',
    PAUSED: 'paused',
    COMPLETED: 'completed',
    REJECTED: 'rejected'
  };
  
  // Industry types
  const INDUSTRY_TYPES = {
    AIRLINE: 'airline',
    TELECOM: 'telecom',
    GOVERNMENT: 'government',
    AUTOMOTIVE: 'automotive',
    RETAIL: 'retail',
    FINANCE: 'finance',
    HEALTHCARE: 'healthcare',
    EDUCATION: 'education',
    TECHNOLOGY: 'technology',
    OTHER: 'other'
  };
  
  // Current campaign being created/edited
  let currentCampaign = null;
  
  // Create a new campaign
  function createCampaign(type, industry) {
    const campaignId = 'camp_' + Date.now();
    
    currentCampaign = {
      id: campaignId,
      type: type || CAMPAIGN_TYPES.AD,
      industry: industry || INDUSTRY_TYPES.OTHER,
      name: '',
      description: '',
      company: '',
      reward: getDefaultReward(type, industry),
      targeting: window.bushra.targeting ? window.bushra.targeting.getTargeting() : {
        age_min: 18,
        age_max: 65,
        gender: [],
        cities: [],
        interests: []
      },
      content: {
        title: '',
        body: '',
        media: [],
        cta: '',
        url: ''
      },
      budget: {
        total: 0,
        daily: 0,
        costPerView: 0
      },
      schedule: {
        startDate: new Date().toISOString().split('T')[0],
        endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
      },
      status: CAMPAIGN_STATUSES.DRAFT,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    return currentCampaign;
  }
  
  // Get default reward based on campaign type and industry
  function getDefaultReward(type, industry) {
    // Default rewards by industry and type
    const rewards = {
      [INDUSTRY_TYPES.AIRLINE]: {
        [CAMPAIGN_TYPES.AD]: 3.50,
        [CAMPAIGN_TYPES.SURVEY]: 15.00,
        [CAMPAIGN_TYPES.AWARENESS]: 2.00
      },
      [INDUSTRY_TYPES.TELECOM]: {
        [CAMPAIGN_TYPES.AD]: 2.50,
        [CAMPAIGN_TYPES.SURVEY]: 12.00,
        [CAMPAIGN_TYPES.AWARENESS]: 1.50
      },
      [INDUSTRY_TYPES.GOVERNMENT]: {
        [CAMPAIGN_TYPES.AD]: 1.50,
        [CAMPAIGN_TYPES.SURVEY]: 10.00,
        [CAMPAIGN_TYPES.AWARENESS]: 1.00
      },
      [INDUSTRY_TYPES.AUTOMOTIVE]: {
        [CAMPAIGN_TYPES.AD]: 3.00,
        [CAMPAIGN_TYPES.SURVEY]: 20.00,
        [CAMPAIGN_TYPES.AWARENESS]: 2.00
      },
      default: {
        [CAMPAIGN_TYPES.AD]: 2.00,
        [CAMPAIGN_TYPES.SURVEY]: 10.00,
        [CAMPAIGN_TYPES.AWARENESS]: 1.50
      }
    };
    
    // Get reward for specific industry and type, or use default
    const industryRewards = rewards[industry] || rewards.default;
    return industryRewards[type] || industryRewards[CAMPAIGN_TYPES.AD];
  }
  
  // Get current campaign
  function getCurrentCampaign() {
    return currentCampaign;
  }
  
  // Update campaign details
  function updateCampaignDetails(details) {
    if (!currentCampaign) {
      return null;
    }
    
    currentCampaign = {
      ...currentCampaign,
      ...details,
      updatedAt: new Date().toISOString()
    };
    
    return currentCampaign;
  }
  
  // Update campaign targeting
  function updateCampaignTargeting(targeting) {
    if (!currentCampaign) {
      return null;
    }
    
    currentCampaign.targeting = {
      ...currentCampaign.targeting,
      ...targeting
    };
    
    currentCampaign.updatedAt = new Date().toISOString();
    
    return currentCampaign;
  }
  
  // Update campaign content
  function updateCampaignContent(content) {
    if (!currentCampaign) {
      return null;
    }
    
    currentCampaign.content = {
      ...currentCampaign.content,
      ...content
    };
    
    currentCampaign.updatedAt = new Date().toISOString();
    
    return currentCampaign;
  }
  
  // Update campaign budget
  function updateCampaignBudget(budget) {
    if (!currentCampaign) {
      return null;
    }
    
    currentCampaign.budget = {
      ...currentCampaign.budget,
      ...budget
    };
    
    currentCampaign.updatedAt = new Date().toISOString();
    
    return currentCampaign;
  }
  
  // Update campaign schedule
  function updateCampaignSchedule(schedule) {
    if (!currentCampaign) {
      return null;
    }
    
    currentCampaign.schedule = {
      ...currentCampaign.schedule,
      ...schedule
    };
    
    currentCampaign.updatedAt = new Date().toISOString();
    
    return currentCampaign;
  }
  
  // Submit campaign for approval
  function submitCampaignForApproval() {
    if (!currentCampaign) {
      return null;
    }
    
    currentCampaign.status = CAMPAIGN_STATUSES.PENDING;
    currentCampaign.updatedAt = new Date().toISOString();
    
    // In a real implementation, we would send the campaign to the server
    // For the demo, we'll just save it to localStorage
    saveCampaignToLocalStorage(currentCampaign);
    
    return currentCampaign;
  }
  
  // Save campaign to localStorage
  function saveCampaignToLocalStorage(campaign) {
    try {
      // Get existing campaigns
      const existingCampaigns = JSON.parse(localStorage.getItem('bushra_campaigns') || '[]');
      
      // Check if campaign already exists
      const existingIndex = existingCampaigns.findIndex(c => c.id === campaign.id);
      
      if (existingIndex >= 0) {
        // Update existing campaign
        existingCampaigns[existingIndex] = campaign;
      } else {
        // Add new campaign
        existingCampaigns.push(campaign);
      }
      
      // Save back to localStorage
      localStorage.setItem('bushra_campaigns', JSON.stringify(existingCampaigns));
      
      return true;
    } catch (e) {
      console.error('Error saving campaign to localStorage:', e);
      return false;
    }
  }
  
  // Get all campaigns
  function getAllCampaigns() {
    try {
      // Get campaigns from localStorage
      const localCampaigns = JSON.parse(localStorage.getItem('bushra_campaigns') || '[]');
      
      // Get campaigns from data module if available
      const dataCampaigns = window.bushra.data ? window.bushra.data.getCampaigns() || [] : [];
      
      // Combine both sources
      return [...dataCampaigns, ...localCampaigns];
    } catch (e) {
      console.error('Error getting campaigns:', e);
      return [];
    }
  }
  
  // Get campaigns by status
  function getCampaignsByStatus(status) {
    const campaigns = getAllCampaigns();
    return campaigns.filter(campaign => campaign.status === status);
  }
  
  // Get campaigns by type
  function getCampaignsByType(type) {
    const campaigns = getAllCampaigns();
    return campaigns.filter(campaign => campaign.type === type);
  }
  
  // Get campaigns by industry
  function getCampaignsByIndustry(industry) {
    const campaigns = getAllCampaigns();
    return campaigns.filter(campaign => campaign.industry === industry);
  }
  
  // Get campaign by ID
  function getCampaignById(id) {
    const campaigns = getAllCampaigns();
    return campaigns.find(campaign => campaign.id === id);
  }
  
  // Initialize campaign form
  function initializeCampaignForm() {
    // Campaign type selection
    const typeSelectors = document.querySelectorAll('.campaign-type-selector');
    
    typeSelectors.forEach(selector => {
      selector.addEventListener('click', function() {
        const type = this.getAttribute('data-type');
        const industry = document.querySelector('.industry-selector.selected')?.getAttribute('data-industry') || INDUSTRY_TYPES.OTHER;
        
        // Update UI
        typeSelectors.forEach(s => s.classList.remove('selected'));
        this.classList.add('selected');
        
        // Create new campaign
        createCampaign(type, industry);
        
        // Update reward display
        updateRewardDisplay();
      });
    });
    
    // Industry selection
    const industrySelectors = document.querySelectorAll('.industry-selector');
    
    industrySelectors.forEach(selector => {
      selector.addEventListener('click', function() {
        const industry = this.getAttribute('data-industry');
        const type = document.querySelector('.campaign-type-selector.selected')?.getAttribute('data-type') || CAMPAIGN_TYPES.AD;
        
        // Update UI
        industrySelectors.forEach(s => s.classList.remove('selected'));
        this.classList.add('selected');
        
        // Update current campaign
        if (currentCampaign) {
          currentCampaign.industry = industry;
          currentCampaign.reward = getDefaultReward(currentCampaign.type, industry);
        } else {
          createCampaign(type, industry);
        }
        
        // Update reward display
        updateRewardDisplay();
      });
    });
    
    // Campaign details form
    const campaignDetailsForm = document.getElementById('campaign-details-form');
    
    if (campaignDetailsForm) {
      campaignDetailsForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const name = document.getElementById('campaign-name').value;
        const description = document.getElementById('campaign-description').value;
        const company = document.getElementById('campaign-company').value;
        const reward = parseFloat(document.getElementById('campaign-reward').value);
        
        updateCampaignDetails({
          name,
          description,
          company,
          reward
        });
        
        // Move to next step
        const nextStep = document.querySelector('.campaign-step.active').nextElementSibling;
        if (nextStep) {
          document.querySelectorAll('.campaign-step').forEach(step => step.classList.remove('active'));
          nextStep.classList.add('active');
        }
      });
    }
    
    // Campaign content form
    const campaignContentForm = document.getElementById('campaign-content-form');
    
    if (campaignContentForm) {
      campaignContentForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const title = document.getElementById('content-title').value;
        const body = document.getElementById('content-body').value;
        const cta = document.getElementById('content-cta').value;
        const url = document.getElementById('content-url').value;
        
        updateCampaignContent({
          title,
          body,
          cta,
          url
        });
        
        // Move to next step
        const nextStep = document.querySelector('.campaign-step.active').nextElementSibling;
        if (nextStep) {
          document.querySelectorAll('.campaign-step').forEach(step => step.classList.remove('active'));
          nextStep.classList.add('active');
        }
      });
    }
    
    // Campaign budget form
    const campaignBudgetForm = document.getElementById('campaign-budget-form');
    
    if (campaignBudgetForm) {
      campaignBudgetForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const total = parseFloat(document.getElementById('budget-total').value);
        const daily = parseFloat(document.getElementById('budget-daily').value);
        
        updateCampaignBudget({
          total,
          daily
        });
        
        // Move to next step
        const nextStep = document.querySelector('.campaign-step.active').nextElementSibling;
        if (nextStep) {
          document.querySelectorAll('.campaign-step').forEach(step => step.classList.remove('active'));
          nextStep.classList.add('active');
        }
      });
    }
    
    // Campaign schedule form
    const campaignScheduleForm = document.getElementById('campaign-schedule-form');
    
    if (campaignScheduleForm) {
      campaignScheduleForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const startDate = document.getElementById('schedule-start-date').value;
        const endDate = document.getElementById('schedule-end-date').value;
        
        updateCampaignSchedule({
          startDate,
          endDate
        });
        
        // Move to next step
        const nextStep = document.querySelector('.campaign-step.active').nextElementSibling;
        if (nextStep) {
          document.querySelectorAll('.campaign-step').forEach(step => step.classList.remove('active'));
          nextStep.classList.add('active');
          
          // Update review page
          updateCampaignReview();
        }
      });
    }
    
    // Campaign submit button
    const submitCampaignButton = document.getElementById('submit-campaign');
    
    if (submitCampaignButton) {
      submitCampaignButton.addEventListener('click', function() {
        submitCampaignForApproval();
        
        // Show success message
        const successMessage = document.getElementById('campaign-success-message');
        if (successMessage) {
          successMessage.style.display = 'block';
        }
        
        // Hide review section
        const reviewSection = document.getElementById('campaign-review-section');
        if (reviewSection) {
          reviewSection.style.display = 'none';
        }
      });
    }
    
    // Initialize with a new campaign
    createCampaign();
  }
  
  // Update reward display
  function updateRewardDisplay() {
    const rewardInput = document.getElementById('campaign-reward');
    const rewardDisplay = document.getElementById('reward-display');
    
    if (rewardInput && currentCampaign) {
      rewardInput.value = currentCampaign.reward.toFixed(2);
    }
    
    if (rewardDisplay && currentCampaign) {
      rewardDisplay.textContent = currentCampaign.reward.toFixed(2);
    }
  }
  
  // Update campaign review
  function updateCampaignReview() {
    if (!currentCampaign) {
      return;
    }
    
    // Campaign type
    const typeDisplay = document.getElementById('review-type');
    if (typeDisplay) {
      const typeLabels = {
        [CAMPAIGN_TYPES.AD]: document.documentElement.lang === 'ar' ? 'إعلان' : 'Advertisement',
        [CAMPAIGN_TYPES.SURVEY]: document.documentElement.lang === 'ar' ? 'استبيان' : 'Survey',
        [CAMPAIGN_TYPES.AWARENESS]: document.documentElement.lang === 'ar' ? 'حملة توعوية' : 'Awareness Campaign'
      };
      
      typeDisplay.textContent = typeLabels[currentCampaign.type] || currentCampaign.type;
    }
    
    // Campaign industry
    const industryDisplay = document.getElementById('review-industry');
    if (industryDisplay) {
      const industryLabels = {
        [INDUSTRY_TYPES.AIRLINE]: document.documentElement.lang === 'ar' ? 'طيران' : 'Airline',
        [INDUSTRY_TYPES.TELECOM]: document.documentElement.lang === 'ar' ? 'اتصالات' : 'Telecom',
        [INDUSTRY_TYPES.GOVERNMENT]: document.documentElement.lang === 'ar' ? 'حكومي' : 'Government',
        [INDUSTRY_TYPES.AUTOMOTIVE]: document.documentElement.lang === 'ar' ? 'سيارات' : 'Automotive',
        [INDUSTRY_TYPES.RETAIL]: document.documentElement.lang === 'ar' ? 'تجزئة' : 'Retail',
        [INDUSTRY_TYPES.FINANCE]: document.documentElement.lang === 'ar' ? 'مالية' : 'Finance',
        [INDUSTRY_TYPES.HEALTHCARE]: document.documentElement.lang === 'ar' ? 'رعاية صحية' : 'Healthcare',
        [INDUSTRY_TYPES.EDUCATION]: document.documentElement.lang === 'ar' ? 'تعليم' : 'Education',
        [INDUSTRY_TYPES.TECHNOLOGY]: document.documentElement.lang === 'ar' ? 'تقنية' : 'Technology',
        [INDUSTRY_TYPES.OTHER]: document.documentElement.lang === 'ar' ? 'أخرى' : 'Other'
      };
      
      industryDisplay.textContent = industryLabels[currentCampaign.industry] || currentCampaign.industry;
    }
    
    // Campaign name
    const nameDisplay = document.getElementById('review-name');
    if (nameDisplay) {
      nameDisplay.textContent = currentCampaign.name;
    }
    
    // Campaign company
    const companyDisplay = document.getElementById('review-company');
    if (companyDisplay) {
      companyDisplay.textContent = currentCampaign.company;
    }
    
    // Campaign reward
    const rewardDisplay = document.getElementById('review-reward');
    if (rewardDisplay) {
      rewardDisplay.textContent = currentCampaign.reward.toFixed(2) + ' SAR';
    }
    
    // Campaign targeting
    const targetingDisplay = document.getElementById('review-targeting');
    if (targetingDisplay) {
      const targeting = currentCampaign.targeting;
      const isArabic = document.documentElement.lang === 'ar';
      
      let targetingText = '';
      
      // Age range
      targetingText += isArabic ? `العمر: ${targeting.age_min} - ${targeting.age_max}` : `Age: ${targeting.age_min} - ${targeting.age_max}`;
      
      // Gender
      if (targeting.gender.length === 0) {
        targetingText += isArabic ? ', الجنس: الجميع' : ', Gender: All';
      } else if (targeting.gender.length === 2) {
        targetingText += isArabic ? ', الجنس: ذكور وإناث' : ', Gender: Male and Female';
      } else if (targeting.gender.includes('Male')) {
        targetingText += isArabic ? ', الجنس: ذكور فقط' : ', Gender: Male only';
      } else {
        targetingText += isArabic ? ', الجنس: إناث فقط' : ', Gender: Female only';
      }
      
      // Cities
      if (targeting.cities.length === 0) {
        targetingText += isArabic ? ', المدن: جميع المدن' : ', Cities: All cities';
      } else {
        targetingText += isArabic ? `, المدن: ${targeting.cities.join(', ')}` : `, Cities: ${targeting.cities.join(', ')}`;
      }
      
      // Interests
      if (targeting.interests.length === 0) {
        targetingText += isArabic ? ', الاهتمامات: جميع الاهتمامات' : ', Interests: All interests';
      } else {
        targetingText += isArabic ? `, الاهتمامات: ${targeting.interests.join(', ')}` : `, Interests: ${targeting.interests.join(', ')}`;
      }
      
      targetingDisplay.textContent = targetingText;
    }
    
    // Campaign budget
    const budgetDisplay = document.getElementById('review-budget');
    if (budgetDisplay) {
      const isArabic = document.documentElement.lang === 'ar';
      const budget = currentCampaign.budget;
      
      let budgetText = '';
      
      if (budget.total > 0) {
        budgetText += isArabic ? `الميزانية الكلية: ${budget.total.toFixed(2)} ريال` : `Total Budget: ${budget.total.toFixed(2)} SAR`;
      }
      
      if (budget.daily > 0) {
        budgetText += isArabic ? `, الميزانية اليومية: ${budget.daily.toFixed(2)} ريال` : `, Daily Budget: ${budget.daily.toFixed(2)} SAR`;
      }
      
      budgetDisplay.textContent = budgetText;
    }
    
    // Campaign schedule
    const scheduleDisplay = document.getElementById('review-schedule');
    if (scheduleDisplay) {
      const isArabic = document.documentElement.lang === 'ar';
      const schedule = currentCampaign.schedule;
      
      let scheduleText = '';
      
      if (schedule.startDate) {
        scheduleText += isArabic ? `تاريخ البدء: ${schedule.startDate}` : `Start Date: ${schedule.startDate}`;
      }
      
      if (schedule.endDate) {
        scheduleText += isArabic ? `, تاريخ الانتهاء: ${schedule.endDate}` : `, End Date: ${schedule.endDate}`;
      }
      
      scheduleDisplay.textContent = scheduleText;
    }
  }
  
  // Initialize the campaigns module
  function initialize() {
    document.addEventListener('DOMContentLoaded', function() {
      initializeCampaignForm();
    });
  }
  
  // Public API
  return {
    initialize,
    createCampaign,
    getCurrentCampaign,
    updateCampaignDetails,
    updateCampaignTargeting,
    updateCampaignContent,
    updateCampaignBudget,
    updateCampaignSchedule,
    submitCampaignForApproval,
    getAllCampaigns,
    getCampaignsByStatus,
    getCampaignsByType,
    getCampaignsByIndustry,
    getCampaignById,
    CAMPAIGN_TYPES,
    CAMPAIGN_STATUSES,
    INDUSTRY_TYPES
  };
})();

// Initialize campaigns when DOM is loaded
window.bushra.campaigns.initialize();
