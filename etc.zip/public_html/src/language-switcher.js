// Language switching functionality for Bushra website
// This file implements the core language switching mechanism

// Language data store
const translations = {
  en: {},
  ar: {}
};

// Default language
let currentLanguage = 'ar';

// Initialize language system
function initializeLanguage() {
  // Check for saved language preference
  const savedLanguage = localStorage.getItem('bushra_language');
  
  if (savedLanguage && (savedLanguage === 'en' || savedLanguage === 'ar')) {
    currentLanguage = savedLanguage;
  }
  
  // Load translation files
  loadTranslations()
    .then(() => {
      // Apply initial language
      applyLanguage(currentLanguage);
      
      // Initialize language toggle button
      initializeLanguageToggle();
    })
    .catch(error => {
      console.error('Failed to load translations:', error);
    });
}

// Load translation files
async function loadTranslations() {
  try {
    // Load English translations
    const enResponse = await fetch('/translations/en.json');
    translations.en = await enResponse.json();
    
    // Load Arabic translations (for completeness, though we already have Arabic content)
    const arResponse = await fetch('/translations/ar.json');
    translations.ar = await arResponse.json();
    
    return true;
  } catch (error) {
    console.error('Error loading translations:', error);
    return false;
  }
}

// Apply selected language to the page
function applyLanguage(language) {
  if (language !== 'en' && language !== 'ar') {
    console.error('Invalid language code:', language);
    return false;
  }
  
  // Update current language
  currentLanguage = language;
  
  // Save preference to localStorage
  localStorage.setItem('bushra_language', language);
  
  // Update HTML lang attribute
  document.documentElement.lang = language;
  
  // Update HTML dir attribute for RTL/LTR
  document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
  
  // Update language toggle button text
  const languageToggle = document.querySelector('.language-toggle');
  if (languageToggle) {
    languageToggle.textContent = language === 'ar' ? 'English' : 'العربية';
  }
  
  // Apply translations to all elements with data-i18n attribute
  const elements = document.querySelectorAll('[data-i18n]');
  
  elements.forEach(element => {
    const key = element.getAttribute('data-i18n');
    
    if (translations[language] && translations[language][key]) {
      // Handle different element types
      if (element.tagName === 'INPUT' && element.type !== 'submit' && element.type !== 'button') {
        // For input elements, update placeholder and value if empty
        element.placeholder = translations[language][key];
        if (!element.value) {
          element.value = translations[language][key];
        }
      } else if (element.tagName === 'IMG') {
        // For images, update alt text
        element.alt = translations[language][key];
      } else {
        // For other elements, update inner text
        element.textContent = translations[language][key];
      }
    } else {
      console.warn(`Translation missing for key: ${key} in language: ${language}`);
    }
  });
  
  // Apply translations to all elements with data-i18n-placeholder attribute
  const placeholderElements = document.querySelectorAll('[data-i18n-placeholder]');
  
  placeholderElements.forEach(element => {
    const key = element.getAttribute('data-i18n-placeholder');
    
    if (translations[language] && translations[language][key]) {
      element.placeholder = translations[language][key];
    }
  });
  
  // Apply translations to all elements with data-i18n-value attribute
  const valueElements = document.querySelectorAll('[data-i18n-value]');
  
  valueElements.forEach(element => {
    const key = element.getAttribute('data-i18n-value');
    
    if (translations[language] && translations[language][key]) {
      element.value = translations[language][key];
    }
  });
  
  // Apply translations to all elements with data-i18n-title attribute
  const titleElements = document.querySelectorAll('[data-i18n-title]');
  
  titleElements.forEach(element => {
    const key = element.getAttribute('data-i18n-title');
    
    if (translations[language] && translations[language][key]) {
      element.title = translations[language][key];
    }
  });
  
  // Update CSS classes for RTL/LTR styling
  if (language === 'ar') {
    document.body.classList.add('rtl');
    document.body.classList.remove('ltr');
  } else {
    document.body.classList.add('ltr');
    document.body.classList.remove('rtl');
  }
  
  // Dispatch language change event
  const event = new CustomEvent('languageChanged', { detail: { language } });
  document.dispatchEvent(event);
  
  return true;
}

// Initialize language toggle button
function initializeLanguageToggle() {
  const languageToggle = document.querySelector('.language-toggle');
  
  if (!languageToggle) {
    // Create language toggle button if it doesn't exist
    createLanguageToggle();
  } else {
    // Update existing toggle button
    languageToggle.textContent = currentLanguage === 'ar' ? 'English' : 'العربية';
    
    // Add event listener
    languageToggle.addEventListener('click', toggleLanguage);
  }
}

// Create language toggle button
function createLanguageToggle() {
  // Check if button already exists
  if (document.querySelector('.language-toggle')) {
    return;
  }
  
  // Create button
  const button = document.createElement('button');
  button.className = 'language-toggle';
  button.textContent = currentLanguage === 'ar' ? 'English' : 'العربية';
  
  // Add event listener
  button.addEventListener('click', toggleLanguage);
  
  // Find navbar or header to append button
  const navbar = document.querySelector('.navbar-nav, .nav, header');
  
  if (navbar) {
    // Create container for button
    const container = document.createElement('div');
    container.className = 'language-toggle-container';
    container.appendChild(button);
    
    // Append to navbar
    navbar.appendChild(container);
  } else {
    // If no navbar, append to body
    document.body.appendChild(button);
  }
}

// Toggle between languages
function toggleLanguage() {
  const newLanguage = currentLanguage === 'ar' ? 'en' : 'ar';
  
  // Apply new language
  if (applyLanguage(newLanguage)) {
    // If we have a single-page application, this would update the UI
    // For a traditional website, we need to redirect to the translated page
    if (typeof window.translateCurrentPage === 'function') {
      // For SPA: update current page content
      window.translateCurrentPage(newLanguage);
    } else {
      // For traditional website: redirect to translated page
      redirectToTranslatedPage(newLanguage);
    }
  }
}

// Redirect to translated page
function redirectToTranslatedPage(language) {
  // Get current path
  const currentPath = window.location.pathname;
  
  // Check if we're already on a language-specific path
  const langPathRegex = /^\/(en|ar)\//;
  const match = currentPath.match(langPathRegex);
  
  if (match) {
    // Replace language code in path
    const newPath = currentPath.replace(langPathRegex, `/${language}/`);
    window.location.href = newPath;
  } else {
    // Add language code to path
    const newPath = `/${language}${currentPath}`;
    window.location.href = newPath;
  }
}

// Get translation for a key
function getTranslation(key, language = currentLanguage) {
  if (!translations[language] || !translations[language][key]) {
    console.warn(`Translation missing for key: ${key} in language: ${language}`);
    return key;
  }
  
  return translations[language][key];
}

// Format date according to current language
function formatDate(date, options = {}) {
  if (!(date instanceof Date)) {
    date = new Date(date);
  }
  
  return new Intl.DateTimeFormat(currentLanguage === 'ar' ? 'ar-SA' : 'en-US', options).format(date);
}

// Format number according to current language
function formatNumber(number, options = {}) {
  return new Intl.NumberFormat(currentLanguage === 'ar' ? 'ar-SA' : 'en-US', options).format(number);
}

// Format currency according to current language
function formatCurrency(amount, currency = 'SAR') {
  return new Intl.NumberFormat(currentLanguage === 'ar' ? 'ar-SA' : 'en-US', {
    style: 'currency',
    currency: currency
  }).format(amount);
}

// Export language utilities
window.bushra = window.bushra || {};
window.bushra.language = {
  initialize: initializeLanguage,
  current: () => currentLanguage,
  apply: applyLanguage,
  toggle: toggleLanguage,
  translate: getTranslation,
  formatDate,
  formatNumber,
  formatCurrency
};

// Initialize language system when DOM is ready
document.addEventListener('DOMContentLoaded', initializeLanguage);
