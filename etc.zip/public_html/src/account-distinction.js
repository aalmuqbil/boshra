// User and merchant account distinction functionality
// This script enhances the distinction between user and merchant accounts

// Store references to DOM elements
const accountTypeToggle = document.getElementById('account-type-toggle');
const userLoginForm = document.getElementById('user-login-form');
const merchantLoginForm = document.getElementById('merchant-login-form');
const switchToUserBtn = document.getElementById('switch-to-user');
const switchToMerchantBtn = document.getElementById('switch-to-merchant');

// Initialize the account distinction functionality
function initAccountDistinction() {
  // Add event listeners to account type toggle buttons if they exist
  if (switchToUserBtn) {
    switchToUserBtn.addEventListener('click', () => switchAccountType('user'));
  }
  
  if (switchToMerchantBtn) {
    switchToMerchantBtn.addEventListener('click', () => switchAccountType('merchant'));
  }
  
  // Check URL parameters for account type
  const urlParams = new URLSearchParams(window.location.search);
  const accountType = urlParams.get('account');
  
  if (accountType) {
    switchAccountType(accountType);
  } else {
    // Default to user account type
    switchAccountType('user');
  }
  
  // Update UI based on current user type
  updateUIBasedOnAccountType();
}

// Switch between user and merchant account types
function switchAccountType(type) {
  if (!userLoginForm || !merchantLoginForm) return;
  
  if (type === 'user') {
    userLoginForm.style.display = 'block';
    merchantLoginForm.style.display = 'none';
    switchToUserBtn.classList.add('active');
    switchToMerchantBtn.classList.remove('active');
    document.querySelector('.login-header h1').textContent = 'تسجيل دخول المستخدم';
    document.querySelector('.login-header p').textContent = 'أدخل بيانات حسابك للوصول إلى حسابك الشخصي';
  } else if (type === 'merchant') {
    userLoginForm.style.display = 'none';
    merchantLoginForm.style.display = 'block';
    switchToUserBtn.classList.remove('active');
    switchToMerchantBtn.classList.add('active');
    document.querySelector('.login-header h1').textContent = 'تسجيل دخول المعلن';
    document.querySelector('.login-header p').textContent = 'أدخل بيانات حسابك للوصول إلى لوحة تحكم المعلن';
  }
}

// Update UI based on current user type
function updateUIBasedOnAccountType() {
  const loginInfo = JSON.parse(localStorage.getItem('bushraLoginInfo'));
  
  if (!loginInfo || !loginInfo.loggedIn) return;
  
  // Update UI elements based on account type
  const accountTypeIndicator = document.getElementById('account-type-indicator');
  const userSpecificElements = document.querySelectorAll('.user-specific');
  const merchantSpecificElements = document.querySelectorAll('.merchant-specific');
  
  if (accountTypeIndicator) {
    if (loginInfo.type === 'user') {
      accountTypeIndicator.textContent = 'حساب مستخدم';
      accountTypeIndicator.classList.add('user-badge');
      accountTypeIndicator.classList.remove('merchant-badge');
    } else if (loginInfo.type === 'merchant') {
      accountTypeIndicator.textContent = 'حساب معلن';
      accountTypeIndicator.classList.add('merchant-badge');
      accountTypeIndicator.classList.remove('user-badge');
    }
  }
  
  // Show/hide elements based on account type
  if (loginInfo.type === 'user') {
    userSpecificElements.forEach(el => el.style.display = 'block');
    merchantSpecificElements.forEach(el => el.style.display = 'none');
  } else if (loginInfo.type === 'merchant') {
    userSpecificElements.forEach(el => el.style.display = 'none');
    merchantSpecificElements.forEach(el => el.style.display = 'block');
  }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', initAccountDistinction);

// Export functions for use in other scripts
window.bushraAccountDistinction = {
  initAccountDistinction,
  switchAccountType,
  updateUIBasedOnAccountType
};
