// Bushra MVP - API Integration

/**
 * API Integration Component
 * Handles communication between frontend and backend
 */
class ApiService {
  constructor() {
    // Base API URL - would be configured based on environment in production
    this.baseUrl = 'http://localhost:3000/api';
  }

  // Authentication methods
  async absherLogin(nationalId, password, verificationCode) {
    try {
      const response = await fetch(`${this.baseUrl}/auth/absher`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ nationalId, password, verificationCode })
      });
      
      return await response.json();
    } catch (error) {
      console.error('Absher login error:', error);
      return { success: false, message: 'حدث خطأ أثناء تسجيل الدخول' };
    }
  }

  // User methods
  async getUserProfile(userId) {
    try {
      const response = await fetch(`${this.baseUrl}/user/profile?id=${userId}`);
      return await response.json();
    } catch (error) {
      console.error('Get user profile error:', error);
      return { success: false, message: 'حدث خطأ أثناء جلب بيانات المستخدم' };
    }
  }

  async updateUserPreferences(userId, preferences) {
    try {
      const response = await fetch(`${this.baseUrl}/user/preferences`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ userId, preferences })
      });
      
      return await response.json();
    } catch (error) {
      console.error('Update preferences error:', error);
      return { success: false, message: 'حدث خطأ أثناء تحديث التفضيلات' };
    }
  }

  // Ad methods
  async getAds(userId) {
    try {
      const response = await fetch(`${this.baseUrl}/ads?userId=${userId}`);
      return await response.json();
    } catch (error) {
      console.error('Get ads error:', error);
      return { success: false, message: 'حدث خطأ أثناء جلب الإعلانات' };
    }
  }

  async recordAdView(userId, adId) {
    try {
      const response = await fetch(`${this.baseUrl}/ads/view`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ userId, adId })
      });
      
      return await response.json();
    } catch (error) {
      console.error('Record ad view error:', error);
      return { success: false, message: 'حدث خطأ أثناء تسجيل مشاهدة الإعلان' };
    }
  }

  async completeSurvey(userId, surveyId, responses) {
    try {
      const response = await fetch(`${this.baseUrl}/surveys/complete`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ userId, surveyId, responses })
      });
      
      return await response.json();
    } catch (error) {
      console.error('Complete survey error:', error);
      return { success: false, message: 'حدث خطأ أثناء إرسال الاستبيان' };
    }
  }

  // Wallet methods
  async getTransactions(userId) {
    try {
      const response = await fetch(`${this.baseUrl}/wallet/transactions?userId=${userId}`);
      return await response.json();
    } catch (error) {
      console.error('Get transactions error:', error);
      return { success: false, message: 'حدث خطأ أثناء جلب المعاملات' };
    }
  }

  async withdrawFunds(userId, amount, bankAccount, accountNumber) {
    try {
      const response = await fetch(`${this.baseUrl}/wallet/withdraw`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ userId, amount, bankAccount, accountNumber })
      });
      
      return await response.json();
    } catch (error) {
      console.error('Withdraw funds error:', error);
      return { success: false, message: 'حدث خطأ أثناء طلب السحب' };
    }
  }

  // Campaign methods
  async getCampaigns(advertiserId) {
    try {
      const response = await fetch(`${this.baseUrl}/campaigns?advertiserId=${advertiserId}`);
      return await response.json();
    } catch (error) {
      console.error('Get campaigns error:', error);
      return { success: false, message: 'حدث خطأ أثناء جلب الحملات' };
    }
  }

  async createCampaign(advertiserId, campaign) {
    try {
      const response = await fetch(`${this.baseUrl}/campaigns`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ advertiserId, campaign })
      });
      
      return await response.json();
    } catch (error) {
      console.error('Create campaign error:', error);
      return { success: false, message: 'حدث خطأ أثناء إنشاء الحملة' };
    }
  }

  async updateCampaign(campaignId, advertiserId, updates) {
    try {
      const response = await fetch(`${this.baseUrl}/campaigns/${campaignId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ advertiserId, updates })
      });
      
      return await response.json();
    } catch (error) {
      console.error('Update campaign error:', error);
      return { success: false, message: 'حدث خطأ أثناء تحديث الحملة' };
    }
  }
}

// Export as global variable for easy access
window.apiService = new ApiService();
