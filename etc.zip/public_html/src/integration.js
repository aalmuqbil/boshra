// Bushra MVP - Frontend-Backend Integration

/**
 * Integration Module
 * Connects frontend components with backend API
 */
class BushraIntegration {
  constructor() {
    this.apiService = window.apiService;
    this.init();
  }
  
  init() {
    // Initialize based on current page
    const currentPath = window.location.pathname;
    
    if (currentPath.includes('index.html') || currentPath === '/' || currentPath === '') {
      this.initLandingPage();
    } else if (currentPath.includes('dashboard.html')) {
      this.initUserDashboard();
    } else if (currentPath.includes('advertiser-dashboard.html')) {
      this.initAdvertiserDashboard();
    }
    
    // Add global auth check
    this.checkAuthentication();
  }
  
  checkAuthentication() {
    // Check if user is logged in for protected pages
    const protectedPages = ['dashboard.html', 'wallet.html', 'preferences.html', 'settings.html'];
    const advertiserPages = ['advertiser-dashboard.html', 'advertiser-campaigns.html', 'advertiser-new-campaign.html'];
    
    const currentPath = window.location.pathname;
    const isProtectedPage = protectedPages.some(page => currentPath.includes(page));
    const isAdvertiserPage = advertiserPages.some(page => currentPath.includes(page));
    
    if (isProtectedPage) {
      const userData = JSON.parse(localStorage.getItem('bushra_user') || 'null');
      if (!userData) {
        // Redirect to login page
        window.location.href = 'index.html?auth=required';
      }
    }
    
    if (isAdvertiserPage) {
      const advertiserData = JSON.parse(localStorage.getItem('bushra_advertiser') || 'null');
      if (!advertiserData) {
        // Redirect to login page
        window.location.href = 'index.html?auth=advertiser';
      }
    }
  }
  
  initLandingPage() {
    // Handle Absher login
    const absherButton = document.querySelector('.absher-button');
    if (absherButton) {
      absherButton.addEventListener('click', async (e) => {
        e.preventDefault();
        
        // Show login modal (handled by absher-integration.js)
        // But we'll override the form submission to use our API
        
        const absherLoginForm = document.getElementById('absher-login-form');
        if (absherLoginForm) {
          absherLoginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const nationalId = document.getElementById('national-id').value;
            const password = document.getElementById('absher-password').value;
            const verificationCode = document.getElementById('verification-code').value;
            
            if (nationalId && password && verificationCode) {
              // Show loading state
              const submitButton = absherLoginForm.querySelector('button[type="submit"]');
              submitButton.textContent = 'جاري تسجيل الدخول...';
              submitButton.disabled = true;
              
              // Call API
              const response = await this.apiService.absherLogin(nationalId, password, verificationCode);
              
              if (response.success) {
                // Store user data
                localStorage.setItem('bushra_user', JSON.stringify(response.user));
                localStorage.setItem('bushra_token', response.token);
                
                // Redirect to dashboard
                window.location.href = 'dashboard.html';
              } else {
                // Show error
                alert(response.message || 'حدث خطأ أثناء تسجيل الدخول');
                
                // Reset button
                submitButton.textContent = 'تسجيل الدخول';
                submitButton.disabled = false;
              }
            }
          });
        }
      });
    }
    
    // Handle waitlist form
    const waitlistForm = document.querySelector('form');
    if (waitlistForm && !waitlistForm.id) {
      waitlistForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const email = waitlistForm.querySelector('input[type="email"]').value;
        
        if (email) {
          // Show success message
          waitlistForm.innerHTML = '<div class="alert alert-success">شكراً لتسجيلك! سنتواصل معك قريباً.</div>';
          
          // In a real implementation, we would send this to the backend
          console.log('Waitlist signup:', email);
        }
      });
    }
  }
  
  async initUserDashboard() {
    // Get user data
    const userData = JSON.parse(localStorage.getItem('bushra_user') || 'null');
    if (!userData) return;
    
    // Update user name if available
    const userNameElement = document.querySelector('h3:contains("أهلاً")');
    if (userNameElement && userData.name) {
      userNameElement.textContent = `أهلاً، ${userData.name.split(' ')[0]}`;
    }
    
    // Load available ads
    try {
      const adsResponse = await this.apiService.getAds(userData.id);
      
      if (adsResponse.success && adsResponse.ads.length > 0) {
        this.renderAds(adsResponse.ads);
      }
    } catch (error) {
      console.error('Error loading ads:', error);
    }
    
    // Load transactions
    try {
      const transactionsResponse = await this.apiService.getTransactions(userData.id);
      
      if (transactionsResponse.success && transactionsResponse.transactions.length > 0) {
        this.renderTransactions(transactionsResponse.transactions);
      }
    } catch (error) {
      console.error('Error loading transactions:', error);
    }
    
    // Handle ad interactions
    this.setupAdInteractions(userData.id);
    
    // Handle wallet functionality
    this.setupWalletFunctionality(userData.id);
  }
  
  renderAds(ads) {
    // Find container for ads
    const adContainer = document.querySelector('.ad-card').parentNode;
    if (!adContainer) return;
    
    // Clear existing ads
    adContainer.innerHTML = '';
    
    // Render each ad
    ads.forEach(ad => {
      const adCard = document.createElement('div');
      adCard.className = 'ad-card';
      adCard.dataset.adId = ad.id;
      adCard.dataset.adType = ad.type;
      
      adCard.innerHTML = `
        <div class="ad-card-header">
          <h4 class="ad-card-title">${ad.title}</h4>
          <span class="ad-card-reward">${ad.reward} ر.س</span>
        </div>
        <div class="ad-card-content">
          <p>${ad.description}</p>
        </div>
        <div class="ad-card-footer">
          <span class="ad-card-category">${ad.categories.join(', ')}</span>
          <a href="#" class="btn btn-primary btn-sm">${ad.type === 'ad' ? 'مشاهدة الإعلان' : 'المشاركة في الاستبيان'}</a>
        </div>
      `;
      
      adContainer.appendChild(adCard);
    });
  }
  
  renderTransactions(transactions) {
    // Find transactions table
    const transactionsTable = document.querySelector('.table tbody');
    if (!transactionsTable) return;
    
    // Clear existing transactions
    transactionsTable.innerHTML = '';
    
    // Sort transactions by date (newest first)
    transactions.sort((a, b) => new Date(b.date) - new Date(a.date));
    
    // Render each transaction (limit to 4 for dashboard)
    const displayTransactions = transactions.slice(0, 4);
    
    displayTransactions.forEach(transaction => {
      const row = document.createElement('tr');
      
      // Format date
      const date = new Date(transaction.date);
      const formattedDate = date.toLocaleDateString('ar-SA');
      
      // Determine transaction type in Arabic
      let typeText = '';
      switch (transaction.type) {
        case 'ad_view':
          typeText = 'إعلان';
          break;
        case 'survey_complete':
          typeText = 'استبيان';
          break;
        case 'withdrawal':
          typeText = 'سحب';
          break;
        default:
          typeText = transaction.type;
      }
      
      // Format amount with color
      const amountClass = transaction.amount > 0 ? 'text-success' : 'text-danger';
      const amountPrefix = transaction.amount > 0 ? '+' : '';
      
      row.innerHTML = `
        <td>${formattedDate}</td>
        <td>${typeText}</td>
        <td>${transaction.description}</td>
        <td class="${amountClass}">${amountPrefix}${transaction.amount.toFixed(2)} ر.س</td>
      `;
      
      transactionsTable.appendChild(row);
    });
  }
  
  setupAdInteractions(userId) {
    // Add event listeners to ad buttons
    document.addEventListener('click', async (e) => {
      // Check if clicked element is an ad button
      if (e.target.matches('.ad-card .btn')) {
        e.preventDefault();
        
        const adCard = e.target.closest('.ad-card');
        const adId = adCard.dataset.adId;
        const adType = adCard.dataset.adType;
        
        if (adType === 'ad') {
          // Show ad view modal
          this.showAdViewModal(userId, adId, adCard);
        } else if (adType === 'survey') {
          // Show survey modal
          this.showSurveyModal(userId, adId, adCard);
        }
      }
    });
  }
  
  showAdViewModal(userId, adId, adCard) {
    // Get ad details
    const adTitle = adCard.querySelector('.ad-card-title').textContent;
    const adReward = adCard.querySelector('.ad-card-reward').textContent;
    
    // Create or update modal
    let modal = document.getElementById('ad-view-modal');
    
    if (!modal) {
      // Create modal if it doesn't exist
      modal = document.createElement('div');
      modal.id = 'ad-view-modal';
      modal.className = 'modal';
      
      modal.innerHTML = `
        <div class="modal-content">
          <span class="close">&times;</span>
          <h3 id="ad-title">${adTitle}</h3>
          <div class="ad-content text-center my-4">
            <img src="images/ad-placeholder.png" alt="Ad Content" style="max-width: 100%;">
          </div>
          <div class="text-center">
            <p>يرجى مشاهدة الإعلان بالكامل للحصول على <span id="ad-reward">${adReward}</span></p>
            <div class="progress-bar-container mt-3 mb-3">
              <div id="ad-progress" class="progress-bar" style="width: 0%;"></div>
            </div>
            <button id="confirm-view-btn" class="btn btn-primary" disabled>تأكيد المشاهدة</button>
          </div>
        </div>
      `;
      
      document.body.appendChild(modal);
      
      // Add close button functionality
      modal.querySelector('.close').addEventListener('click', () => {
        modal.style.display = 'none';
      });
      
      // Close when clicking outside
      window.addEventListener('click', (event) => {
        if (event.target === modal) {
          modal.style.display = 'none';
        }
      });
    } else {
      // Update existing modal
      modal.querySelector('#ad-title').textContent = adTitle;
      modal.querySelector('#ad-reward').textContent = adReward;
      modal.querySelector('#ad-progress').style.width = '0%';
      modal.querySelector('#confirm-view-btn').disabled = true;
    }
    
    // Show modal
    modal.style.display = 'block';
    
    // Simulate ad progress
    let progress = 0;
    const progressBar = document.getElementById('ad-progress');
    const confirmButton = document.getElementById('confirm-view-btn');
    
    const progressInterval = setInterval(() => {
      progress += 5;
      progressBar.style.width = progress + '%';
      
      if (progress >= 100) {
        clearInterval(progressInterval);
        confirmButton.disabled = false;
        
        // Add event listener to confirm button
        confirmButton.onclick = async () => {
          // Record ad view in API
          const response = await this.apiService.recordAdView(userId, adId);
          
          if (response.success) {
            // Update user balance
            const userData = JSON.parse(localStorage.getItem('bushra_user') || '{}');
            userData.balance = response.newBalance;
            localStorage.setItem('bushra_user', JSON.stringify(userData));
            
            // Update UI
            const earningsAmount = document.querySelector('.earnings-amount');
            if (earningsAmount) {
              earningsAmount.textContent = response.newBalance.toFixed(2) + ' ر.س';
            }
            
            // Show success notification
            this.showNotification(`تم إضافة ${response.reward} ر.س إلى رصيدك!`, 'success');
            
            // Hide modal
            modal.style.display = 'none';
          } else {
            // Show error
            this.showNotification(response.message || 'حدث خطأ أثناء تسجيل مشاهدة الإعلان', 'error');
          }
        };
      }
    }, 500);
  }
  
  showSurveyModal(userId, surveyId, adCard) {
    // Get survey details
    const surveyTitle = adCard.querySelector('.ad-card-title').textContent;
    const surveyReward = adCard.querySelector('.ad-card-reward').textContent;
    
    // Create or update modal
    let modal = document.getElementById('survey-modal');
    
    if (!modal) {
      // Create modal if it doesn't exist
      modal = document.createElement('div');
      modal.id = 'survey-modal';
      modal.className = 'modal';
      
      modal.innerHTML = `
        <div class="modal-content">
          <span class="close">&times;</span>
          <h3 id="survey-title">${surveyTitle}</h3>
          <p class="text-center">أكمل هذا الاستبيان للحصول على <span id="survey-reward">${surveyReward}</span></p>
          <div class="survey-content my-4">
            <form id="survey-form">
              <div class="form-group">
                <label>1. كم مرة تتسوق عبر الإنترنت شهرياً؟</label>
                <div class="mt-2">
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="q1" id="q1-1" value="1">
                    <label class="form-check-label" for="q1-1">لا أتسوق عبر الإنترنت</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="q1" id="q1-2" value="2">
                    <label class="form-check-label" for="q1-2">1-2 مرات</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="q1" id="q1-3" value="3">
                    <label class="form-check-label" for="q1-3">3-5 مرات</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="q1" id="q1-4" value="4">
                    <label class="form-check-label" for="q1-4">أكثر من 5 مرات</label>
                  </div>
                </div>
              </div>
              <div class="form-group mt-3">
                <label>2. ما هي منصات التسوق الإلكتروني التي تستخدمها؟</label>
                <div class="mt-2">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="q2" id="q2-1" value="noon">
                    <label class="form-check-label" for="q2-1">نون</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="q2" id="q2-2" value="amazon">
                    <label class="form-check-label" for="q2-2">أمازون</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="q2" id="q2-3" value="jarir">
                    <label class="form-check-label" for="q2-3">جرير</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="q2" id="q2-4" value="other">
                    <label class="form-check-label" for="q2-4">أخرى</label>
                  </div>
                </div>
              </div>
              <div class="form-group mt-3">
                <label>3. ما هي العوامل الأكثر أهمية بالنسبة لك عند التسوق عبر الإنترنت؟</label>
                <div class="mt-2">
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="q3" id="q3-1" value="price">
                    <label class="form-check-label" for="q3-1">السعر</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="q3" id="q3-2" value="quality">
                    <label class="form-check-label" for="q3-2">الجودة</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="q3" id="q3-3" value="delivery">
                    <label class="form-check-label" for="q3-3">سرعة التوصيل</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="q3" id="q3-4" value="reviews">
                    <label class="form-check-label" for="q3-4">تقييمات المستخدمين</label>
                  </div>
                </div>
              </div>
              <div class="text-center mt-4">
                <button type="submit" class="btn btn-primary">إرسال الاستبيان</button>
              </div>
            </form>
          </div>
        </div>
      `;
      
      document.body.appendChild(modal);
      
      // Add close button functionality
      modal.querySelector('.close').addEventListener('click', () => {
        modal.style.display = 'none';
      });
      
      // Close when clicking outside
      window.addEventListener('click', (event) => {
        if (event.target === modal) {
          modal.style.display = 'none';
        }
      });
    } else {
      // Update existing modal
      modal.querySelector('#survey-title').textContent = surveyTitle;
      modal.querySelector('#survey-reward').textContent = surveyReward;
      
      // Reset form
      const form = modal.querySelector('#survey-form');
      if (form) form.reset();
    }
    
    // Show modal
    modal.style.display = 'block';
    
    // Handle form submission
    const surveyForm = document.getElementById('survey-form');
    surveyForm.onsubmit = async (e) => {
      e.preventDefault();
      
      // Validate form
      const q1 = surveyForm.querySelector('input[name="q1"]:checked');
      const q3 = surveyForm.querySelector('input[name="q3"]:checked');
      
      if (!q1 || !q3) {
        alert('يرجى الإجابة على جميع الأسئلة المطلوبة');
        return;
      }
      
      // Collect responses
      const formData = new FormData(surveyForm);
      const responses = {};
      
      for (let [key, value] of formData.entries()) {
        if (responses[key]) {
          if (!Array.isArray(responses[key])) {
            responses[key] = [responses[key]];
          }
          responses[key].push(value);
        } else {
          responses[key] = value;
        }
      }
      
      // Submit survey
      const response = await this.apiService.completeSurvey(userId, surveyId, responses);
      
      if (response.success) {
        // Update user balance
        const userData = JSON.parse(localStorage.getItem('bushra_user') || '{}');
        userData.balance = response.newBalance;
        localStorage.setItem('bushra_user', JSON.stringify(userData));
        
        // Update UI
        const earningsAmount = document.querySelector('.earnings-amount');
        if (earningsAmount) {
          earningsAmount.textContent = response.newBalance.toFixed(2) + ' ر.س';
        }
        
        // Show success notification
        this.showNotification(`تم إضافة ${response.reward} ر.س إلى رصيدك!`, 'success');
        
        // Hide modal
        modal.style.display = 'none';
      } else {
        // Show error
        this.showNotification(response.message || 'حدث خطأ أثناء إرسال الاستبيان', 'error');
      }
    };
  }
  
  setupWalletFunctionality(userId) {
    // Handle withdrawal button
    document.addEventListener('click', (e) => {
      if (e.target.matches('.btn:contains("سحب الرصيد")')) {
        e.preventDefault();
        this.showWithdrawalModal(userId);
      }
    });
  }
  
  showWithdrawalModal(userId) {
    // Get user data
    const userData = JSON.parse(localStorage.getItem('bushra_user') || '{}');
    const balance = userData.balance || 0;
    
    // Create or update modal
    let modal = document.getElementById('withdrawal-modal');
    
    if (!modal) {
      // Create modal if it doesn't exist
      modal = document.createElement('div');
      modal.id = 'withdrawal-modal';
      modal.className = 'modal';
      
      modal.innerHTML = `
        <div class="modal-content">
          <span class="close">&times;</span>
          <h3>سحب الرصيد</h3>
          <div class="my-4">
            <p>رصيدك الحالي: <strong class="current-balance">${balance.toFixed(2)} ر.س</strong></p>
            <form id="withdrawal-form">
              <div class="form-group">
                <label for="withdrawal-amount">المبلغ المراد سحبه</label>
                <input type="number" id="withdrawal-amount" class="form-control" min="50" max="${balance}" value="50" required>
                <small class="text-muted">الحد الأدنى للسحب هو 50 ر.س</small>
              </div>
              <div class="form-group mt-3">
                <label for="bank-account">الحساب المصرفي</label>
                <select id="bank-account" class="form-control" required>
                  <option value="">اختر الحساب المصرفي</option>
                  <option value="alahli">البنك الأهلي السعودي</option>
                  <option value="alrajhi">مصرف الراجحي</option>
                  <option value="samba">سامبا</option>
                  <option value="riyadh">بنك الرياض</option>
                </select>
              </div>
              <div class="form-group mt-3">
                <label for="account-number">رقم الحساب (IBAN)</label>
                <input type="text" id="account-number" class="form-control" placeholder="SA0000000000000000000000" required>
              </div>
              <div class="text-center mt-4">
                <button type="submit" class="btn btn-primary">تأكيد السحب</button>
              </div>
            </form>
          </div>
        </div>
      `;
      
      document.body.appendChild(modal);
      
      // Add close button functionality
      modal.querySelector('.close').addEventListener('click', () => {
        modal.style.display = 'none';
      });
      
      // Close when clicking outside
      window.addEventListener('click', (event) => {
        if (event.target === modal) {
          modal.style.display = 'none';
        }
      });
    } else {
      // Update existing modal
      modal.querySelector('.current-balance').textContent = balance.toFixed(2) + ' ر.س';
      
      // Update max withdrawal amount
      const amountInput = modal.querySelector('#withdrawal-amount');
      if (amountInput) {
        amountInput.max = balance;
      }
      
      // Reset form
      const form = modal.querySelector('#withdrawal-form');
      if (form) form.reset();
    }
    
    // Show modal
    modal.style.display = 'block';
    
    // Handle form submission
    const withdrawalForm = document.getElementById('withdrawal-form');
    withdrawalForm.onsubmit = async (e) => {
      e.preventDefault();
      
      const amount = parseFloat(document.getElementById('withdrawal-amount').value);
      const bankAccount = document.getElementById('bank-account').value;
      const accountNumber = document.getElementById('account-number').value;
      
      // Validate form
      if (amount < 50) {
        alert('الحد الأدنى للسحب هو 50 ر.س');
        return;
      }
      
      if (amount > balance) {
        alert('المبلغ المطلوب أكبر من رصيدك الحالي');
        return;
      }
      
      if (!bankAccount) {
        alert('يرجى اختيار الحساب المصرفي');
        return;
      }
      
      if (!accountNumber) {
        alert('يرجى إدخال رقم الحساب');
        return;
      }
      
      // Show loading state
      const submitButton = withdrawalForm.querySelector('button[type="submit"]');
      submitButton.textContent = 'جاري تنفيذ العملية...';
      submitButton.disabled = true;
      
      // Submit withdrawal request
      const response = await this.apiService.withdrawFunds(userId, amount, bankAccount, accountNumber);
      
      if (response.success) {
        // Update user balance
        const userData = JSON.parse(localStorage.getItem('bushra_user') || '{}');
        userData.balance = response.newBalance;
        localStorage.setItem('bushra_user', JSON.stringify(userData));
        
        // Update UI
        const earningsAmount = document.querySelector('.earnings-amount');
        if (earningsAmount) {
          earningsAmount.textContent = response.newBalance.toFixed(2) + ' ر.س';
        }
        
        // Show success notification
        this.showNotification(`تم تقديم طلب سحب بمبلغ ${amount.toFixed(2)} ر.س إلى حسابك المصرفي بنجاح. سيتم تنفيذ العملية خلال 1-3 أيام عمل.`, 'success');
        
        // Hide modal
        modal.style.display = 'none';
      } else {
        // Show error
        this.showNotification(response.message || 'حدث خطأ أثناء طلب السحب', 'error');
        
        // Reset button
        submitButton.textContent = 'تأكيد السحب';
        submitButton.disabled = false;
      }
    };
  }
  
  async initAdvertiserDashboard() {
    // For MVP, we'll use a mock advertiser ID
    const advertiserId = 'adv-1';
    
    // Store advertiser data
    localStorage.setItem('bushra_advertiser', JSON.stringify({
      id: advertiserId,
      name: 'شركة الرياض للتسويق',
      type: 'company'
    }));
    
    // Load campaigns
    try {
      const campaignsResponse = await this.apiService.getCampaigns(advertiserId);
      
      if (campaignsResponse.success && campaignsResponse.campaigns.length > 0) {
        // For MVP, we're using static HTML for campaigns
        console.log('Campaigns loaded:', campaignsResponse.campaigns);
      }
    } catch (error) {
      console.error('Error loading campaigns:', error);
    }
    
    // Handle new campaign button
    const newCampaignButton = document.querySelector('.btn-secondary');
    if (newCampaignButton) {
      newCampaignButton.addEventListener('click', (e) => {
        e.preventDefault();
        window.location.href = 'advertiser-new-campaign.html';
      });
    }
    
    // Handle campaign edit buttons
    const editButtons = document.querySelectorAll('.btn-primary.btn-sm');
    editButtons.forEach(button => {
      button.addEventListener('click', (e) => {
        e.preventDefault();
        const campaignCard = button.closest('.card');
        const campaignTitle = campaignCard.querySelector('h4').textContent;
        
        window.location.href = `advertiser-edit-campaign.html?campaign=${encodeURIComponent(campaignTitle)}`;
      });
    });
  }
  
  showNotification(message, type = 'success') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}-notification`;
    notification.innerHTML = `
      <div class="notification-content">
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
        <p>${message}</p>
      </div>
    `;
    
    // Add styles
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.backgroundColor = type === 'success' ? 'var(--success)' : 'var(--danger)';
    notification.style.color = 'white';
    notification.style.padding = '15px 20px';
    notification.style.borderRadius = 'var(--radius-md)';
    notification.style.boxShadow = 'var(--shadow-md)';
    notification.style.zIndex = '1001';
    notification.style.transform = 'translateX(120%)';
    notification.style.transition = 'transform 0.3s ease';
    
    // RTL support
    if (document.querySelector('html').getAttribute('dir') === 'rtl') {
      notification.style.right = 'auto';
      notification.style.left = '20px';
      notification.style.transform = 'translateX(-120%)';
    }
    
    // Add to body
    document.body.appendChild(notification);
    
    // Show notification
    setTimeout(() => {
      notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Hide and remove after 5 seconds
    setTimeout(() => {
      notification.style.transform = document.querySelector('html').getAttribute('dir') === 'rtl' ? 
        'translateX(-120%)' : 'translateX(120%)';
      setTimeout(() => {
        if (notification.parentNode) {
          notification.parentNode.removeChild(notification);
        }
      }, 300);
    }, 5000);
  }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  // Make sure API service is loaded first
  if (window.apiService) {
    new BushraIntegration();
  } else {
    // Load API service first
    const script = document.createElement('script');
    script.src = '../src/api-service.js';
    script.onload = () => {
      new BushraIntegration();
    };
    document.body.appendChild(script);
  }
});
