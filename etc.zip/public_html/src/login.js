// Login functionality for Bushra website
// This script handles user and merchant authentication

// Store references to DOM elements
const loginForm = document.getElementById('login-form');
const usernameInput = document.getElementById('username');
const passwordInput = document.getElementById('password');
const accountTypeSelect = document.getElementById('account-type');
const loginButton = document.getElementById('login-button');
const loginError = document.getElementById('login-error');

// Load user and merchant data
let users = [];
let merchants = [];

// Fetch user data
async function fetchUserData() {
  try {
    const userResponse = await fetch('../data/users.json');
    const userData = await userResponse.json();
    users = userData.users;
    
    const merchantResponse = await fetch('../data/merchants.json');
    const merchantData = await merchantResponse.json();
    merchants = merchantData.merchants;
    
    console.log('User and merchant data loaded successfully');
  } catch (error) {
    console.error('Error loading user data:', error);
  }
}

// Initialize the login functionality
function initLogin() {
  fetchUserData();
  
  // Add event listener to login form
  if (loginForm) {
    loginForm.addEventListener('submit', handleLogin);
  }
  
  // Check if user is already logged in
  checkLoginStatus();
}

// Handle login form submission
function handleLogin(event) {
  event.preventDefault();
  
  const username = usernameInput.value.trim();
  const password = passwordInput.value;
  const accountType = accountTypeSelect.value;
  
  if (!username || !password) {
    showLoginError('الرجاء إدخال اسم المستخدم وكلمة المرور');
    return;
  }
  
  // Authenticate based on account type
  if (accountType === 'user') {
    authenticateUser(username, password);
  } else if (accountType === 'merchant') {
    authenticateMerchant(username, password);
  }
}

// Authenticate user
function authenticateUser(username, password) {
  const user = users.find(u => u.username === username && u.password === password);
  
  if (user) {
    // Login successful
    loginSuccess(user, 'user');
  } else {
    showLoginError('اسم المستخدم أو كلمة المرور غير صحيحة');
  }
}

// Authenticate merchant
function authenticateMerchant(username, password) {
  const merchant = merchants.find(m => m.username === username && m.password === password);
  
  if (merchant) {
    // Login successful
    loginSuccess(merchant, 'merchant');
  } else {
    showLoginError('اسم المستخدم أو كلمة المرور غير صحيحة');
  }
}

// Handle successful login
function loginSuccess(account, type) {
  // Store login information in localStorage
  const loginInfo = {
    id: account.id,
    username: account.username,
    name: account.name,
    type: type,
    loggedIn: true,
    loginTime: new Date().toISOString()
  };
  
  localStorage.setItem('bushraLoginInfo', JSON.stringify(loginInfo));
  
  // Redirect to ads-surveys page for users, and advertiser dashboard for merchants
  if (type === 'user') {
    // Changed from dashboard.html to ads-surveys.html as requested
    window.location.href = 'ads-surveys.html';
  } else if (type === 'merchant') {
    window.location.href = 'advertiser-dashboard.html';
  }
}

// Show login error message
function showLoginError(message) {
  if (loginError) {
    loginError.textContent = message;
    loginError.style.display = 'block';
    
    // Hide error after 3 seconds
    setTimeout(() => {
      loginError.style.display = 'none';
    }, 3000);
  }
}

// Check if user is already logged in
function checkLoginStatus() {
  const loginInfo = JSON.parse(localStorage.getItem('bushraLoginInfo'));
  
  if (loginInfo && loginInfo.loggedIn) {
    // User is logged in, update UI accordingly
    updateUIForLoggedInUser(loginInfo);
    
    // If on login page, redirect to appropriate page
    if (window.location.pathname.includes('login.html')) {
      if (loginInfo.type === 'user') {
        // Changed from dashboard.html to ads-surveys.html as requested
        window.location.href = 'ads-surveys.html';
      } else if (loginInfo.type === 'merchant') {
        window.location.href = 'advertiser-dashboard.html';
      }
    }
  }
}

// Update UI for logged in user
function updateUIForLoggedInUser(loginInfo) {
  const loginButtons = document.querySelectorAll('.login-button, .login-btn');
  const userMenus = document.querySelectorAll('.user-menu');
  
  // Hide login buttons
  loginButtons.forEach(button => {
    button.style.display = 'none';
  });
  
  // Show user menu
  userMenus.forEach(menu => {
    menu.style.display = 'flex';
    
    // Update user name
    const userNameElement = menu.querySelector('.user-name');
    if (userNameElement) {
      userNameElement.textContent = loginInfo.name;
    }
  });
}

// Handle logout
function logout() {
  // Clear login information
  localStorage.removeItem('bushraLoginInfo');
  
  // Redirect to home page
  window.location.href = 'index.html';
}

// Initialize login functionality when DOM is loaded
document.addEventListener('DOMContentLoaded', initLogin);

// Export functions for use in other scripts
window.bushraAuth = {
  logout,
  checkLoginStatus,
  getCurrentUser: () => JSON.parse(localStorage.getItem('bushraLoginInfo'))
};
