// Database initialization and connection module
// This file handles loading the database and initializing it for the application

// Import the database structure and service
const DATABASE = require('./database.js');
const DatabaseService = require('./database-service.js');

// Database initialization function
function initializeDatabase() {
  console.log('Initializing Bushra database...');
  
  // Simulate loading data from persistent storage
  const loadedData = localStorage.getItem('bushra_database');
  
  if (loadedData) {
    try {
      // Parse the stored data
      const parsedData = JSON.parse(loadedData);
      
      // Merge with the default database
      Object.keys(parsedData).forEach(key => {
        if (DATABASE[key]) {
          DATABASE[key] = parsedData[key];
        }
      });
      
      console.log('Database loaded from storage');
    } catch (error) {
      console.error('Error loading database from storage:', error);
      console.log('Using default database');
    }
  } else {
    console.log('No stored database found, using default database');
  }
  
  // Set up periodic saving
  setInterval(saveDatabase, 30000); // Save every 30 seconds
  
  return {
    database: DATABASE,
    service: DatabaseService
  };
}

// Function to save database to persistent storage
function saveDatabase() {
  try {
    localStorage.setItem('bushra_database', JSON.stringify(DATABASE));
    console.log('Database saved to storage');
  } catch (error) {
    console.error('Error saving database to storage:', error);
  }
}

// Function to clear database (for testing)
function clearDatabase() {
  localStorage.removeItem('bushra_database');
  console.log('Database cleared from storage');
}

// Export the initialization function
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    initializeDatabase,
    saveDatabase,
    clearDatabase
  };
}
