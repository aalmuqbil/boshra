// Nafath authentication integration for Bushra
// This script simulates the Nafath authentication process

window.bushra = window.bushra || {};

window.bushra.auth = (function() {
  // Authentication state
  let isAuthenticated = false;
  let currentUser = null;
  let authToken = null;
  
  // Simulate Nafath authentication
  function authenticateWithNafath(nationalId, callback) {
    console.log('Initiating Nafath authentication for ID:', nationalId);
    
    // Show verification code modal
    const verificationCode = '123456'; // In a real implementation, this would be sent to the user's Nafath app
    
    // Create and show the verification modal
    const modal = document.createElement('div');
    modal.className = 'nafath-modal';
    modal.innerHTML = `
      <div class="nafath-modal-content">
        <div class="nafath-modal-header">
          <h3 data-i18n="nafath_verification">التحقق عبر نفاذ</h3>
          <span class="nafath-modal-close">&times;</span>
        </div>
        <div class="nafath-modal-body">
          <p data-i18n="verification_sent">تم إرسال رمز التحقق إلى تطبيق نفاذ الخاص بك.</p>
          <div class="nafath-code-display">${verificationCode}</div>
          <p data-i18n="enter_code">أدخل الرمز المعروض في تطبيق نفاذ:</p>
          <input type="text" class="nafath-code-input" placeholder="******" maxlength="6">
          <div class="nafath-error" style="display: none;" data-i18n="invalid_code">رمز غير صحيح، حاول مرة أخرى</div>
        </div>
        <div class="nafath-modal-footer">
          <button class="nafath-verify-btn" data-i18n="verify">تحقق</button>
          <button class="nafath-cancel-btn" data-i18n="cancel">إلغاء</button>
        </div>
      </div>
    `;
    
    document.body.appendChild(modal);
    
    // Add event listeners
    const closeBtn = modal.querySelector('.nafath-modal-close');
    const verifyBtn = modal.querySelector('.nafath-verify-btn');
    const cancelBtn = modal.querySelector('.nafath-cancel-btn');
    const codeInput = modal.querySelector('.nafath-code-input');
    const errorMsg = modal.querySelector('.nafath-error');
    
    closeBtn.addEventListener('click', function() {
      document.body.removeChild(modal);
      if (callback) callback(false, null);
    });
    
    cancelBtn.addEventListener('click', function() {
      document.body.removeChild(modal);
      if (callback) callback(false, null);
    });
    
    verifyBtn.addEventListener('click', function() {
      const inputCode = codeInput.value;
      if (inputCode === verificationCode) {
        // Successful verification
        document.body.removeChild(modal);
        
        // In a real implementation, we would make an API call to verify the code
        // and get the user data from Absher
        
        // For the demo, we'll fetch a random user from our data
        window.bushra.data.initialize().then(() => {
          const users = window.bushra.data.getUserData();
          if (users && users.length > 0) {
            // Get a random user or the first one
            currentUser = users[0];
            isAuthenticated = true;
            authToken = 'nafath_' + Math.random().toString(36).substring(2);
            
            // Store auth state in localStorage
            localStorage.setItem('bushra_auth', JSON.stringify({
              isAuthenticated,
              user: currentUser,
              token: authToken
            }));
            
            if (callback) callback(true, currentUser);
          } else {
            if (callback) callback(false, null);
          }
        });
      } else {
        // Failed verification
        errorMsg.style.display = 'block';
        codeInput.value = '';
      }
    });
    
    // Focus the input
    codeInput.focus();
  }
  
  // Check if user is authenticated
  function isUserAuthenticated() {
    if (isAuthenticated && currentUser) {
      return true;
    }
    
    // Check localStorage
    const storedAuth = localStorage.getItem('bushra_auth');
    if (storedAuth) {
      try {
        const authData = JSON.parse(storedAuth);
        isAuthenticated = authData.isAuthenticated;
        currentUser = authData.user;
        authToken = authData.token;
        return isAuthenticated;
      } catch (e) {
        return false;
      }
    }
    
    return false;
  }
  
  // Get current user
  function getCurrentUser() {
    if (isUserAuthenticated()) {
      return currentUser;
    }
    return null;
  }
  
  // Logout
  function logout() {
    isAuthenticated = false;
    currentUser = null;
    authToken = null;
    localStorage.removeItem('bushra_auth');
    
    // Redirect to home page
    window.location.href = 'index.html';
  }
  
  // Initialize auth buttons
  function initializeAuthButtons() {
    const authButtons = document.querySelectorAll('.btn-nafath, .nafath-login-btn');
    
    authButtons.forEach(button => {
      button.addEventListener('click', function(e) {
        e.preventDefault();
        
        // Get national ID from input if available
        let nationalId = '1234567890'; // Default ID for demo
        const idInput = document.querySelector('#national-id');
        if (idInput && idInput.value) {
          nationalId = idInput.value;
        }
        
        authenticateWithNafath(nationalId, function(success, user) {
          if (success) {
            console.log('Authentication successful:', user);
            
            // Redirect based on current page
            const currentPage = window.location.pathname.split('/').pop();
            if (currentPage === 'index.html' || currentPage === '') {
              window.location.href = 'dashboard.html';
            } else {
              // Reload current page to update UI
              window.location.reload();
            }
          } else {
            console.log('Authentication failed');
          }
        });
      });
    });
    
    // Initialize logout buttons
    const logoutButtons = document.querySelectorAll('.logout-btn');
    logoutButtons.forEach(button => {
      button.addEventListener('click', function(e) {
        e.preventDefault();
        logout();
      });
    });
    
    // Update UI based on auth state
    updateUIForAuthState();
  }
  
  // Update UI based on authentication state
  function updateUIForAuthState() {
    const isAuth = isUserAuthenticated();
    const user = getCurrentUser();
    
    // Update login/logout buttons
    const loginElements = document.querySelectorAll('.login-only');
    const logoutElements = document.querySelectorAll('.logout-only');
    const userNameElements = document.querySelectorAll('.user-name');
    
    loginElements.forEach(el => {
      el.style.display = isAuth ? 'none' : '';
    });
    
    logoutElements.forEach(el => {
      el.style.display = isAuth ? '' : 'none';
    });
    
    if (isAuth && user) {
      userNameElements.forEach(el => {
        el.textContent = user.name;
      });
    }
  }
  
  // Initialize the auth module
  function initialize() {
    document.addEventListener('DOMContentLoaded', function() {
      initializeAuthButtons();
    });
  }
  
  // Public API
  return {
    initialize,
    authenticateWithNafath,
    isUserAuthenticated,
    getCurrentUser,
    logout,
    updateUIForAuthState
  };
})();

// Initialize auth when DOM is loaded
window.bushra.auth.initialize();
