// Integration of Merchant Campaign Creation with Existing Website
// This file handles the integration of the new merchant campaign creation page with the existing Bushra website

document.addEventListener('DOMContentLoaded', function() {
    // Initialize navigation links
    initializeNavigation();
    
    // Initialize component loading
    loadComponents();
    
    // Initialize Absher integration for merchant verification
    initializeAbsherMerchantVerification();
    
    // Initialize data sharing between components
    initializeDataSharing();
});

// Initialize navigation links
function initializeNavigation() {
    // Add merchant campaign link to main navigation
    addMerchantCampaignLink();
    
    // Update dashboard to include campaign management section
    updateDashboardWithCampaigns();
}

// Add merchant campaign link to main navigation
function addMerchantCampaignLink() {
    // This function would be called on each page load to ensure the merchant campaign link is available
    // In a real implementation, this would modify the navigation menu server-side
    
    console.log('Adding merchant campaign link to navigation');
    
    // Check if we're on a page with the navbar
    const navbar = document.querySelector('.navbar-nav');
    
    if (navbar) {
        // Check if the link already exists
        const existingLink = navbar.querySelector('a[href="merchant-campaign.html"]');
        
        if (!existingLink) {
            // Create new nav item
            const navItem = document.createElement('li');
            navItem.className = 'nav-item';
            
            // Create link
            const link = document.createElement('a');
            link.href = 'merchant-campaign.html';
            link.className = 'nav-link';
            link.textContent = 'إنشاء حملة';
            
            // Add link to nav item
            navItem.appendChild(link);
            
            // Add nav item to navbar
            navbar.appendChild(navItem);
            
            console.log('Merchant campaign link added to navigation');
        }
    }
}

// Update dashboard to include campaign management section
function updateDashboardWithCampaigns() {
    // This function would add a campaign management section to the dashboard
    // In a real implementation, this would be part of the dashboard template
    
    console.log('Updating dashboard with campaign management section');
    
    // Check if we're on the dashboard page
    if (window.location.pathname.includes('dashboard.html')) {
        // Check if the campaigns section already exists
        const existingSection = document.querySelector('#campaigns-section');
        
        if (!existingSection) {
            // Create campaigns section
            const campaignsSection = document.createElement('div');
            campaignsSection.id = 'campaigns-section';
            campaignsSection.className = 'dashboard-section';
            
            // Set section content
            campaignsSection.innerHTML = `
                <h2 class="section-title">حملاتي الإعلانية</h2>
                <div class="section-content">
                    <div class="campaigns-list">
                        <div class="empty-state">
                            <i class="fas fa-bullhorn" style="font-size: 3rem; color: var(--text-muted); margin-bottom: 1rem;"></i>
                            <p>ليس لديك أي حملات إعلانية نشطة حالياً</p>
                            <a href="merchant-campaign.html" class="btn btn-primary">إنشاء حملة جديدة</a>
                        </div>
                    </div>
                </div>
            `;
            
            // Find the appropriate location to insert the section
            const mainContent = document.querySelector('main .container');
            
            if (mainContent) {
                // Insert after the first section
                const firstSection = mainContent.querySelector('.dashboard-section');
                
                if (firstSection) {
                    firstSection.parentNode.insertBefore(campaignsSection, firstSection.nextSibling);
                } else {
                    mainContent.appendChild(campaignsSection);
                }
                
                console.log('Campaign management section added to dashboard');
            }
        }
    }
}

// Load components
function loadComponents() {
    // Load audience targeting component
    loadScript('/src/components/audience-targeting.js');
    
    // Load campaign creation component
    loadScript('/src/components/campaign-creation.js');
    
    // Load survey creation component
    loadScript('/src/components/survey-creation.js');
}

// Load script dynamically
function loadScript(src) {
    return new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = src;
        script.onload = resolve;
        script.onerror = reject;
        document.head.appendChild(script);
    });
}

// Initialize Absher integration for merchant verification
function initializeAbsherMerchantVerification() {
    // This function would handle the integration with Absher for merchant verification
    // In the MVP, this is simulated
    
    console.log('Initializing Absher merchant verification');
    
    // Check if we're on the merchant campaign page
    if (window.location.pathname.includes('merchant-campaign.html')) {
        // Simulate Absher verification
        simulateAbsherVerification();
    }
}

// Simulate Absher verification
function simulateAbsherVerification() {
    // In a real implementation, this would check if the user is logged in and verified as a merchant
    // For the MVP, we'll assume the user is verified
    
    console.log('Simulating Absher merchant verification');
    
    // Store verification status
    window.merchantVerified = true;
    
    // Create merchant data
    window.merchantData = {
        id: 'M' + Math.floor(Math.random() * 1000000),
        name: 'شركة نموذجية',
        commercialRegistration: '1234567890',
        verified: true,
        verificationDate: new Date().toISOString(),
        category: 'retail',
        contactPerson: 'محمد أحمد',
        email: 'contact@example.com',
        phone: '+966500000000',
        address: 'الرياض، المملكة العربية السعودية'
    };
}

// Initialize data sharing between components
function initializeDataSharing() {
    // This function would set up event listeners and data structures for sharing data between components
    
    console.log('Initializing data sharing between components');
    
    // Create global campaign data object
    window.campaignData = {
        type: null,
        details: null,
        audience: null,
        content: null,
        budget: null
    };
    
    // Set up event listeners for data updates
    document.addEventListener('campaignTypeSelected', function(e) {
        window.campaignData.type = e.detail.type;
    });
    
    document.addEventListener('campaignDetailsUpdated', function(e) {
        window.campaignData.details = e.detail;
    });
    
    document.addEventListener('audienceTargetingUpdated', function(e) {
        window.campaignData.audience = e.detail;
    });
    
    document.addEventListener('contentUpdated', function(e) {
        window.campaignData.content = e.detail;
    });
    
    document.addEventListener('budgetUpdated', function(e) {
        window.campaignData.budget = e.detail;
    });
}

// Update merchant navigation based on user role
function updateMerchantNavigation() {
    // This function would show/hide merchant-specific navigation items based on user role
    // In a real implementation, this would check the user's role from the server
    
    console.log('Updating merchant navigation based on user role');
    
    // Check if user is logged in
    const isLoggedIn = document.querySelector('.navbar-nav a[href="dashboard.html"]') !== null;
    
    if (isLoggedIn) {
        // Simulate checking if user is a merchant
        const isMerchant = true; // In a real implementation, this would be determined by the user's role
        
        if (isMerchant) {
            // Show merchant-specific navigation items
            addMerchantCampaignLink();
        }
    }
}

// Add campaign creation button to ads-surveys page
function addCampaignCreationButton() {
    // This function would add a campaign creation button to the ads-surveys page
    
    console.log('Adding campaign creation button to ads-surveys page');
    
    // Check if we're on the ads-surveys page
    if (window.location.pathname.includes('ads-surveys.html')) {
        // Check if the button already exists
        const existingButton = document.querySelector('a[href="merchant-campaign.html"].create-campaign-btn');
        
        if (!existingButton) {
            // Create button
            const button = document.createElement('a');
            button.href = 'merchant-campaign.html';
            button.className = 'btn btn-primary create-campaign-btn';
            button.textContent = 'إنشاء حملة إعلانية جديدة';
            
            // Add button to page
            const pageHeader = document.querySelector('main .container h1');
            
            if (pageHeader) {
                // Create container for button
                const buttonContainer = document.createElement('div');
                buttonContainer.className = 'text-left mb-4';
                buttonContainer.appendChild(button);
                
                // Insert after page header
                pageHeader.parentNode.insertBefore(buttonContainer, pageHeader.nextSibling);
                
                console.log('Campaign creation button added to ads-surveys page');
            }
        }
    }
}

// Initialize merchant campaign page
function initializeMerchantCampaignPage() {
    // This function would initialize the merchant campaign page
    
    console.log('Initializing merchant campaign page');
    
    // Check if we're on the merchant campaign page
    if (window.location.pathname.includes('merchant-campaign.html')) {
        // Initialize wizard
        initializeWizard();
        
        // Initialize form validation
        initializeFormValidation();
        
        // Initialize preview functionality
        initializePreview();
    }
}

// Initialize wizard
function initializeWizard() {
    // This function would initialize the wizard navigation
    // The actual implementation is in campaign-creation.js
    
    console.log('Initializing wizard');
}

// Initialize form validation
function initializeFormValidation() {
    // This function would initialize form validation
    // The actual implementation is in campaign-creation.js
    
    console.log('Initializing form validation');
}

// Initialize preview functionality
function initializePreview() {
    // This function would initialize preview functionality
    // The actual implementation is in campaign-creation.js and survey-creation.js
    
    console.log('Initializing preview functionality');
}

// Export integration functions
window.bushraMerchantIntegration = {
    addMerchantCampaignLink,
    updateDashboardWithCampaigns,
    simulateAbsherVerification,
    updateMerchantNavigation,
    addCampaignCreationButton,
    initializeMerchantCampaignPage
};
