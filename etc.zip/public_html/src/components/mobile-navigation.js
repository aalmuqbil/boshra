// Bushra MVP - Mobile Navigation Component

/**
 * Mobile Navigation Component
 * Handles responsive navigation for mobile devices
 */
class MobileNavigation {
  constructor() {
    this.init();
  }
  
  init() {
    // Create mobile menu toggle button if it doesn't exist
    if (!document.querySelector('.mobile-menu-toggle')) {
      this.createMobileMenuToggle();
    }
    
    // Add event listeners
    this.addEventListeners();
    
    // Initial check for screen size
    this.checkScreenSize();
  }
  
  createMobileMenuToggle() {
    const navbar = document.querySelector('.navbar .container');
    if (navbar) {
      const toggleButton = document.createElement('button');
      toggleButton.className = 'mobile-menu-toggle';
      toggleButton.innerHTML = '<i class="fas fa-bars"></i>';
      toggleButton.style.display = 'none';
      
      // Insert before the nav links
      const navbarNav = document.querySelector('.navbar-nav');
      if (navbarNav) {
        navbar.insertBefore(toggleButton, navbarNav);
      }
    }
  }
  
  addEventListeners() {
    // Toggle menu on button click
    const toggleButton = document.querySelector('.mobile-menu-toggle');
    const navbarNav = document.querySelector('.navbar-nav');
    
    if (toggleButton && navbarNav) {
      toggleButton.addEventListener('click', () => {
        navbarNav.classList.toggle('show');
      });
    }
    
    // Check screen size on resize
    window.addEventListener('resize', () => {
      this.checkScreenSize();
    });
  }
  
  checkScreenSize() {
    const toggleButton = document.querySelector('.mobile-menu-toggle');
    const navbarNav = document.querySelector('.navbar-nav');
    
    if (toggleButton && navbarNav) {
      if (window.innerWidth <= 768) {
        toggleButton.style.display = 'block';
        navbarNav.classList.remove('show');
      } else {
        toggleButton.style.display = 'none';
        navbarNav.classList.remove('show');
        navbarNav.style.display = 'flex';
      }
    }
  }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new MobileNavigation();
});
