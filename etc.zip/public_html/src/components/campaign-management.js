// Bushra MVP - Campaign Management Component

/**
 * Campaign Management Component
 * Handles advertiser campaign creation and management functionality
 */
class CampaignManagement {
  constructor() {
    this.init();
  }
  
  init() {
    // Check if we're on an advertiser page
    if (!window.location.pathname.includes('advertiser')) {
      return;
    }
    
    // Initialize based on current page
    if (window.location.pathname.includes('advertiser-dashboard.html')) {
      this.initDashboard();
    } else if (window.location.pathname.includes('advertiser-new-campaign.html')) {
      this.initNewCampaign();
    } else if (window.location.pathname.includes('advertiser-edit-campaign.html')) {
      this.initEditCampaign();
    }
  }
  
  initDashboard() {
    // Handle campaign edit buttons
    const editButtons = document.querySelectorAll('.btn-primary.btn-sm');
    editButtons.forEach(button => {
      button.addEventListener('click', (e) => {
        e.preventDefault();
        const campaignCard = button.closest('.card');
        const campaignTitle = campaignCard.querySelector('h4').textContent;
        
        // Redirect to edit campaign page
        window.location.href = `advertiser-edit-campaign.html?campaign=${encodeURIComponent(campaignTitle)}`;
      });
    });
    
    // Handle new campaign button
    const newCampaignButton = document.querySelector('.btn-secondary');
    if (newCampaignButton) {
      newCampaignButton.addEventListener('click', (e) => {
        e.preventDefault();
        window.location.href = 'advertiser-new-campaign.html';
      });
    }
    
    // Check for success message from campaign creation
    if (window.location.search.includes('success=true')) {
      this.showSuccessNotification('تم إنشاء الحملة الإعلانية بنجاح');
      
      // Clean URL
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }
  
  initNewCampaign() {
    // Create campaign form if it doesn't exist
    if (!document.querySelector('.campaign-form')) {
      this.createCampaignForm();
    }
    
    // Add event listeners to form
    const campaignForm = document.querySelector('.campaign-form');
    if (campaignForm) {
      campaignForm.addEventListener('submit', (e) => {
        e.preventDefault();
        this.handleCampaignSubmit(campaignForm);
      });
      
      // Add dynamic budget calculation
      const budgetInput = document.getElementById('campaign-budget');
      const audienceReach = document.getElementById('audience-reach');
      if (budgetInput && audienceReach) {
        budgetInput.addEventListener('input', () => {
          const budget = parseFloat(budgetInput.value) || 0;
          // Simulate audience reach calculation (1 SAR = ~100 users)
          const reach = Math.round(budget * 100);
          audienceReach.textContent = reach.toLocaleString('ar-SA');
        });
      }
      
      // Add dynamic targeting options
      const targetingOptions = document.querySelectorAll('input[name="targeting"]');
      const customTargetingFields = document.getElementById('custom-targeting-fields');
      if (targetingOptions && customTargetingFields) {
        targetingOptions.forEach(option => {
          option.addEventListener('change', () => {
            if (option.value === 'custom' && option.checked) {
              customTargetingFields.style.display = 'block';
            } else if (option.value !== 'custom' && option.checked) {
              customTargetingFields.style.display = 'none';
            }
          });
        });
      }
    }
  }
  
  initEditCampaign() {
    // Get campaign name from URL
    const urlParams = new URLSearchParams(window.location.search);
    const campaignName = urlParams.get('campaign');
    
    if (campaignName) {
      // Create campaign form if it doesn't exist
      if (!document.querySelector('.campaign-form')) {
        this.createCampaignForm(true);
      }
      
      // Populate form with campaign data
      this.populateCampaignForm(campaignName);
      
      // Add event listeners to form
      const campaignForm = document.querySelector('.campaign-form');
      if (campaignForm) {
        campaignForm.addEventListener('submit', (e) => {
          e.preventDefault();
          this.handleCampaignSubmit(campaignForm, true);
        });
      }
    }
  }
  
  createCampaignForm(isEdit = false) {
    const mainContent = document.querySelector('.col-md-9');
    if (!mainContent) return;
    
    const formHTML = `
      <div class="card mb-4">
        <div class="card-header">
          <h3 class="card-title">${isEdit ? 'تعديل الحملة الإعلانية' : 'إنشاء حملة إعلانية جديدة'}</h3>
        </div>
        <div class="card-body">
          <form class="campaign-form">
            <div class="form-group mb-3">
              <label for="campaign-name">اسم الحملة</label>
              <input type="text" id="campaign-name" class="form-control" required>
            </div>
            
            <div class="form-group mb-3">
              <label>نوع الحملة</label>
              <div class="mt-2">
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="campaign-type" id="type-ad" value="ad" checked>
                  <label class="form-check-label" for="type-ad">إعلان</label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="campaign-type" id="type-survey" value="survey">
                  <label class="form-check-label" for="type-survey">استبيان</label>
                </div>
              </div>
            </div>
            
            <div class="form-group mb-3">
              <label for="campaign-description">وصف الحملة</label>
              <textarea id="campaign-description" class="form-control" rows="3" required></textarea>
            </div>
            
            <div class="form-group mb-3">
              <label for="campaign-budget">الميزانية (ر.س)</label>
              <input type="number" id="campaign-budget" class="form-control" min="1000" step="100" value="5000" required>
              <small class="text-muted">الحد الأدنى للميزانية هو 1000 ر.س</small>
            </div>
            
            <div class="form-group mb-3">
              <label>الجمهور المستهدف المتوقع: <span id="audience-reach">500,000</span> مستخدم</label>
            </div>
            
            <div class="form-group mb-3">
              <label>استهداف الجمهور</label>
              <div class="mt-2">
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="targeting" id="targeting-all" value="all" checked>
                  <label class="form-check-label" for="targeting-all">جميع المستخدمين</label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="targeting" id="targeting-men" value="men">
                  <label class="form-check-label" for="targeting-men">الرجال فقط</label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="targeting" id="targeting-women" value="women">
                  <label class="form-check-label" for="targeting-women">النساء فقط</label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="targeting" id="targeting-custom" value="custom">
                  <label class="form-check-label" for="targeting-custom">تخصيص</label>
                </div>
              </div>
            </div>
            
            <div id="custom-targeting-fields" style="display: none;">
              <div class="card mb-3 p-3">
                <div class="form-group mb-3">
                  <label>الفئة العمرية</label>
                  <div class="row">
                    <div class="col-md-6">
                      <label for="age-min">من</label>
                      <select id="age-min" class="form-control">
                        <option value="18">18</option>
                        <option value="25" selected>25</option>
                        <option value="35">35</option>
                        <option value="45">45</option>
                      </select>
                    </div>
                    <div class="col-md-6">
                      <label for="age-max">إلى</label>
                      <select id="age-max" class="form-control">
                        <option value="24">24</option>
                        <option value="34">34</option>
                        <option value="44" selected>44</option>
                        <option value="65">65+</option>
                      </select>
                    </div>
                  </div>
                </div>
                
                <div class="form-group mb-3">
                  <label>المناطق</label>
                  <div class="mt-2">
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" name="regions" id="region-riyadh" value="riyadh" checked>
                      <label class="form-check-label" for="region-riyadh">الرياض</label>
                    </div>
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" name="regions" id="region-jeddah" value="jeddah" checked>
                      <label class="form-check-label" for="region-jeddah">جدة</label>
                    </div>
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" name="regions" id="region-dammam" value="dammam">
                      <label class="form-check-label" for="region-dammam">الدمام</label>
                    </div>
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" name="regions" id="region-all" value="all">
                      <label class="form-check-label" for="region-all">جميع المناطق</label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div class="form-group mb-3">
              <label for="campaign-creative">محتوى الإعلان</label>
              <div class="input-group">
                <input type="file" id="campaign-creative" class="form-control" ${isEdit ? '' : 'required'}>
                <button class="btn btn-outline" type="button">استعراض</button>
              </div>
              <small class="text-muted">يمكنك رفع صور بصيغة JPG أو PNG أو GIF، أو ملفات فيديو بصيغة MP4</small>
            </div>
            
            <div class="form-group mb-3">
              <label for="campaign-url">رابط الوجهة (اختياري)</label>
              <input type="url" id="campaign-url" class="form-control" placeholder="https://example.com">
            </div>
            
            <div class="form-group mb-3">
              <label>فئات الإعلان</label>
              <div class="mt-2">
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" name="categories" id="category-auto" value="auto">
                  <label class="form-check-label" for="category-auto">السيارات</label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" name="categories" id="category-tech" value="tech">
                  <label class="form-check-label" for="category-tech">التقنية</label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" name="categories" id="category-finance" value="finance">
                  <label class="form-check-label" for="category-finance">الخدمات المالية</label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" name="categories" id="category-retail" value="retail">
                  <label class="form-check-label" for="category-retail">التجزئة والتسوق</label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" name="categories" id="category-other" value="other">
                  <label class="form-check-label" for="category-other">أخرى</label>
                </div>
              </div>
            </div>
            
            <div class="text-center mt-4">
              <button type="submit" class="btn btn-primary">${isEdit ? 'حفظ التغييرات' : 'إنشاء الحملة'}</button>
              <a href="advertiser-dashboard.html" class="btn btn-outline">إلغاء</a>
            </div>
          </form>
        </div>
      </div>
    `;
    
    mainContent.innerHTML = formHTML;
  }
  
  populateCampaignForm(campaignName) {
    // For MVP, we'll use mock data
    const mockCampaigns = {
      'عروض السيارات الجديدة': {
        type: 'ad',
        description: 'حملة إعلانية لعروض السيارات الجديدة تستهدف الرجال من 25-45 سنة في الرياض وجدة',
        budget: 10000,
        targeting: 'custom',
        ageMin: 25,
        ageMax: 45,
        regions: ['riyadh', 'jeddah'],
        categories: ['auto']
      },
      'استبيان عادات التسوق': {
        type: 'survey',
        description: 'استبيان لمعرفة عادات التسوق لدى النساء من 18-35 سنة في جميع مناطق المملكة',
        budget: 5000,
        targeting: 'women',
        categories: ['retail']
      },
      'عروض الخدمات المصرفية': {
        type: 'ad',
        description: 'حملة إعلانية للخدمات المصرفية تستهدف الرجال والنساء من 30-50 سنة في المدن الرئيسية',
        budget: 8000,
        targeting: 'all',
        categories: ['finance']
      }
    };
    
    // Get campaign data
    const campaign = mockCampaigns[campaignName];
    if (!campaign) return;
    
    // Populate form fields
    document.getElementById('campaign-name').value = campaignName;
    document.getElementById('campaign-description').value = campaign.description;
    document.getElementById('campaign-budget').value = campaign.budget;
    
    // Update audience reach
    document.getElementById('audience-reach').textContent = (campaign.budget * 100).toLocaleString('ar-SA');
    
    // Set campaign type
    document.querySelector(`input[name="campaign-type"][value="${campaign.type}"]`).checked = true;
    
    // Set targeting
    document.querySelector(`input[name="targeting"][value="${campaign.targeting}"]`).checked = true;
    
    // Show custom targeting fields if needed
    if (campaign.targeting === 'custom') {
      document.getElementById('custom-targeting-fields').style.display = 'block';
      
      // Set age range
      if (campaign.ageMin) document.getElementById('age-min').value = campaign.ageMin;
      if (campaign.ageMax) document.getElementById('age-max').value = campaign.ageMax;
      
      // Set regions
      if (campaign.regions) {
        campaign.regions.forEach(region => {
          const checkbox = document.getElementById(`region-${region}`);
          if (checkbox) checkbox.checked = true;
        });
      }
    }
    
    // Set categories
    if (campaign.categories) {
      campaign.categories.forEach(category => {
        const checkbox = document.getElementById(`category-${category}`);
        if (checkbox) checkbox.checked = true;
      });
    }
  }
  
  handleCampaignSubmit(form, isEdit = false) {
    // Validate form
    let isValid = true;
    const requiredFields = form.querySelectorAll('[required]');
    
    requiredFields.forEach(field => {
      if (!field.value.trim()) {
        field.classList.add('is-invalid');
        isValid = false;
      } else {
        field.classList.remove('is-invalid');
      }
    });
    
    if (isValid) {
      // Simulate form submission
      const submitButton = form.querySelector('button[type="submit"]');
      const originalText = submitButton.textContent;
      submitButton.textContent = isEdit ? 'جاري الحفظ...' : 'جاري الإنشاء...';
      submitButton.disabled = true;
      
      // Simulate API call delay
      setTimeout(() => {
        // Redirect to dashboard with success message
        window.location.href = 'advertiser-dashboard.html?success=true';
      }, 2000);
    }
  }
  
  showSuccessNotification(message) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = 'success-notification';
    notification.innerHTML = `
      <div class="success-content">
        <i class="fas fa-check-circle"></i>
        <p>${message}</p>
      </div>
    `;
    
    // Add styles
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.backgroundColor = 'var(--success)';
    notification.style.color = 'white';
    notification.style.padding = '15px 20px';
    notification.style.borderRadius = 'var(--radius-md)';
    notification.style.boxShadow = 'var(--shadow-md)';
    notification.style.zIndex = '1001';
    notification.style.transform = 'translateX(120%)';
    notification.style.transition = 'transform 0.3s ease';
    
    // RTL support
    if (document.querySelector('html').getAttribute('dir') === 'rtl') {
      notification.style.right = 'auto';
      notification.style.left = '20px';
      notification.style.transform = 'translateX(-120%)';
    }
    
    // Add to body
    document.body.appendChild(notification);
    
    // Show notification
    setTimeout(() => {
      notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Hide and remove after 3 seconds
    setTimeout(() => {
      notification.style.transform = document.querySelector('html').getAttribute('dir') === 'rtl' ? 
        'translateX(-120%)' : 'translateX(120%)';
      setTimeout(() => {
        if (notification.parentNode) {
          notification.parentNode.removeChild(notification);
        }
      }, 300);
    }, 3000);
  }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new CampaignManagement();
});
