// Bushra MVP - Absher Integration Component

/**
 * Absher Integration Component
 * Simulates integration with Saudi Arabia's Absher system for the MVP
 */
class AbsherIntegration {
  constructor() {
    this.init();
  }
  
  init() {
    // Find all Absher login buttons
    const absherButtons = document.querySelectorAll('.absher-button');
    
    // Add event listeners to all Absher buttons
    absherButtons.forEach(button => {
      button.addEventListener('click', (e) => {
        e.preventDefault();
        this.showLoginModal();
      });
    });
  }
  
  showLoginModal() {
    // Create modal if it doesn't exist
    if (!document.getElementById('absher-login-modal')) {
      this.createLoginModal();
    } else {
      document.getElementById('absher-login-modal').style.display = 'block';
    }
  }
  
  createLoginModal() {
    const modalHTML = `
      <div id="absher-login-modal" class="modal">
        <div class="modal-content">
          <span class="close">&times;</span>
          <div class="text-center mb-4">
            <img src="images/absher-logo.png" alt="Absher Logo" style="height: 60px;">
            <h3 class="mt-3">تسجيل الدخول باستخدام أبشر</h3>
          </div>
          <form id="absher-login-form">
            <div class="form-group">
              <label for="national-id">رقم الهوية الوطنية</label>
              <input type="text" id="national-id" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="absher-password">كلمة المرور</label>
              <input type="password" id="absher-password" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="verification-code">رمز التحقق</label>
              <div class="d-flex">
                <input type="text" id="verification-code" class="form-control" required>
                <button type="button" class="btn btn-outline ms-2" id="send-code-btn">إرسال الرمز</button>
              </div>
            </div>
            <div class="text-center mt-4">
              <button type="submit" class="btn btn-primary">تسجيل الدخول</button>
            </div>
          </form>
          <div class="text-center mt-3">
            <p class="text-muted">هذا محاكاة لتسجيل الدخول بأبشر للأغراض التجريبية فقط</p>
            <p class="text-muted">لن يتم مشاركة بياناتك الحساسة مع أي جهة</p>
          </div>
        </div>
      </div>
    `;
    
    // Append modal to body
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    // Add event listeners
    const modal = document.getElementById('absher-login-modal');
    const closeBtn = modal.querySelector('.close');
    const form = document.getElementById('absher-login-form');
    const sendCodeBtn = document.getElementById('send-code-btn');
    
    // Close button
    closeBtn.addEventListener('click', () => {
      modal.style.display = 'none';
    });
    
    // Close when clicking outside
    window.addEventListener('click', (event) => {
      if (event.target === modal) {
        modal.style.display = 'none';
      }
    });
    
    // Send verification code
    if (sendCodeBtn) {
      sendCodeBtn.addEventListener('click', () => {
        const nationalId = document.getElementById('national-id').value;
        if (nationalId) {
          sendCodeBtn.textContent = 'تم الإرسال';
          sendCodeBtn.disabled = true;
          
          // Re-enable after 30 seconds
          setTimeout(() => {
            sendCodeBtn.textContent = 'إرسال الرمز';
            sendCodeBtn.disabled = false;
          }, 30000);
        } else {
          alert('يرجى إدخال رقم الهوية الوطنية أولاً');
        }
      });
    }
    
    // Form submission
    if (form) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const nationalId = document.getElementById('national-id').value;
        const password = document.getElementById('absher-password').value;
        const verificationCode = document.getElementById('verification-code').value;
        
        if (nationalId && password && verificationCode) {
          // Simulate authentication
          const submitButton = form.querySelector('button[type="submit"]');
          submitButton.textContent = 'جاري تسجيل الدخول...';
          submitButton.disabled = true;
          
          // Simulate API call delay
          setTimeout(() => {
            // For MVP, always succeed
            this.handleSuccessfulLogin({
              name: 'محمد عبدالله',
              id: nationalId,
              city: 'الرياض',
              age: 32,
              gender: 'ذكر'
            });
            
            // Hide modal
            modal.style.display = 'none';
          }, 2000);
        }
      });
    }
    
    // Show the modal
    modal.style.display = 'block';
  }
  
  handleSuccessfulLogin(userData) {
    // Store user data in localStorage (for MVP only)
    localStorage.setItem('bushra_user', JSON.stringify(userData));
    
    // Dispatch login event
    const loginEvent = new CustomEvent('absher:login', { detail: userData });
    document.dispatchEvent(loginEvent);
    
    // Redirect to dashboard
    window.location.href = 'dashboard.html';
  }
  
  // Static method to check if user is logged in
  static isLoggedIn() {
    return localStorage.getItem('bushra_user') !== null;
  }
  
  // Static method to get current user data
  static getCurrentUser() {
    const userData = localStorage.getItem('bushra_user');
    return userData ? JSON.parse(userData) : null;
  }
  
  // Static method to logout
  static logout() {
    localStorage.removeItem('bushra_user');
    window.location.href = 'index.html';
  }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new AbsherIntegration();
  
  // Add logout functionality to logout buttons
  const logoutButtons = document.querySelectorAll('.btn-outline:contains("تسجيل الخروج")');
  logoutButtons.forEach(button => {
    button.addEventListener('click', (e) => {
      e.preventDefault();
      AbsherIntegration.logout();
    });
  });
  
  // Redirect to landing page if trying to access dashboard without login
  if (window.location.pathname.includes('dashboard.html') && !AbsherIntegration.isLoggedIn()) {
    window.location.href = 'index.html';
  }
});
