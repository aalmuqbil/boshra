// JavaScript for Merchant Campaign Creation Page
// This file implements the audience targeting features for the merchant campaign creation page

document.addEventListener('DOMContentLoaded', function() {
    // Initialize audience targeting components
    initializeAudienceTargeting();
    
    // Initialize demographic selectors
    initializeDemographicSelectors();
    
    // Initialize behavioral targeting
    initializeBehavioralTargeting();
    
    // Initialize audience size calculator
    initializeAudienceSizeCalculator();
});

// Initialize audience targeting components
function initializeAudienceTargeting() {
    // Age range sliders
    const ageMinSlider = document.getElementById('age-min');
    const ageMaxSlider = document.getElementById('age-max');
    const ageMinValue = document.getElementById('age-min-value');
    const ageMaxValue = document.getElementById('age-max-value');
    
    if (ageMinSlider && ageMaxSlider) {
        ageMinSlider.addEventListener('input', function() {
            if (parseInt(ageMinSlider.value) > parseInt(ageMaxSlider.value)) {
                ageMaxSlider.value = ageMinSlider.value;
                ageMaxValue.textContent = ageMaxSlider.value;
            }
            ageMinValue.textContent = ageMinSlider.value;
            updateAudienceSize();
        });
        
        ageMaxSlider.addEventListener('input', function() {
            if (parseInt(ageMaxSlider.value) < parseInt(ageMinSlider.value)) {
                ageMinSlider.value = ageMaxSlider.value;
                ageMinValue.textContent = ageMinSlider.value;
            }
            ageMaxValue.textContent = ageMaxSlider.value;
            updateAudienceSize();
        });
    }
    
    // Gender selection
    const genderMale = document.getElementById('gender-male');
    const genderFemale = document.getElementById('gender-female');
    
    if (genderMale && genderFemale) {
        genderMale.addEventListener('change', updateAudienceSize);
        genderFemale.addEventListener('change', updateAudienceSize);
    }
}

// Initialize demographic selectors
function initializeDemographicSelectors() {
    // City selection
    const cityAll = document.getElementById('city-all');
    const cityCheckboxes = document.querySelectorAll('.city-selector .form-check-input:not(#city-all)');
    
    if (cityAll) {
        cityAll.addEventListener('change', function() {
            cityCheckboxes.forEach(checkbox => {
                checkbox.checked = false;
                checkbox.disabled = cityAll.checked;
            });
            updateAudienceSize();
        });
        
        cityCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                if (checkbox.checked) {
                    cityAll.checked = false;
                }
                updateAudienceSize();
            });
        });
    }
    
    // Absher data integration simulation
    simulateAbsherDataIntegration();
}

// Initialize behavioral targeting
function initializeBehavioralTargeting() {
    // Interest selection
    const interestCheckboxes = document.querySelectorAll('[id^="interest-"]');
    
    interestCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateAudienceSize);
    });
    
    // Behavior selection
    const behaviorCheckboxes = document.querySelectorAll('[id^="behavior-"]');
    
    behaviorCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateAudienceSize);
    });
}

// Initialize audience size calculator
function initializeAudienceSizeCalculator() {
    // Initial calculation
    updateAudienceSize();
    
    // Update audience description
    updateAudienceDescription();
}

// Update audience size based on targeting criteria
function updateAudienceSize() {
    // Get targeting criteria
    const ageMin = parseInt(document.getElementById('age-min').value);
    const ageMax = parseInt(document.getElementById('age-max').value);
    const genderMale = document.getElementById('gender-male').checked;
    const genderFemale = document.getElementById('gender-female').checked;
    const cityAll = document.getElementById('city-all').checked;
    const selectedCities = document.querySelectorAll('.city-selector .form-check-input:checked:not(#city-all)').length;
    const selectedInterests = document.querySelectorAll('[id^="interest-"]:checked').length;
    const selectedBehaviors = document.querySelectorAll('[id^="behavior-"]:checked').length;
    
    // Base audience size (total Absher users)
    let baseAudienceSize = 28000000; // 28 million Absher users
    
    // Apply age filter
    const ageRange = ageMax - ageMin + 1;
    const totalAgeRange = 65 - 13 + 1;
    const ageMultiplier = ageRange / totalAgeRange;
    
    // Apply gender filter
    let genderMultiplier = 1;
    if (genderMale && !genderFemale) {
        genderMultiplier = 0.55; // 55% male
    } else if (!genderMale && genderFemale) {
        genderMultiplier = 0.45; // 45% female
    }
    
    // Apply location filter
    let locationMultiplier = 1;
    if (!cityAll) {
        // Each city represents approximately 10% of the population
        locationMultiplier = Math.min(selectedCities * 0.1, 1);
        if (selectedCities === 0) {
            locationMultiplier = 0.01; // Very small audience if no city selected
        }
    }
    
    // Apply interest filter
    let interestMultiplier = 1;
    if (selectedInterests > 0) {
        // Each interest represents approximately 20% of the population
        // Multiple interests have overlapping users
        interestMultiplier = Math.min(selectedInterests * 0.2, 1);
    }
    
    // Apply behavior filter
    let behaviorMultiplier = 1;
    if (selectedBehaviors > 0) {
        // Each behavior represents approximately 25% of the population
        // Multiple behaviors have overlapping users
        behaviorMultiplier = Math.min(selectedBehaviors * 0.25, 1);
    }
    
    // Calculate final audience size
    let audienceSize = baseAudienceSize * ageMultiplier * genderMultiplier * locationMultiplier * interestMultiplier * behaviorMultiplier;
    
    // Round to nearest thousand
    audienceSize = Math.round(audienceSize / 1000) * 1000;
    
    // Update UI
    const audienceSizeElement = document.querySelector('.audience-size');
    if (audienceSizeElement) {
        audienceSizeElement.textContent = '~' + formatNumber(audienceSize) + ' مستخدم';
    }
    
    // Update audience description
    updateAudienceDescription();
    
    return audienceSize;
}

// Update audience description based on targeting criteria
function updateAudienceDescription() {
    const audienceDescription = document.querySelector('.audience-description');
    if (!audienceDescription) return;
    
    const genderMale = document.getElementById('gender-male').checked;
    const genderFemale = document.getElementById('gender-female').checked;
    const ageMin = document.getElementById('age-min').value;
    const ageMax = document.getElementById('age-max').value;
    const cityAll = document.getElementById('city-all').checked;
    
    let genderText = '';
    if (genderMale && genderFemale) {
        genderText = 'الذكور والإناث';
    } else if (genderMale) {
        genderText = 'الذكور';
    } else if (genderFemale) {
        genderText = 'الإناث';
    }
    
    let cityText = cityAll ? 'جميع المدن' : 'المدن المحددة';
    
    // Get selected interests
    const selectedInterests = Array.from(document.querySelectorAll('[id^="interest-"]:checked'))
        .map(checkbox => checkbox.nextElementSibling.textContent.trim());
    
    let interestsText = '';
    if (selectedInterests.length > 0) {
        interestsText = selectedInterests.join(' و');
    }
    
    audienceDescription.textContent = `جمهورك المستهدف يشمل ${genderText} من سن ${ageMin} إلى ${ageMax} في ${cityText}${interestsText ? '، مع اهتمام ب' + interestsText : ''}.`;
}

// Simulate Absher data integration
function simulateAbsherDataIntegration() {
    console.log('Simulating Absher data integration for audience targeting');
    
    // Demographic data available through Absher
    const absherDemographicData = {
        ageDistribution: {
            '13-17': 0.12, // 12% of users
            '18-24': 0.18, // 18% of users
            '25-34': 0.25, // 25% of users
            '35-44': 0.20, // 20% of users
            '45-54': 0.15, // 15% of users
            '55-65': 0.10  // 10% of users
        },
        genderDistribution: {
            male: 0.55,    // 55% of users
            female: 0.45   // 45% of users
        },
        locationDistribution: {
            riyadh: 0.25,      // 25% of users
            jeddah: 0.18,      // 18% of users
            mecca: 0.12,       // 12% of users
            medina: 0.08,      // 8% of users
            dammam: 0.07,      // 7% of users
            taif: 0.05,        // 5% of users
            abha: 0.04,        // 4% of users
            tabuk: 0.03,       // 3% of users
            buraidah: 0.03,    // 3% of users
            other: 0.15        // 15% of users
        },
        educationDistribution: {
            highSchool: 0.30,      // 30% of users
            bachelors: 0.40,       // 40% of users
            masters: 0.15,         // 15% of users
            doctorate: 0.05,       // 5% of users
            other: 0.10            // 10% of users
        },
        incomeDistribution: {
            low: 0.25,             // 25% of users
            mediumLow: 0.30,       // 30% of users
            medium: 0.25,          // 25% of users
            mediumHigh: 0.15,      // 15% of users
            high: 0.05             // 5% of users
        }
    };
    
    // Store data for audience targeting calculations
    window.absherData = absherDemographicData;
}

// Format number with thousands separator
function formatNumber(number) {
    return new Intl.NumberFormat('ar-SA').format(number);
}
