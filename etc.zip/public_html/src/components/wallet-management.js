// Bushra MVP - Wallet Management Component

/**
 * Wallet Management Component
 * Handles user wallet functionality including balance display and withdrawals
 */
class WalletManagement {
  constructor() {
    this.init();
  }
  
  init() {
    // Check if we're on a user dashboard or wallet page
    if (!window.location.pathname.includes('dashboard.html') && 
        !window.location.pathname.includes('wallet.html')) {
      return;
    }
    
    // Initialize wallet functionality
    this.initializeWalletDisplay();
    this.initializeWithdrawalButtons();
  }
  
  initializeWalletDisplay() {
    // Get user data from localStorage
    const userData = JSON.parse(localStorage.getItem('bushra_user') || '{}');
    
    // Set initial balance if not set
    if (!userData.balance) {
      userData.balance = '75.50';
      localStorage.setItem('bushra_user', JSON.stringify(userData));
    }
    
    // Update earnings display
    const earningsAmount = document.querySelector('.earnings-amount');
    if (earningsAmount) {
      earningsAmount.textContent = userData.balance + ' ر.س';
    }
    
    // Update timestamp
    const earningsLabel = document.querySelector('.earnings-label:contains("تم تحديثه")');
    if (earningsLabel) {
      const now = new Date();
      const timeString = now.toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' });
      earningsLabel.textContent = `تم تحديثه: اليوم، ${timeString}`;
    }
  }
  
  initializeWithdrawalButtons() {
    // Find all withdrawal buttons
    const withdrawalButtons = document.querySelectorAll('.btn:contains("سحب الرصيد")');
    
    // Add event listeners
    withdrawalButtons.forEach(button => {
      button.addEventListener('click', (e) => {
        e.preventDefault();
        this.showWithdrawalModal();
      });
    });
  }
  
  showWithdrawalModal() {
    // Get user data from localStorage
    const userData = JSON.parse(localStorage.getItem('bushra_user') || '{}');
    const balance = parseFloat(userData.balance || '0');
    
    // Create modal if it doesn't exist
    if (!document.getElementById('withdrawal-modal')) {
      this.createWithdrawalModal(balance);
    } else {
      // Update balance in existing modal
      const balanceElement = document.querySelector('#withdrawal-modal .current-balance');
      if (balanceElement) {
        balanceElement.textContent = balance.toFixed(2) + ' ر.س';
      }
      
      // Update max withdrawal amount
      const amountInput = document.getElementById('withdrawal-amount');
      if (amountInput) {
        amountInput.max = balance;
      }
      
      // Show modal
      document.getElementById('withdrawal-modal').style.display = 'block';
    }
  }
  
  createWithdrawalModal(balance) {
    const modalHTML = `
      <div id="withdrawal-modal" class="modal">
        <div class="modal-content">
          <span class="close">&times;</span>
          <h3>سحب الرصيد</h3>
          <div class="my-4">
            <p>رصيدك الحالي: <strong class="current-balance">${balance.toFixed(2)} ر.س</strong></p>
            <form id="withdrawal-form">
              <div class="form-group">
                <label for="withdrawal-amount">المبلغ المراد سحبه</label>
                <input type="number" id="withdrawal-amount" class="form-control" min="50" max="${balance}" value="50" required>
                <small class="text-muted">الحد الأدنى للسحب هو 50 ر.س</small>
              </div>
              <div class="form-group mt-3">
                <label for="bank-account">الحساب المصرفي</label>
                <select id="bank-account" class="form-control" required>
                  <option value="">اختر الحساب المصرفي</option>
                  <option value="alahli">البنك الأهلي السعودي</option>
                  <option value="alrajhi">مصرف الراجحي</option>
                  <option value="samba">سامبا</option>
                  <option value="riyadh">بنك الرياض</option>
                </select>
              </div>
              <div class="form-group mt-3">
                <label for="account-number">رقم الحساب (IBAN)</label>
                <input type="text" id="account-number" class="form-control" placeholder="SA0000000000000000000000" required>
              </div>
              <div class="text-center mt-4">
                <button type="submit" class="btn btn-primary">تأكيد السحب</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    `;
    
    // Append modal to body
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    // Add event listeners
    const modal = document.getElementById('withdrawal-modal');
    const closeBtn = modal.querySelector('.close');
    const form = document.getElementById('withdrawal-form');
    
    // Close button
    closeBtn.addEventListener('click', () => {
      modal.style.display = 'none';
    });
    
    // Close when clicking outside
    window.addEventListener('click', (event) => {
      if (event.target === modal) {
        modal.style.display = 'none';
      }
    });
    
    // Form submission
    if (form) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        this.handleWithdrawalSubmit(form);
      });
    }
    
    // Show the modal
    modal.style.display = 'block';
  }
  
  handleWithdrawalSubmit(form) {
    const amount = parseFloat(document.getElementById('withdrawal-amount').value);
    const bank = document.getElementById('bank-account').value;
    const accountNumber = document.getElementById('account-number').value;
    
    // Get user data from localStorage
    const userData = JSON.parse(localStorage.getItem('bushra_user') || '{}');
    const balance = parseFloat(userData.balance || '0');
    
    // Validate form
    if (amount >= 50 && amount <= balance && bank && accountNumber) {
      // Simulate withdrawal
      const submitButton = form.querySelector('button[type="submit"]');
      submitButton.textContent = 'جاري تنفيذ العملية...';
      submitButton.disabled = true;
      
      // Simulate API call delay
      setTimeout(() => {
        // Update user balance
        const newBalance = (balance - amount).toFixed(2);
        userData.balance = newBalance;
        localStorage.setItem('bushra_user', JSON.stringify(userData));
        
        // Update UI
        const earningsAmount = document.querySelector('.earnings-amount');
        if (earningsAmount) {
          earningsAmount.textContent = newBalance + ' ر.س';
        }
        
        // Hide modal
        document.getElementById('withdrawal-modal').style.display = 'none';
        
        // Show success notification
        this.showSuccessNotification(`تم تقديم طلب سحب بمبلغ ${amount.toFixed(2)} ر.س إلى حسابك المصرفي بنجاح. سيتم تنفيذ العملية خلال 1-3 أيام عمل.`);
        
        // Add transaction to history if on wallet page
        this.addWithdrawalToHistory(amount, bank);
      }, 2000);
    } else {
      // Show validation errors
      if (amount < 50 || amount > balance) {
        const amountInput = document.getElementById('withdrawal-amount');
        amountInput.classList.add('is-invalid');
        
        // Create error message if it doesn't exist
        let errorMessage = form.querySelector('.amount-error');
        if (!errorMessage) {
          errorMessage = document.createElement('div');
          errorMessage.className = 'error-message text-danger mt-2 amount-error';
          errorMessage.textContent = amount < 50 ? 
            'الحد الأدنى للسحب هو 50 ر.س' : 
            'المبلغ المطلوب أكبر من رصيدك الحالي';
          amountInput.parentNode.appendChild(errorMessage);
        } else {
          errorMessage.textContent = amount < 50 ? 
            'الحد الأدنى للسحب هو 50 ر.س' : 
            'المبلغ المطلوب أكبر من رصيدك الحالي';
        }
      }
      
      if (!bank) {
        document.getElementById('bank-account').classList.add('is-invalid');
      }
      
      if (!accountNumber) {
        document.getElementById('account-number').classList.add('is-invalid');
      }
    }
  }
  
  addWithdrawalToHistory(amount, bank) {
    const transactionTable = document.querySelector('.table tbody');
    if (!transactionTable) return;
    
    // Get bank name
    const bankSelect = document.getElementById('bank-account');
    const bankName = bankSelect.options[bankSelect.selectedIndex].text;
    
    // Create new transaction row
    const now = new Date();
    const dateString = now.toLocaleDateString('ar-SA');
    
    const newRow = document.createElement('tr');
    newRow.innerHTML = `
      <td>${dateString}</td>
      <td>سحب</td>
      <td>سحب إلى ${bankName}</td>
      <td class="text-danger">-${amount.toFixed(2)} ر.س</td>
    `;
    
    // Add to top of table
    transactionTable.insertBefore(newRow, transactionTable.firstChild);
  }
  
  showSuccessNotification(message) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = 'success-notification';
    notification.innerHTML = `
      <div class="success-content">
        <i class="fas fa-check-circle"></i>
        <p>${message}</p>
      </div>
    `;
    
    // Add styles
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.backgroundColor = 'var(--success)';
    notification.style.color = 'white';
    notification.style.padding = '15px 20px';
    notification.style.borderRadius = 'var(--radius-md)';
    notification.style.boxShadow = 'var(--shadow-md)';
    notification.style.zIndex = '1001';
    notification.style.transform = 'translateX(120%)';
    notification.style.transition = 'transform 0.3s ease';
    
    // RTL support
    if (document.querySelector('html').getAttribute('dir') === 'rtl') {
      notification.style.right = 'auto';
      notification.style.left = '20px';
      notification.style.transform = 'translateX(-120%)';
    }
    
    // Add to body
    document.body.appendChild(notification);
    
    // Show notification
    setTimeout(() => {
      notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Hide and remove after 5 seconds
    setTimeout(() => {
      notification.style.transform = document.querySelector('html').getAttribute('dir') === 'rtl' ? 
        'translateX(-120%)' : 'translateX(120%)';
      setTimeout(() => {
        if (notification.parentNode) {
          notification.parentNode.removeChild(notification);
        }
      }, 300);
    }, 5000);
  }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new WalletManagement();
});
