// Ad Campaign Creation Workflow
// This file implements the ad campaign creation workflow for the merchant campaign creation page

document.addEventListener('DOMContentLoaded', function() {
    // Initialize campaign type selection
    initializeCampaignTypeSelection();
    
    // Initialize wizard navigation
    initializeWizardNavigation();
    
    // Initialize ad content management
    initializeAdContentManagement();
    
    // Initialize budget and duration settings
    initializeBudgetSettings();
    
    // Initialize campaign review and launch
    initializeCampaignReview();
});

// Initialize campaign type selection
function initializeCampaignTypeSelection() {
    const campaignTypes = document.querySelectorAll('.campaign-type');
    
    campaignTypes.forEach(type => {
        type.addEventListener('click', function() {
            // Update selection UI
            campaignTypes.forEach(t => t.classList.remove('selected'));
            this.classList.add('selected');
            
            // Store selected campaign type
            const campaignType = this.getAttribute('data-type');
            window.selectedCampaignType = campaignType;
            
            // Show/hide content sections based on campaign type
            updateContentSections(campaignType);
            
            // Update campaign objective options based on type
            updateCampaignObjectives(campaignType);
        });
    });
}

// Update content sections based on campaign type
function updateContentSections(campaignType) {
    const adContentSection = document.getElementById('ad-content-section');
    const surveyContentSection = document.getElementById('survey-content-section');
    
    if (campaignType === 'survey') {
        adContentSection.style.display = 'none';
        surveyContentSection.style.display = 'block';
    } else {
        adContentSection.style.display = 'block';
        surveyContentSection.style.display = 'none';
    }
}

// Update campaign objective options based on type
function updateCampaignObjectives(campaignType) {
    const awarenessObjective = document.getElementById('objective-awareness');
    const considerationObjective = document.getElementById('objective-consideration');
    const conversionObjective = document.getElementById('objective-conversion');
    const feedbackObjective = document.getElementById('objective-feedback');
    
    // Reset all objectives
    awarenessObjective.disabled = false;
    considerationObjective.disabled = false;
    conversionObjective.disabled = false;
    feedbackObjective.disabled = false;
    
    // Set appropriate defaults and disable irrelevant objectives
    if (campaignType === 'ad') {
        awarenessObjective.checked = true;
        feedbackObjective.disabled = true;
    } else if (campaignType === 'awareness') {
        awarenessObjective.checked = true;
        conversionObjective.disabled = true;
    } else if (campaignType === 'survey') {
        feedbackObjective.checked = true;
        conversionObjective.disabled = true;
    }
}

// Initialize wizard navigation
function initializeWizardNavigation() {
    // Step 1 navigation
    const step1Next = document.getElementById('step-1-next');
    if (step1Next) {
        step1Next.addEventListener('click', function() {
            navigateToStep(1, 2);
        });
    }
    
    // Step 2 navigation
    const step2Prev = document.getElementById('step-2-prev');
    const step2Next = document.getElementById('step-2-next');
    
    if (step2Prev) {
        step2Prev.addEventListener('click', function() {
            navigateToStep(2, 1);
        });
    }
    
    if (step2Next) {
        step2Next.addEventListener('click', function() {
            if (validateStep2()) {
                navigateToStep(2, 3);
            }
        });
    }
    
    // Step 3 navigation
    const step3Prev = document.getElementById('step-3-prev');
    const step3Next = document.getElementById('step-3-next');
    
    if (step3Prev) {
        step3Prev.addEventListener('click', function() {
            navigateToStep(3, 2);
        });
    }
    
    if (step3Next) {
        step3Next.addEventListener('click', function() {
            navigateToStep(3, 4);
        });
    }
    
    // Step 4 navigation
    const step4Prev = document.getElementById('step-4-prev');
    const step4Next = document.getElementById('step-4-next');
    
    if (step4Prev) {
        step4Prev.addEventListener('click', function() {
            navigateToStep(4, 3);
        });
    }
    
    if (step4Next) {
        step4Next.addEventListener('click', function() {
            if (validateStep4()) {
                navigateToStep(4, 5);
            }
        });
    }
    
    // Step 5 navigation
    const step5Prev = document.getElementById('step-5-prev');
    const step5Next = document.getElementById('step-5-next');
    
    if (step5Prev) {
        step5Prev.addEventListener('click', function() {
            navigateToStep(5, 4);
        });
    }
    
    if (step5Next) {
        step5Next.addEventListener('click', function() {
            if (validateStep5()) {
                navigateToStep(5, 6);
                updateCampaignSummary();
            }
        });
    }
    
    // Step 6 navigation
    const step6Prev = document.getElementById('step-6-prev');
    
    if (step6Prev) {
        step6Prev.addEventListener('click', function() {
            navigateToStep(6, 5);
        });
    }
}

// Navigate to a specific step
function navigateToStep(currentStep, targetStep) {
    // Hide current step
    document.getElementById(`step-${currentStep}`).style.display = 'none';
    
    // Show target step
    document.getElementById(`step-${targetStep}`).style.display = 'block';
    
    // Update step status
    updateStepStatus(targetStep);
}

// Update step status in the wizard
function updateStepStatus(currentStep) {
    const steps = document.querySelectorAll('.wizard-step');
    
    steps.forEach((step, index) => {
        step.classList.remove('step-active', 'step-completed');
        
        if (index + 1 === currentStep) {
            step.classList.add('step-active');
        } else if (index + 1 < currentStep) {
            step.classList.add('step-completed');
        }
    });
}

// Validate step 2 (Campaign Details)
function validateStep2() {
    const campaignName = document.getElementById('campaign-name').value;
    const campaignDescription = document.getElementById('campaign-description').value;
    
    if (!campaignName) {
        alert('الرجاء إدخال اسم الحملة');
        return false;
    }
    
    if (!campaignDescription) {
        alert('الرجاء إدخال وصف الحملة');
        return false;
    }
    
    // Store campaign details
    window.campaignDetails = {
        name: campaignName,
        description: campaignDescription,
        objective: getSelectedObjective(),
        category: document.querySelector('select.form-control').value
    };
    
    return true;
}

// Get selected campaign objective
function getSelectedObjective() {
    const objectives = {
        'objective-awareness': 'زيادة الوعي بالعلامة التجارية',
        'objective-consideration': 'زيادة التفاعل مع المحتوى',
        'objective-conversion': 'زيادة التحويلات والمبيعات',
        'objective-feedback': 'جمع آراء وملاحظات المستخدمين'
    };
    
    for (const [id, text] of Object.entries(objectives)) {
        const radio = document.getElementById(id);
        if (radio && radio.checked) {
            return text;
        }
    }
    
    return '';
}

// Initialize ad content management
function initializeAdContentManagement() {
    // Content uploader
    const contentUploader = document.querySelector('.content-uploader');
    
    if (contentUploader) {
        contentUploader.addEventListener('click', function() {
            // Simulate file selection dialog
            alert('سيتم فتح نافذة اختيار الملفات في التطبيق النهائي');
            
            // For demo purposes, simulate a successful upload
            simulateFileUpload();
        });
    }
    
    // Initialize preview functionality
    initializeContentPreview();
}

// Simulate file upload
function simulateFileUpload() {
    const previewContent = document.querySelector('.preview-content');
    
    if (previewContent) {
        // Create a simulated preview
        previewContent.innerHTML = `
            <div style="width: 100%; height: 100%; background-color: #f0f0f0; display: flex; flex-direction: column; align-items: center; justify-content: center;">
                <div style="width: 100%; height: 70%; background-color: #e0e0e0; display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-image" style="font-size: 3rem; color: var(--primary);"></i>
                </div>
                <div style="padding: 1rem; text-align: center;">
                    <h3 style="margin: 0; font-size: 1rem;">عنوان الإعلان</h3>
                    <p style="margin: 0.5rem 0; font-size: 0.8rem; color: var(--text-muted);">وصف الإعلان يظهر هنا</p>
                </div>
            </div>
        `;
    }
}

// Initialize content preview
function initializeContentPreview() {
    // Ad title and description inputs
    const adTitle = document.querySelector('#ad-content-section .form-control[placeholder*="عنوان"]');
    const adDescription = document.querySelector('#ad-content-section textarea');
    
    if (adTitle && adDescription) {
        // Update preview when title changes
        adTitle.addEventListener('input', function() {
            updateAdPreview(adTitle.value, adDescription.value);
        });
        
        // Update preview when description changes
        adDescription.addEventListener('input', function() {
            updateAdPreview(adTitle.value, adDescription.value);
        });
    }
}

// Update ad preview
function updateAdPreview(title, description) {
    const previewContent = document.querySelector('.preview-content');
    
    if (previewContent && previewContent.querySelector('h3') && previewContent.querySelector('p')) {
        previewContent.querySelector('h3').textContent = title || 'عنوان الإعلان';
        previewContent.querySelector('p').textContent = description || 'وصف الإعلان يظهر هنا';
    }
}

// Validate step 4 (Content)
function validateStep4() {
    const campaignType = window.selectedCampaignType;
    
    if (campaignType === 'survey') {
        // Validate survey content
        return validateSurveyContent();
    } else {
        // Validate ad content
        return validateAdContent();
    }
}

// Validate ad content
function validateAdContent() {
    const adTitle = document.querySelector('#ad-content-section .form-control[placeholder*="عنوان"]');
    const adDescription = document.querySelector('#ad-content-section textarea');
    const adLink = document.querySelector('#ad-content-section .form-control[placeholder*="رابط"]');
    
    if (!adTitle || !adTitle.value) {
        alert('الرجاء إدخال عنوان الإعلان');
        return false;
    }
    
    if (!adDescription || !adDescription.value) {
        alert('الرجاء إدخال وصف الإعلان');
        return false;
    }
    
    // Store ad content
    window.adContent = {
        title: adTitle.value,
        description: adDescription.value,
        link: adLink ? adLink.value : ''
    };
    
    return true;
}

// Validate survey content
function validateSurveyContent() {
    const surveyTitle = document.querySelector('#survey-content-section .form-control[placeholder*="عنوان"]');
    const surveyDescription = document.querySelector('#survey-content-section textarea');
    
    if (!surveyTitle || !surveyTitle.value) {
        alert('الرجاء إدخال عنوان الاستبيان');
        return false;
    }
    
    if (!surveyDescription || !surveyDescription.value) {
        alert('الرجاء إدخال وصف الاستبيان');
        return false;
    }
    
    // Check if at least one question exists
    const questions = document.querySelectorAll('.survey-question');
    if (questions.length === 0) {
        alert('الرجاء إضافة سؤال واحد على الأقل');
        return false;
    }
    
    // Store survey content
    window.surveyContent = {
        title: surveyTitle.value,
        description: surveyDescription.value,
        questionCount: questions.length
    };
    
    return true;
}

// Initialize budget and duration settings
function initializeBudgetSettings() {
    // Budget slider
    const budgetSlider = document.getElementById('budget-slider');
    const budgetValue = document.getElementById('budget-value');
    
    if (budgetSlider && budgetValue) {
        budgetSlider.addEventListener('input', function() {
            budgetValue.textContent = formatCurrency(budgetSlider.value);
            updateBudgetMetrics(parseInt(budgetSlider.value));
        });
        
        // Initialize budget metrics
        updateBudgetMetrics(parseInt(budgetSlider.value || 1000));
    }
    
    // Budget inputs
    const totalBudgetInput = document.querySelector('.form-group:has(label:contains("الميزانية الإجمالية")) input');
    const dailyBudgetInput = document.querySelector('.form-group:has(label:contains("الميزانية اليومية")) input');
    
    if (totalBudgetInput && dailyBudgetInput) {
        // Sync total budget with slider
        totalBudgetInput.addEventListener('input', function() {
            if (budgetSlider) {
                budgetSlider.value = totalBudgetInput.value;
                budgetValue.textContent = formatCurrency(totalBudgetInput.value);
                updateBudgetMetrics(parseInt(totalBudgetInput.value));
            }
        });
        
        // Calculate daily budget based on total budget and duration
        totalBudgetInput.addEventListener('change', function() {
            calculateDailyBudget();
        });
        
        // Ensure daily budget doesn't exceed total budget
        dailyBudgetInput.addEventListener('change', function() {
            if (parseInt(dailyBudgetInput.value) > parseInt(totalBudgetInput.value)) {
                dailyBudgetInput.value = totalBudgetInput.value;
            }
        });
    }
    
    // Date inputs
    const startDateInput = document.querySelector('input[type="date"]:first-of-type');
    const endDateInput = document.querySelector('input[type="date"]:last-of-type');
    
    if (startDateInput && endDateInput) {
        // Set default dates
        const today = new Date();
        const fourDaysLater = new Date(today);
        fourDaysLater.setDate(today.getDate() + 4);
        
        startDateInput.valueAsDate = today;
        endDateInput.valueAsDate = fourDaysLater;
        
        // Ensure end date is after start date
        startDateInput.addEventListener('change', function() {
            if (startDateInput.valueAsDate > endDateInput.valueAsDate) {
                endDateInput.valueAsDate = startDateInput.valueAsDate;
            }
            calculateDailyBudget();
        });
        
        endDateInput.addEventListener('change', function() {
            if (endDateInput.valueAsDate < startDateInput.valueAsDate) {
                startDateInput.valueAsDate = endDateInput.valueAsDate;
            }
            calculateDailyBudget();
        });
    }
}

// Calculate daily budget based on total budget and campaign duration
function calculateDailyBudget() {
    const totalBudgetInput = document.querySelector('.form-group:has(label:contains("الميزانية الإجمالية")) input');
    const dailyBudgetInput = document.querySelector('.form-group:has(label:contains("الميزانية اليومية")) input');
    const startDateInput = document.querySelector('input[type="date"]:first-of-type');
    const endDateInput = document.querySelector('input[type="date"]:last-of-type');
    
    if (totalBudgetInput && dailyBudgetInput && startDateInput && endDateInput) {
        const totalBudget = parseInt(totalBudgetInput.value);
        const startDate = startDateInput.valueAsDate;
        const endDate = endDateInput.valueAsDate;
        
        if (totalBudget && startDate && endDate) {
            // Calculate number of days
            const campaignDays = Math.max(1, Math.round((endDate - startDate) / (1000 * 60 * 60 * 24)));
            
            // Calculate daily budget
            const dailyBudget = Math.ceil(totalBudget / campaignDays);
            
            // Update daily budget input
            dailyBudgetInput.value = dailyBudget;
        }
    }
}

// Update budget metrics based on total budget
function updateBudgetMetrics(budget) {
    const impressionsElement = document.querySelector('.budget-metrics .budget-metric:nth-child(1) .budget-metric-value');
    const engagementsElement = document.querySelector('.budget-metrics .budget-metric:nth-child(2) .budget-metric-value');
    const conversionsElement = document.querySelector('.budget-metrics .budget-metric:nth-child(3) .budget-metric-value');
    
    if (impressionsElement && engagementsElement && conversionsElement) {
        // Calculate metrics based on budget
        const impressions = Math.floor(budget * 10); // 10 impressions per 1 SAR
        const engagements = Math.floor(budget * 0.5); // 0.5 engagements per 1 SAR
        const conversions = Math.floor(budget * 0.05); // 0.05 conversions per 1 SAR
        
        // Update UI
        impressionsElement.textContent = formatNumber(impressions) + '+';
        engagementsElement.textContent = formatNumber(engagements) + '+';
        conversionsElement.textContent = formatNumber(conversions) + '+';
    }
}

// Validate step 5 (Budget and Duration)
function validateStep5() {
    const totalBudgetInput = document.querySelector('.form-group:has(label:contains("الميزانية الإجمالية")) input');
    const startDateInput = document.querySelector('input[type="date"]:first-of-type');
    const endDateInput = document.querySelector('input[type="date"]:last-of-type');
    
    if (!totalBudgetInput || !totalBudgetInput.value) {
        alert('الرجاء إدخال الميزانية الإجمالية');
        return false;
    }
    
    if (!startDateInput || !startDateInput.value) {
        alert('الرجاء إدخال تاريخ بدء الحملة');
        return false;
    }
    
    if (!endDateInput || !endDateInput.value) {
        alert('الرجاء إدخال تاريخ انتهاء الحملة');
        return false;
    }
    
    // Store budget and duration
    window.budgetSettings = {
        totalBudget: totalBudgetInput.value,
        dailyBudget: document.querySelector('.form-group:has(label:contains("الميزانية اليومية")) input').value,
        startDate: startDateInput.value,
        endDate: endDateInput.value,
        allDay: document.getElementById('schedule-all').checked
    };
    
    return true;
}

// Initialize campaign review and launch
function initializeCampaignReview() {
    // Terms checkbox
    const termsCheck = document.getElementById('terms-check');
    const launchButton = document.querySelector('.launch-button');
    
    if (termsCheck && launchButton) {
        termsCheck.addEventListener('change', function() {
            launchButton.disabled = !termsCheck.checked;
        });
        
        // Launch button
        launchButton.addEventListener('click', function() {
            if (!termsCheck.checked) {
                alert('الرجاء الموافقة على الشروط والأحكام');
                return;
            }
            
            // Launch campaign
            launchCampaign();
        });
    }
}

// Update campaign summary
function updateCampaignSummary() {
    // Campaign type
    const campaignTypeValue = document.querySelector('.summary-row:has(.summary-label:contains("نوع الحملة")) .summary-value');
    if (campaignTypeValue) {
        const campaignTypeMap = {
            'ad': 'إعلان',
            'awareness': 'حملة توعوية',
            'survey': 'استبيان'
        };
        campaignTypeValue.textContent = campaignTypeMap[window.selectedCampaignType] || 'إعلان';
    }
    
    // Campaign details
    if (window.campaignDetails) {
        const nameValue = document.querySelector('.summary-row:has(.summary-label:contains("اسم الحملة")) .summary-value');
        const objectiveValue = document.querySelector('.summary-row:has(.summary-label:contains("الهدف")) .summary-value');
        const categoryValue = document.querySelector('.summary-row:has(.summary-label:contains("الفئة")) .summary-value');
        
        if (nameValue) nameValue.textContent = window.campaignDetails.name;
        if (objectiveValue) objectiveValue.textContent = window.campaignDetails.objective;
        if (categoryValue) categoryValue.textContent = getCategoryName(window.campaignDetails.category);
    }
    
    // Audience targeting
    const ageValue = document.querySelector('.summary-row:has(.summary-label:contains("الفئة العمرية")) .summary-value');
    const genderValue = document.querySelector('.summary-row:has(.summary-label:contains("الجنس")) .summary-value');
    const citiesValue = document.querySelector('.summary-row:has(.summary-label:contains("المدن")) .summary-value');
    const interestsValue = document.querySelector('.summary-row:has(.summary-label:contains("الاهتمامات")) .summary-value');
    const audienceSizeValue = document.querySelector('.summary-row:has(.summary-label:contains("حجم الجمهور")) .summary-value');
    
    if (ageValue) {
        const ageMin = document.getElementById('age-min').value;
        const ageMax = document.getElementById('age-max').value;
        ageValue.textContent = `${ageMin} - ${ageMax} سنة`;
    }
    
    if (genderValue) {
        const genderMale = document.getElementById('gender-male').checked;
        const genderFemale = document.getElementById('gender-female').checked;
        
        if (genderMale && genderFemale) {
            genderValue.textContent = 'ذكر، أنثى';
        } else if (genderMale) {
            genderValue.textContent = 'ذكر';
        } else if (genderFemale) {
            genderValue.textContent = 'أنثى';
        }
    }
    
    if (citiesValue) {
        const cityAll = document.getElementById('city-all').checked;
        
        if (cityAll) {
            citiesValue.textContent = 'جميع المدن';
        } else {
            const selectedCities = Array.from(document.querySelectorAll('.city-selector .form-check-input:checked:not(#city-all)'))
                .map(checkbox => checkbox.nextElementSibling.textContent.trim());
            
            citiesValue.textContent = selectedCities.length > 0 ? selectedCities.join('، ') : 'لم يتم تحديد مدن';
        }
    }
    
    if (interestsValue) {
        const selectedInterests = Array.from(document.querySelectorAll('[id^="interest-"]:checked'))
            .map(checkbox => checkbox.nextElementSibling.textContent.trim());
        
        interestsValue.textContent = selectedInterests.length > 0 ? selectedInterests.join('، ') : 'لم يتم تحديد اهتمامات';
    }
    
    if (audienceSizeValue) {
        audienceSizeValue.textContent = document.querySelector('.audience-size').textContent;
    }
    
    // Budget and duration
    if (window.budgetSettings) {
        const totalBudgetValue = document.querySelector('.summary-row:has(.summary-label:contains("الميزانية الإجمالية")) .summary-value');
        const dailyBudgetValue = document.querySelector('.summary-row:has(.summary-label:contains("الميزانية اليومية")) .summary-value');
        const startDateValue = document.querySelector('.summary-row:has(.summary-label:contains("تاريخ البدء")) .summary-value');
        const endDateValue = document.querySelector('.summary-row:has(.summary-label:contains("تاريخ الانتهاء")) .summary-value');
        const durationValue = document.querySelector('.summary-row:has(.summary-label:contains("المدة")) .summary-value');
        
        if (totalBudgetValue) totalBudgetValue.textContent = formatCurrency(window.budgetSettings.totalBudget);
        if (dailyBudgetValue) dailyBudgetValue.textContent = formatCurrency(window.budgetSettings.dailyBudget);
        if (startDateValue) startDateValue.textContent = formatDate(window.budgetSettings.startDate);
        if (endDateValue) endDateValue.textContent = formatDate(window.budgetSettings.endDate);
        
        if (durationValue) {
            const startDate = new Date(window.budgetSettings.startDate);
            const endDate = new Date(window.budgetSettings.endDate);
            const days = Math.round((endDate - startDate) / (1000 * 60 * 60 * 24));
            durationValue.textContent = `${days} أيام`;
        }
    }
}

// Launch campaign
function launchCampaign() {
    // Collect all campaign data
    const campaignData = {
        type: window.selectedCampaignType,
        details: window.campaignDetails,
        audience: {
            ageMin: document.getElementById('age-min').value,
            ageMax: document.getElementById('age-max').value,
            genderMale: document.getElementById('gender-male').checked,
            genderFemale: document.getElementById('gender-female').checked,
            cityAll: document.getElementById('city-all').checked,
            selectedCities: Array.from(document.querySelectorAll('.city-selector .form-check-input:checked:not(#city-all)'))
                .map(checkbox => checkbox.nextElementSibling.textContent.trim()),
            selectedInterests: Array.from(document.querySelectorAll('[id^="interest-"]:checked'))
                .map(checkbox => checkbox.nextElementSibling.textContent.trim()),
            selectedBehaviors: Array.from(document.querySelectorAll('[id^="behavior-"]:checked'))
                .map(checkbox => checkbox.nextElementSibling.textContent.trim()),
            audienceSize: document.querySelector('.audience-size').textContent
        },
        content: window.selectedCampaignType === 'survey' ? window.surveyContent : window.adContent,
        budget: window.budgetSettings
    };
    
    // Log campaign data
    console.log('Campaign launched:', campaignData);
    
    // Show success message
    alert('تم إطلاق الحملة بنجاح! سيتم مراجعتها وتفعيلها خلال 24 ساعة.');
    
    // Redirect to dashboard
    window.location.href = 'dashboard.html';
}

// Helper function to get category name
function getCategoryName(categoryValue) {
    const categories = {
        'retail': 'تجارة التجزئة',
        'food': 'مطاعم وأغذية',
        'tech': 'تقنية ومنتجات إلكترونية',
        'fashion': 'أزياء وملابس',
        'health': 'صحة ولياقة',
        'education': 'تعليم وتدريب',
        'entertainment': 'ترفيه',
        'travel': 'سفر وسياحة',
        'automotive': 'سيارات',
        'finance': 'خدمات مالية',
        'realestate': 'عقارات',
        'other': 'أخرى'
    };
    
    return categories[categoryValue] || 'غير محدد';
}

// Helper function to format currency
function formatCurrency(value) {
    return new Intl.NumberFormat('ar-SA', { style: 'decimal' }).format(value) + ' ريال سعودي';
}

// Helper function to format number
function formatNumber(value) {
    return new Intl.NumberFormat('ar-SA').format(value);
}

// Helper function to format date
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-SA', { year: 'numeric', month: '2-digit', day: '2-digit' });
}
