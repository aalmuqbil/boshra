// Bushra MVP - Industry-specific Ads and Surveys Component

/**
 * Industry Ads Component
 * Handles industry-specific ads and surveys functionality
 */
class IndustryAdsComponent {
  constructor() {
    this.apiService = window.apiService;
    this.industryRewards = {
      airline: {
        adView: 4.50,
        surveyCompletion: 15.00,
        specialAction: 35.00
      },
      telecom: {
        adView: 3.50,
        surveyCompletion: 12.00,
        specialAction: 25.00
      },
      government: {
        adView: 2.50,
        surveyCompletion: 10.00,
        specialAction: 15.00
      },
      automotive: {
        adView: 4.00,
        surveyCompletion: 20.00,
        specialAction: 35.00
      }
    };
    
    this.init();
  }
  
  init() {
    // Check if we're on the ads-surveys page
    if (!window.location.pathname.includes('ads-surveys.html')) {
      return;
    }
    
    // Initialize event listeners
    this.initializeFilters();
    this.initializeAdInteractions();
    this.initializeSurveyInteractions();
  }
  
  initializeFilters() {
    // Industry filters
    const industryFilters = document.querySelectorAll('[id^="filter-"]');
    industryFilters.forEach(filter => {
      filter.addEventListener('change', () => {
        this.applyFilters();
      });
    });
    
    // Content type filters
    const contentFilters = document.querySelectorAll('#filter-ads, #filter-surveys');
    contentFilters.forEach(filter => {
      filter.addEventListener('change', () => {
        this.applyFilters();
      });
    });
    
    // Reward filters
    const rewardFilters = document.querySelectorAll('[name="reward-filter"]');
    rewardFilters.forEach(filter => {
      filter.addEventListener('change', () => {
        this.applyFilters();
      });
    });
    
    // Filter button
    const filterButton = document.querySelector('.btn-outline.btn-block');
    if (filterButton) {
      filterButton.addEventListener('click', (e) => {
        e.preventDefault();
        this.applyFilters();
      });
    }
  }
  
  applyFilters() {
    // Get selected industries
    const selectedIndustries = [];
    if (document.getElementById('filter-airline').checked) selectedIndustries.push('airline-section');
    if (document.getElementById('filter-telecom').checked) selectedIndustries.push('telecom-section');
    if (document.getElementById('filter-government').checked) selectedIndustries.push('government-section');
    if (document.getElementById('filter-automotive').checked) selectedIndustries.push('automotive-section');
    
    // Get content types
    const showAds = document.getElementById('filter-ads').checked;
    const showSurveys = document.getElementById('filter-surveys').checked;
    
    // Get reward filter
    const highRewardsFirst = document.getElementById('reward-high').checked;
    
    // Apply industry filters
    const industrySections = document.querySelectorAll('.industry-section');
    industrySections.forEach(section => {
      if (selectedIndustries.includes(section.id)) {
        section.style.display = 'block';
      } else {
        section.style.display = 'none';
      }
    });
    
    // Apply content type filters
    const adCards = document.querySelectorAll('.ad-card');
    adCards.forEach(card => {
      if (showAds && card.dataset.adType === 'ad') {
        card.style.display = 'block';
      } else {
        card.style.display = 'none';
      }
    });
    
    const surveyCards = document.querySelectorAll('.survey-card');
    surveyCards.forEach(card => {
      if (showSurveys && card.dataset.adType === 'survey') {
        card.style.display = 'block';
      } else {
        card.style.display = 'none';
      }
    });
    
    // Apply reward sorting if needed
    if (highRewardsFirst) {
      this.sortByReward();
    }
  }
  
  sortByReward() {
    // This is a simplified version - in a real implementation, 
    // we would reorder the elements based on reward value
    const sections = document.querySelectorAll('.industry-section');
    sections.forEach(section => {
      const adGrid = section.querySelector('.ad-grid');
      if (adGrid) {
        const cards = Array.from(adGrid.querySelectorAll('.ad-card'));
        cards.sort((a, b) => {
          const rewardA = parseFloat(a.querySelector('.ad-card-reward').textContent);
          const rewardB = parseFloat(b.querySelector('.ad-card-reward').textContent);
          return rewardB - rewardA; // Sort in descending order
        });
        
        // Remove existing cards
        cards.forEach(card => card.remove());
        
        // Add sorted cards
        cards.forEach(card => adGrid.appendChild(card));
      }
    });
  }
  
  initializeAdInteractions() {
    // Add event listeners to ad buttons
    document.addEventListener('click', (e) => {
      if (e.target.matches('.ad-card .btn')) {
        e.preventDefault();
        
        const adCard = e.target.closest('.ad-card');
        const adId = adCard.dataset.adId;
        const adTitle = adCard.querySelector('.ad-card-title').textContent;
        const adReward = adCard.querySelector('.ad-card-reward').textContent;
        
        // Determine industry from ad ID
        let industry = 'general';
        if (adId.startsWith('saudia')) {
          industry = 'airline';
        } else if (adId.startsWith('stc')) {
          industry = 'telecom';
        } else if (adId.startsWith('moc')) {
          industry = 'government';
        } else if (adId.includes('changan') || adId.includes('mg')) {
          industry = 'automotive';
        }
        
        this.showAdViewModal(adId, adTitle, adReward, industry);
      }
    });
  }
  
  initializeSurveyInteractions() {
    // Add event listeners to survey buttons
    document.addEventListener('click', (e) => {
      if (e.target.matches('.survey-card .btn')) {
        e.preventDefault();
        
        const surveyCard = e.target.closest('.survey-card');
        const surveyId = surveyCard.dataset.adId;
        const surveyTitle = surveyCard.querySelector('.survey-title').textContent;
        const surveyReward = surveyCard.querySelector('.survey-reward').textContent;
        
        // Determine industry from survey ID
        let industry = 'general';
        if (surveyId.includes('saudia')) {
          industry = 'airline';
        } else if (surveyId.includes('stc')) {
          industry = 'telecom';
        } else if (surveyId.includes('moc')) {
          industry = 'government';
        } else if (surveyId.includes('chinese-cars')) {
          industry = 'automotive';
        }
        
        this.showSurveyModal(surveyId, surveyTitle, surveyReward, industry);
      }
    });
  }
  
  showAdViewModal(adId, adTitle, adReward, industry) {
    // Create or update modal
    let modal = document.getElementById('ad-view-modal');
    
    if (!modal) {
      // Create modal if it doesn't exist
      modal = document.createElement('div');
      modal.id = 'ad-view-modal';
      modal.className = 'modal';
      
      modal.innerHTML = `
        <div class="modal-content">
          <span class="close">&times;</span>
          <h3 id="ad-title">${adTitle}</h3>
          <div class="ad-content text-center my-4">
            <img src="images/${adId}.png" alt="Ad Content" style="max-width: 100%;">
          </div>
          <div class="text-center">
            <p>يرجى مشاهدة الإعلان بالكامل للحصول على <span id="ad-reward">${adReward}</span></p>
            <div class="progress-bar-container mt-3 mb-3">
              <div id="ad-progress" class="progress-bar" style="width: 0%;"></div>
            </div>
            <button id="confirm-view-btn" class="btn btn-primary" disabled>تأكيد المشاهدة</button>
          </div>
        </div>
      `;
      
      document.body.appendChild(modal);
      
      // Add close button functionality
      modal.querySelector('.close').addEventListener('click', () => {
        modal.style.display = 'none';
      });
      
      // Close when clicking outside
      window.addEventListener('click', (event) => {
        if (event.target === modal) {
          modal.style.display = 'none';
        }
      });
    } else {
      // Update existing modal
      modal.querySelector('#ad-title').textContent = adTitle;
      modal.querySelector('#ad-reward').textContent = adReward;
      modal.querySelector('.ad-content img').src = `images/${adId}.png`;
      modal.querySelector('#ad-progress').style.width = '0%';
      modal.querySelector('#confirm-view-btn').disabled = true;
    }
    
    // Show modal
    modal.style.display = 'block';
    
    // Simulate ad progress
    let progress = 0;
    const progressBar = document.getElementById('ad-progress');
    const confirmButton = document.getElementById('confirm-view-btn');
    
    const progressInterval = setInterval(() => {
      progress += 5;
      progressBar.style.width = progress + '%';
      
      if (progress >= 100) {
        clearInterval(progressInterval);
        confirmButton.disabled = false;
        
        // Add event listener to confirm button
        confirmButton.onclick = async () => {
          // Get user data
          const userData = JSON.parse(localStorage.getItem('bushra_user') || '{}');
          
          // For MVP, we'll simulate the API call
          const reward = this.industryRewards[industry].adView;
          
          // Update user balance
          userData.balance = (parseFloat(userData.balance) + reward).toFixed(2);
          localStorage.setItem('bushra_user', JSON.stringify(userData));
          
          // Update UI
          const earningsAmount = document.querySelector('.earnings-amount');
          if (earningsAmount) {
            earningsAmount.textContent = userData.balance + ' ر.س';
          }
          
          // Show success notification
          this.showNotification(`تم إضافة ${reward.toFixed(2)} ر.س إلى رصيدك!`, 'success');
          
          // Hide modal
          modal.style.display = 'none';
        };
      }
    }, 500);
  }
  
  showSurveyModal(surveyId, surveyTitle, surveyReward, industry) {
    // Create survey questions based on industry
    let questions = [];
    
    if (industry === 'airline') {
      questions = [
        {
          id: 'q1',
          text: 'كم مرة تسافر سنوياً على متن الخطوط السعودية؟',
          type: 'radio',
          options: ['لا أسافر على متنها', '1-2 مرات', '3-5 مرات', 'أكثر من 5 مرات']
        },
        {
          id: 'q2',
          text: 'ما هي أهم العوامل التي تؤثر على اختيارك لشركة الطيران؟',
          type: 'checkbox',
          options: ['السعر', 'مواعيد الرحلات', 'الخدمة على متن الطائرة', 'برنامج الولاء', 'سمعة الشركة']
        },
        {
          id: 'q3',
          text: 'كيف تقيم تجربتك مع الخطوط السعودية؟',
          type: 'radio',
          options: ['ممتازة', 'جيدة', 'متوسطة', 'سيئة']
        }
      ];
    } else if (industry === 'telecom') {
      questions = [
        {
          id: 'q1',
          text: 'ما هو مزود خدمة الاتصالات الرئيسي الخاص بك؟',
          type: 'radio',
          options: ['STC', 'موبايلي', 'زين', 'آخر']
        },
        {
          id: 'q2',
          text: 'ما هي الخدمات التي تستخدمها من مزود الاتصالات الخاص بك؟',
          type: 'checkbox',
          options: ['الجوال', 'الإنترنت المنزلي', 'التلفزيون', 'الخدمات السحابية']
        },
        {
          id: 'q3',
          text: 'كيف تقيم جودة خدمة الإنترنت المقدمة؟',
          type: 'radio',
          options: ['ممتازة', 'جيدة', 'متوسطة', 'سيئة']
        }
      ];
    } else if (industry === 'government') {
      questions = [
        {
          id: 'q1',
          text: 'هل استخدمت أي من الخدمات الإلكترونية لوزارة التجارة؟',
          type: 'radio',
          options: ['نعم، عدة مرات', 'نعم، مرة واحدة', 'لا، لم أستخدمها']
        },
        {
          id: 'q2',
          text: 'ما هي الخدمات التي تهمك من وزارة التجارة؟',
          type: 'checkbox',
          options: ['السجل التجاري', 'حماية المستهلك', 'العلامات التجارية', 'التراخيص', 'الاستثمار الأجنبي']
        },
        {
          id: 'q3',
          text: 'كيف تفضل التواصل مع وزارة التجارة؟',
          type: 'radio',
          options: ['المنصة الإلكترونية', 'التطبيق', 'مركز الاتصال', 'زيارة الفرع']
        }
      ];
    } else if (industry === 'automotive') {
      questions = [
        {
          id: 'q1',
          text: 'هل تمتلك أو سبق لك امتلاك سيارة صينية؟',
          type: 'radio',
          options: ['نعم، أمتلك حالياً', 'نعم، امتلكت سابقاً', 'لا، لم أمتلك أبداً']
        },
        {
          id: 'q2',
          text: 'ما هي العلامات التجارية الصينية للسيارات التي تعرفها؟',
          type: 'checkbox',
          options: ['شانجان', 'MG', 'جيلي', 'BYD', 'هافال', 'جريت وول', 'أخرى']
        },
        {
          id: 'q3',
          text: 'ما رأيك في جودة السيارات الصينية مقارنة بالسيارات اليابانية والكورية؟',
          type: 'radio',
          options: ['أفضل', 'مساوية', 'أقل قليلاً', 'أقل بكثير']
        },
        {
          id: 'q4',
          text: 'ما هو أهم عامل قد يدفعك لشراء سيارة صينية؟',
          type: 'radio',
          options: ['السعر المنخفض', 'التقنيات الحديثة', 'التصميم', 'الضمان الطويل', 'الاقتصاد في استهلاك الوقود']
        },
        {
          id: 'q5',
          text: 'ما هي أكبر مخاوفك بشأن السيارات الصينية؟',
          type: 'checkbox',
          options: ['جودة التصنيع', 'قطع الغيار', 'خدمات ما بعد البيع', 'قيمة إعادة البيع', 'السلامة']
        }
      ];
    }
    
    // Create or update modal
    let modal = document.getElementById('survey-modal');
    
    if (!modal) {
      // Create modal if it doesn't exist
      modal = document.createElement('div');
      modal.id = 'survey-modal';
      modal.className = 'modal';
      
      // Create HTML for questions
      let questionsHTML = '';
      questions.forEach((question, index) => {
        questionsHTML += `
          <div class="form-group mt-3">
            <label>${index + 1}. ${question.text}</label>
            <div class="mt-2">
        `;
        
        if (question.type === 'radio') {
          question.options.forEach((option, optIndex) => {
            questionsHTML += `
              <div class="form-check">
                <input class="form-check-input" type="radio" name="${question.id}" id="${question.id}-${optIndex}" value="${option}">
                <label class="form-check-label" for="${question.id}-${optIndex}">${option}</label>
              </div>
            `;
          });
        } else if (question.type === 'checkbox') {
          question.options.forEach((option, optIndex) => {
            questionsHTML += `
              <div class="form-check">
                <input class="form-check-input" type="checkbox" name="${question.id}" id="${question.id}-${optIndex}" value="${option}">
                <label class="form-check-label" for="${question.id}-${optIndex}">${option}</label>
              </div>
            `;
          });
        }
        
        questionsHTML += `
            </div>
          </div>
        `;
      });
      
      modal.innerHTML = `
        <div class="modal-content">
          <span class="close">&times;</span>
          <h3 id="survey-title">${surveyTitle}</h3>
          <p class="text-center">أكمل هذا الاستبيان للحصول على <span id="survey-reward">${surveyReward}</span></p>
          <div class="survey-content my-4">
            <form id="survey-form">
              ${questionsHTML}
              <div class="text-center mt-4">
                <button type="submit" class="btn btn-primary">إرسال الاستبيان</button>
              </div>
            </form>
          </div>
        </div>
      `;
      
      document.body.appendChild(modal);
      
      // Add close button functionality
      modal.querySelector('.close').addEventListener('click', () => {
        modal.style.display = 'none';
      });
      
      // Close when clicking outside
      window.addEventListener('click', (event) => {
        if (event.target === modal) {
          modal.style.display = 'none';
        }
      });
    } else {
      // Update existing modal
      modal.querySelector('#survey-title').textContent = surveyTitle;
      modal.querySelector('#survey-reward').textContent = surveyReward;
      
      // Update questions
      const surveyContent = modal.querySelector('.survey-content');
      let questionsHTML = '';
      questions.forEach((question, index) => {
        questionsHTML += `
          <div class="form-group mt-3">
            <label>${index + 1}. ${question.text}</label>
            <div class="mt-2">
        `;
        
        if (question.type === 'radio') {
          question.options.forEach((option, optIndex) => {
            questionsHTML += `
              <div class="form-check">
                <input class="form-check-input" type="radio" name="${question.id}" id="${question.id}-${optIndex}" value="${option}">
                <label class="form-check-label" for="${question.id}-${optIndex}">${option}</label>
              </div>
            `;
          });
        } else if (question.type === 'checkbox') {
          question.options.forEach((option, optIndex) => {
            questionsHTML += `
              <div class="form-check">
                <input class="form-check-input" type="checkbox" name="${question.id}" id="${question.id}-${optIndex}" value="${option}">
                <label class="form-check-label" for="${question.id}-${optIndex}">${option}</label>
              </div>
            `;
          });
        }
        
        questionsHTML += `
            </div>
          </div>
        `;
      });
      
      surveyContent.innerHTML = `
        <form id="survey-form">
          ${questionsHTML}
          <div class="text-center mt-4">
            <button type="submit" class="btn btn-primary">إرسال الاستبيان</button>
          </div>
        </form>
      `;
    }
    
    // Show modal
    modal.style.display = 'block';
    
    // Handle form submission
    const surveyForm = document.getElementById('survey-form');
    surveyForm.onsubmit = async (e) => {
      e.preventDefault();
      
      // Validate form - ensure at least one option is selected for each question
      let isValid = true;
      let unansweredQuestions = [];
      
      questions.forEach(question => {
        const answered = document.querySelector(`input[name="${question.id}"]:checked`);
        if (!answered) {
          isValid = false;
          unansweredQuestions.push(question.id);
        }
      });
      
      if (!isValid) {
        alert('يرجى الإجابة على جميع الأسئلة');
        return;
      }
      
      // Collect responses
      const formData = new FormData(surveyForm);
      const responses = {};
      
      for (let [key, value] of formData.entries()) {
        if (responses[key]) {
          if (!Array.isArray(responses[key])) {
            responses[key] = [responses[key]];
          }
          responses[key].push(value);
        } else {
          responses[key] = value;
        }
      }
      
      // Get user data
      const userData = JSON.parse(localStorage.getItem('bushra_user') || '{}');
      
      // For MVP, we'll simulate the API call
      const reward = this.industryRewards[industry].surveyCompletion;
      
      // Update user balance
      userData.balance = (parseFloat(userData.balance) + reward).toFixed(2);
      localStorage.setItem('bushra_user', JSON.stringify(userData));
      
      // Update UI
      const earningsAmount = document.querySelector('.earnings-amount');
      if (earningsAmount) {
        earningsAmount.textContent = userData.balance + ' ر.س';
      }
      
      // Show success notification
      this.showNotification(`تم إضافة ${reward.toFixed(2)} ر.س إلى رصيدك!`, 'success');
      
      // Hide modal
      modal.style.display = 'none';
    };
  }
  
  showNotification(message, type = 'success') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}-notification`;
    notification.innerHTML = `
      <div class="notification-content">
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
        <p>${message}</p>
      </div>
    `;
    
    // Add styles
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.backgroundColor = type === 'success' ? 'var(--success)' : 'var(--danger)';
    notification.style.color = 'white';
    notification.style.padding = '15px 20px';
    notification.style.borderRadius = 'var(--radius-md)';
    notification.style.boxShadow = 'var(--shadow-md)';
    notification.style.zIndex = '1001';
    notification.style.transform = 'translateX(120%)';
    notification.style.transition = 'transform 0.3s ease';
    
    // RTL support
    if (document.querySelector('html').getAttribute('dir') === 'rtl') {
      notification.style.right = 'auto';
      notification.style.left = '20px';
      notification.style.transform = 'translateX(-120%)';
    }
    
    // Add to body
    document.body.appendChild(notification);
    
    // Show notification
    setTimeout(() => {
      notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Hide and remove after 5 seconds
    setTimeout(() => {
      notification.style.transform = document.querySelector('html').getAttribute('dir') === 'rtl' ? 
        'translateX(-120%)' : 'translateX(120%)';
      setTimeout(() => {
        if (notification.parentNode) {
          notification.parentNode.removeChild(notification);
        }
      }, 300);
    }, 5000);
  }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new IndustryAdsComponent();
});
