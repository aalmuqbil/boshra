// Bushra MVP - Ad Management Component

/**
 * Ad Management Component
 * Handles ad display, interaction, and reward functionality
 */
class AdManagement {
  constructor() {
    this.init();
  }
  
  init() {
    // Find all ad interaction buttons
    const adButtons = document.querySelectorAll('.ad-card .btn');
    
    // Add event listeners to all ad buttons
    adButtons.forEach(button => {
      button.addEventListener('click', (e) => {
        e.preventDefault();
        
        const adCard = button.closest('.ad-card');
        const adTitle = adCard.querySelector('.ad-card-title').textContent;
        const adReward = adCard.querySelector('.ad-card-reward').textContent;
        
        // Determine if this is an ad or survey
        if (button.textContent.includes('مشاهدة')) {
          this.showAdModal(adTitle, adReward);
        } else if (button.textContent.includes('المشاركة')) {
          this.showSurveyModal(adTitle, adReward);
        }
      });
    });
  }
  
  showAdModal(adTitle, adReward) {
    // Create modal if it doesn't exist
    if (!document.getElementById('ad-view-modal')) {
      this.createAdModal();
    }
    
    // Update modal content
    const modal = document.getElementById('ad-view-modal');
    modal.querySelector('#ad-title').textContent = adTitle;
    modal.querySelector('#ad-reward').textContent = adReward;
    
    // Show modal
    modal.style.display = 'block';
    
    // Start ad progress
    this.simulateAdViewing(adReward);
  }
  
  createAdModal() {
    const modalHTML = `
      <div id="ad-view-modal" class="modal">
        <div class="modal-content">
          <span class="close">&times;</span>
          <h3 id="ad-title">عنوان الإعلان</h3>
          <div class="ad-content text-center my-4">
            <img src="images/ad-placeholder.png" alt="Ad Content" style="max-width: 100%;">
          </div>
          <div class="text-center">
            <p>يرجى مشاهدة الإعلان بالكامل للحصول على <span id="ad-reward">2.00 ر.س</span></p>
            <div class="progress-bar-container mt-3 mb-3">
              <div id="ad-progress" class="progress-bar" style="width: 0%;"></div>
            </div>
            <button id="confirm-view-btn" class="btn btn-primary" disabled>تأكيد المشاهدة</button>
          </div>
        </div>
      </div>
    `;
    
    // Append modal to body
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    // Add event listeners
    const modal = document.getElementById('ad-view-modal');
    const closeBtn = modal.querySelector('.close');
    
    // Close button
    closeBtn.addEventListener('click', () => {
      modal.style.display = 'none';
    });
    
    // Close when clicking outside
    window.addEventListener('click', (event) => {
      if (event.target === modal) {
        modal.style.display = 'none';
      }
    });
  }
  
  simulateAdViewing(adReward) {
    const progressBar = document.getElementById('ad-progress');
    const confirmButton = document.getElementById('confirm-view-btn');
    let progress = 0;
    
    // Reset progress
    progressBar.style.width = '0%';
    confirmButton.disabled = true;
    
    // Simulate ad progress
    const progressInterval = setInterval(() => {
      progress += 5;
      progressBar.style.width = progress + '%';
      
      if (progress >= 100) {
        clearInterval(progressInterval);
        confirmButton.disabled = false;
        
        // Add event listener to confirm button
        confirmButton.addEventListener('click', () => {
          // Hide modal
          document.getElementById('ad-view-modal').style.display = 'none';
          
          // Show reward notification
          this.showRewardNotification(adReward);
          
          // Update user balance
          this.updateUserBalance(adReward);
        });
      }
    }, 500); // 10 seconds total for 100% progress
  }
  
  showSurveyModal(surveyTitle, surveyReward) {
    // Create modal if it doesn't exist
    if (!document.getElementById('survey-modal')) {
      this.createSurveyModal();
    }
    
    // Update modal content
    const modal = document.getElementById('survey-modal');
    modal.querySelector('#survey-title').textContent = surveyTitle;
    modal.querySelector('#survey-reward').textContent = surveyReward;
    
    // Show modal
    modal.style.display = 'block';
    
    // Initialize survey form
    this.initializeSurveyForm(surveyReward);
  }
  
  createSurveyModal() {
    const modalHTML = `
      <div id="survey-modal" class="modal">
        <div class="modal-content">
          <span class="close">&times;</span>
          <h3 id="survey-title">عنوان الاستبيان</h3>
          <p class="text-center">أكمل هذا الاستبيان للحصول على <span id="survey-reward">10.00 ر.س</span></p>
          <div class="survey-content my-4">
            <form id="survey-form">
              <div class="form-group">
                <label>1. كم مرة تتسوق عبر الإنترنت شهرياً؟</label>
                <div class="mt-2">
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="q1" id="q1-1" value="1">
                    <label class="form-check-label" for="q1-1">لا أتسوق عبر الإنترنت</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="q1" id="q1-2" value="2">
                    <label class="form-check-label" for="q1-2">1-2 مرات</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="q1" id="q1-3" value="3">
                    <label class="form-check-label" for="q1-3">3-5 مرات</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="q1" id="q1-4" value="4">
                    <label class="form-check-label" for="q1-4">أكثر من 5 مرات</label>
                  </div>
                </div>
              </div>
              <div class="form-group mt-3">
                <label>2. ما هي منصات التسوق الإلكتروني التي تستخدمها؟</label>
                <div class="mt-2">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="q2" id="q2-1" value="noon">
                    <label class="form-check-label" for="q2-1">نون</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="q2" id="q2-2" value="amazon">
                    <label class="form-check-label" for="q2-2">أمازون</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="q2" id="q2-3" value="jarir">
                    <label class="form-check-label" for="q2-3">جرير</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="q2" id="q2-4" value="other">
                    <label class="form-check-label" for="q2-4">أخرى</label>
                  </div>
                </div>
              </div>
              <div class="form-group mt-3">
                <label>3. ما هي العوامل الأكثر أهمية بالنسبة لك عند التسوق عبر الإنترنت؟</label>
                <div class="mt-2">
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="q3" id="q3-1" value="price">
                    <label class="form-check-label" for="q3-1">السعر</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="q3" id="q3-2" value="quality">
                    <label class="form-check-label" for="q3-2">الجودة</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="q3" id="q3-3" value="delivery">
                    <label class="form-check-label" for="q3-3">سرعة التوصيل</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="q3" id="q3-4" value="reviews">
                    <label class="form-check-label" for="q3-4">تقييمات المستخدمين</label>
                  </div>
                </div>
              </div>
              <div class="text-center mt-4">
                <button type="submit" class="btn btn-primary">إرسال الاستبيان</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    `;
    
    // Append modal to body
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    // Add event listeners
    const modal = document.getElementById('survey-modal');
    const closeBtn = modal.querySelector('.close');
    
    // Close button
    closeBtn.addEventListener('click', () => {
      modal.style.display = 'none';
    });
    
    // Close when clicking outside
    window.addEventListener('click', (event) => {
      if (event.target === modal) {
        modal.style.display = 'none';
      }
    });
  }
  
  initializeSurveyForm(surveyReward) {
    const surveyForm = document.getElementById('survey-form');
    
    surveyForm.addEventListener('submit', (e) => {
      e.preventDefault();
      
      // Validate form
      let isValid = true;
      const radioGroups = ['q1', 'q3']; // Required radio button groups
      
      radioGroups.forEach(name => {
        const checkedRadio = surveyForm.querySelector(`input[name="${name}"]:checked`);
        if (!checkedRadio) {
          isValid = false;
          
          // Show validation error
          const groupLabel = surveyForm.querySelector(`label:contains("${name.replace('q', '')}")`);
          if (groupLabel) {
            groupLabel.classList.add('text-danger');
          }
        }
      });
      
      if (isValid) {
        // Hide modal
        document.getElementById('survey-modal').style.display = 'none';
        
        // Show reward notification
        this.showRewardNotification(surveyReward);
        
        // Update user balance
        this.updateUserBalance(surveyReward);
        
        // Store survey data (for MVP, just log to console)
        const formData = new FormData(surveyForm);
        const surveyData = {};
        for (let [key, value] of formData.entries()) {
          if (surveyData[key]) {
            if (!Array.isArray(surveyData[key])) {
              surveyData[key] = [surveyData[key]];
            }
            surveyData[key].push(value);
          } else {
            surveyData[key] = value;
          }
        }
        console.log('Survey data:', surveyData);
      } else {
        alert('يرجى الإجابة على جميع الأسئلة المطلوبة');
      }
    });
  }
  
  showRewardNotification(reward) {
    // Create notification element if it doesn't exist
    if (!document.querySelector('.reward-notification')) {
      const notification = document.createElement('div');
      notification.className = 'reward-notification';
      notification.innerHTML = `
        <div class="reward-content">
          <i class="fas fa-check-circle"></i>
          <p>تم إضافة <span class="reward-amount">${reward}</span> إلى رصيدك!</p>
        </div>
      `;
      
      // Add to body
      document.body.appendChild(notification);
    } else {
      // Update existing notification
      document.querySelector('.reward-notification .reward-amount').textContent = reward;
    }
    
    const notification = document.querySelector('.reward-notification');
    
    // Show notification
    setTimeout(() => {
      notification.classList.add('show');
    }, 100);
    
    // Hide and remove after 3 seconds
    setTimeout(() => {
      notification.classList.remove('show');
      setTimeout(() => {
        if (notification.parentNode) {
          notification.parentNode.removeChild(notification);
        }
      }, 300);
    }, 3000);
  }
  
  updateUserBalance(reward) {
    // Update earnings display if on dashboard
    const earningsAmount = document.querySelector('.earnings-amount');
    if (earningsAmount) {
      const currentAmount = parseFloat(earningsAmount.textContent.replace(' ر.س', ''));
      const rewardAmount = parseFloat(reward.replace(' ر.س', ''));
      const newAmount = (currentAmount + rewardAmount).toFixed(2);
      earningsAmount.textContent = newAmount + ' ر.س';
      
      // Update timestamp
      const earningsLabel = document.querySelector('.earnings-label:contains("تم تحديثه")');
      if (earningsLabel) {
        const now = new Date();
        const timeString = now.toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' });
        earningsLabel.textContent = `تم تحديثه: اليوم، ${timeString}`;
      }
      
      // Store updated balance in localStorage
      const userData = JSON.parse(localStorage.getItem('bushra_user') || '{}');
      userData.balance = newAmount;
      localStorage.setItem('bushra_user', JSON.stringify(userData));
    }
  }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  // Only initialize on dashboard page
  if (window.location.pathname.includes('dashboard.html')) {
    new AdManagement();
  }
});
