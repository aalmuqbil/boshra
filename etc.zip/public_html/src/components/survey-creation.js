// Survey Creation Functionality
// This file implements the survey creation functionality for the merchant campaign creation page

document.addEventListener('DOMContentLoaded', function() {
    // Initialize survey builder
    initializeSurveyBuilder();
    
    // Initialize question type selector
    initializeQuestionTypeSelector();
    
    // Initialize question actions
    initializeQuestionActions();
});

// Initialize survey builder
function initializeSurveyBuilder() {
    // Add question button
    const addQuestionButton = document.querySelector('.add-question');
    
    if (addQuestionButton) {
        addQuestionButton.addEventListener('click', function() {
            addNewQuestion();
        });
    }
    
    // Add option button
    const addOptionButton = document.querySelector('.add-option');
    
    if (addOptionButton) {
        addOptionButton.addEventListener('click', function() {
            addNewOption(this.closest('.survey-question'));
        });
    }
}

// Add new question to survey
function addNewQuestion() {
    const surveyBuilder = document.querySelector('.survey-builder');
    const addQuestionButton = document.querySelector('.add-question');
    
    if (surveyBuilder && addQuestionButton) {
        // Create new question element
        const newQuestion = document.createElement('div');
        newQuestion.className = 'survey-question';
        
        // Generate unique ID for the question
        const questionId = 'question-' + Date.now();
        newQuestion.id = questionId;
        
        // Set question content
        newQuestion.innerHTML = `
            <div class="question-header">
                <div class="question-type">سؤال متعدد الخيارات</div>
                <div class="question-actions">
                    <button class="question-action" data-action="move"><i class="fas fa-arrows-alt"></i></button>
                    <button class="question-action" data-action="duplicate"><i class="fas fa-copy"></i></button>
                    <button class="question-action" data-action="delete"><i class="fas fa-trash"></i></button>
                </div>
            </div>
            
            <div class="form-group">
                <input type="text" class="form-control" placeholder="أدخل نص السؤال هنا">
            </div>
            
            <div class="option-list">
                <div class="option-item">
                    <input type="text" class="form-control option-input" placeholder="الخيار 1">
                    <button class="question-action" data-action="remove-option"><i class="fas fa-times"></i></button>
                </div>
                <div class="option-item">
                    <input type="text" class="form-control option-input" placeholder="الخيار 2">
                    <button class="question-action" data-action="remove-option"><i class="fas fa-times"></i></button>
                </div>
                
                <button class="add-option">
                    <i class="fas fa-plus"></i>
                    إضافة خيار
                </button>
            </div>
        `;
        
        // Insert new question before add button
        surveyBuilder.insertBefore(newQuestion, addQuestionButton);
        
        // Initialize question actions
        initializeQuestionActions(newQuestion);
        
        // Focus on question text
        newQuestion.querySelector('input[placeholder="أدخل نص السؤال هنا"]').focus();
        
        // Update question count
        updateQuestionCount();
    }
}

// Add new option to question
function addNewOption(questionElement) {
    if (questionElement) {
        const optionList = questionElement.querySelector('.option-list');
        const addOptionButton = questionElement.querySelector('.add-option');
        
        if (optionList && addOptionButton) {
            // Get current option count
            const optionCount = optionList.querySelectorAll('.option-item').length + 1;
            
            // Create new option element
            const newOption = document.createElement('div');
            newOption.className = 'option-item';
            
            // Set option content
            newOption.innerHTML = `
                <input type="text" class="form-control option-input" placeholder="الخيار ${optionCount}">
                <button class="question-action" data-action="remove-option"><i class="fas fa-times"></i></button>
            `;
            
            // Insert new option before add button
            optionList.insertBefore(newOption, addOptionButton);
            
            // Initialize option actions
            initializeOptionActions(newOption);
            
            // Focus on option text
            newOption.querySelector('input').focus();
        }
    }
}

// Initialize question type selector
function initializeQuestionTypeSelector() {
    // Question type dropdown (to be implemented in the future)
    // For now, we'll use the default multiple choice question type
}

// Initialize question actions
function initializeQuestionActions(container = document) {
    // Question action buttons
    const questionActions = container.querySelectorAll('.question-action[data-action]');
    
    questionActions.forEach(action => {
        const actionType = action.getAttribute('data-action');
        
        action.addEventListener('click', function(e) {
            e.preventDefault();
            
            const questionElement = this.closest('.survey-question');
            
            if (questionElement) {
                switch (actionType) {
                    case 'move':
                        // Move functionality would be implemented with drag-and-drop
                        alert('سيتم تفعيل خاصية السحب والإفلات في النسخة النهائية');
                        break;
                        
                    case 'duplicate':
                        duplicateQuestion(questionElement);
                        break;
                        
                    case 'delete':
                        deleteQuestion(questionElement);
                        break;
                        
                    case 'remove-option':
                        removeOption(this.closest('.option-item'));
                        break;
                }
            }
        });
    });
    
    // Initialize option actions
    const optionItems = container.querySelectorAll('.option-item');
    optionItems.forEach(option => {
        initializeOptionActions(option);
    });
    
    // Add option buttons
    const addOptionButtons = container.querySelectorAll('.add-option');
    
    addOptionButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            addNewOption(this.closest('.survey-question'));
        });
    });
}

// Initialize option actions
function initializeOptionActions(optionElement) {
    const removeButton = optionElement.querySelector('.question-action[data-action="remove-option"]');
    
    if (removeButton) {
        removeButton.addEventListener('click', function(e) {
            e.preventDefault();
            removeOption(optionElement);
        });
    }
}

// Duplicate question
function duplicateQuestion(questionElement) {
    if (questionElement) {
        // Create a clone of the question
        const clone = questionElement.cloneNode(true);
        
        // Generate new ID for the clone
        const newId = 'question-' + Date.now();
        clone.id = newId;
        
        // Insert clone after original
        questionElement.parentNode.insertBefore(clone, questionElement.nextSibling);
        
        // Initialize actions for the clone
        initializeQuestionActions(clone);
        
        // Update question count
        updateQuestionCount();
    }
}

// Delete question
function deleteQuestion(questionElement) {
    if (questionElement) {
        // Confirm deletion
        if (confirm('هل أنت متأكد من حذف هذا السؤال؟')) {
            // Remove question element
            questionElement.remove();
            
            // Update question count
            updateQuestionCount();
        }
    }
}

// Remove option
function removeOption(optionElement) {
    if (optionElement) {
        const questionElement = optionElement.closest('.survey-question');
        const optionList = questionElement.querySelector('.option-list');
        
        // Ensure we have at least two options
        if (optionList.querySelectorAll('.option-item').length > 2) {
            // Remove option element
            optionElement.remove();
            
            // Update option placeholders
            updateOptionPlaceholders(questionElement);
        } else {
            alert('يجب أن يحتوي السؤال على خيارين على الأقل');
        }
    }
}

// Update option placeholders
function updateOptionPlaceholders(questionElement) {
    if (questionElement) {
        const options = questionElement.querySelectorAll('.option-item input');
        
        options.forEach((option, index) => {
            option.placeholder = `الخيار ${index + 1}`;
        });
    }
}

// Update question count
function updateQuestionCount() {
    const questionCount = document.querySelectorAll('.survey-question').length;
    
    // Update survey content object if it exists
    if (window.surveyContent) {
        window.surveyContent.questionCount = questionCount;
    }
    
    return questionCount;
}

// Get survey data
function getSurveyData() {
    const surveyTitle = document.querySelector('#survey-content-section .form-control[placeholder*="عنوان"]').value;
    const surveyDescription = document.querySelector('#survey-content-section textarea').value;
    const questions = [];
    
    // Collect questions
    document.querySelectorAll('.survey-question').forEach((questionElement, questionIndex) => {
        const questionText = questionElement.querySelector('input[placeholder="أدخل نص السؤال هنا"]').value;
        const options = [];
        
        // Collect options
        questionElement.querySelectorAll('.option-item input').forEach((optionInput, optionIndex) => {
            options.push({
                id: `q${questionIndex + 1}_o${optionIndex + 1}`,
                text: optionInput.value
            });
        });
        
        questions.push({
            id: `q${questionIndex + 1}`,
            text: questionText,
            type: 'multiple_choice',
            options: options
        });
    });
    
    return {
        title: surveyTitle,
        description: surveyDescription,
        questionCount: questions.length,
        questions: questions
    };
}

// Validate survey
function validateSurvey() {
    const surveyTitle = document.querySelector('#survey-content-section .form-control[placeholder*="عنوان"]');
    const surveyDescription = document.querySelector('#survey-content-section textarea');
    
    if (!surveyTitle || !surveyTitle.value) {
        alert('الرجاء إدخال عنوان الاستبيان');
        return false;
    }
    
    if (!surveyDescription || !surveyDescription.value) {
        alert('الرجاء إدخال وصف الاستبيان');
        return false;
    }
    
    // Check if at least one question exists
    const questions = document.querySelectorAll('.survey-question');
    if (questions.length === 0) {
        alert('الرجاء إضافة سؤال واحد على الأقل');
        return false;
    }
    
    // Validate each question
    let isValid = true;
    
    questions.forEach((questionElement, index) => {
        const questionText = questionElement.querySelector('input[placeholder="أدخل نص السؤال هنا"]').value;
        
        if (!questionText) {
            alert(`الرجاء إدخال نص السؤال رقم ${index + 1}`);
            isValid = false;
            return;
        }
        
        // Validate options
        const options = questionElement.querySelectorAll('.option-item input');
        let hasEmptyOption = false;
        
        options.forEach((optionInput, optionIndex) => {
            if (!optionInput.value) {
                hasEmptyOption = true;
            }
        });
        
        if (hasEmptyOption) {
            alert(`الرجاء إدخال نص لجميع خيارات السؤال رقم ${index + 1}`);
            isValid = false;
            return;
        }
    });
    
    if (isValid) {
        // Store survey data
        window.surveyContent = getSurveyData();
    }
    
    return isValid;
}

// Preview survey
function previewSurvey() {
    const surveyData = getSurveyData();
    
    // Create preview HTML
    let previewHtml = `
        <div class="survey-preview">
            <h3>${surveyData.title}</h3>
            <p>${surveyData.description}</p>
            <div class="survey-questions">
    `;
    
    // Add questions
    surveyData.questions.forEach((question, index) => {
        previewHtml += `
            <div class="survey-question-preview">
                <div class="question-number">${index + 1}</div>
                <div class="question-text">${question.text}</div>
                <div class="question-options">
        `;
        
        // Add options
        question.options.forEach((option) => {
            previewHtml += `
                <div class="option-preview">
                    <input type="${question.type === 'multiple_choice' ? 'radio' : 'checkbox'}" name="q${index + 1}" id="${option.id}">
                    <label for="${option.id}">${option.text}</label>
                </div>
            `;
        });
        
        previewHtml += `
                </div>
            </div>
        `;
    });
    
    previewHtml += `
            </div>
        </div>
    `;
    
    // Display preview (in a real implementation, this would be a modal or a new tab)
    alert('سيتم عرض معاينة الاستبيان في النسخة النهائية');
    console.log('Survey Preview:', previewHtml);
}

// Export survey functionality
window.surveyCreator = {
    addNewQuestion,
    addNewOption,
    deleteQuestion,
    removeOption,
    getSurveyData,
    validateSurvey,
    previewSurvey
};
