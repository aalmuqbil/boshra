// Database functionality for Bushra website
// This file provides a simulated database layer for the MVP

// Initialize IndexedDB
function initDatabase() {
    console.log('Initializing database...');
    
    // Check if IndexedDB is supported
    if (!window.indexedDB) {
        console.error('Your browser doesn\'t support IndexedDB. Using local storage fallback.');
        initLocalStorageFallback();
        return;
    }
    
    // Open database connection
    const request = indexedDB.open('BushraDB', 1);
    
    // Handle database upgrade (first time or version change)
    request.onupgradeneeded = function(event) {
        const db = event.target.result;
        
        // Create object stores (tables)
        if (!db.objectStoreNames.contains('users')) {
            const usersStore = db.createObjectStore('users', { keyPath: 'id' });
            usersStore.createIndex('nationalId', 'nationalId', { unique: true });
        }
        
        if (!db.objectStoreNames.contains('campaigns')) {
            const campaignsStore = db.createObjectStore('campaigns', { keyPath: 'id', autoIncrement: true });
            campaignsStore.createIndex('advertiserId', 'advertiserId', { unique: false });
            campaignsStore.createIndex('status', 'status', { unique: false });
        }
        
        if (!db.objectStoreNames.contains('ads')) {
            const adsStore = db.createObjectStore('ads', { keyPath: 'id', autoIncrement: true });
            adsStore.createIndex('campaignId', 'campaignId', { unique: false });
            adsStore.createIndex('industry', 'industry', { unique: false });
        }
        
        if (!db.objectStoreNames.contains('surveys')) {
            const surveysStore = db.createObjectStore('surveys', { keyPath: 'id', autoIncrement: true });
            surveysStore.createIndex('campaignId', 'campaignId', { unique: false });
            surveysStore.createIndex('industry', 'industry', { unique: false });
        }
        
        if (!db.objectStoreNames.contains('transactions')) {
            const transactionsStore = db.createObjectStore('transactions', { keyPath: 'id', autoIncrement: true });
            transactionsStore.createIndex('userId', 'userId', { unique: false });
            transactionsStore.createIndex('date', 'date', { unique: false });
        }
        
        if (!db.objectStoreNames.contains('targeting')) {
            db.createObjectStore('targeting', { keyPath: 'id', autoIncrement: true });
        }
        
        console.log('Database schema created');
    };
    
    // Handle successful database open
    request.onsuccess = function(event) {
        const db = event.target.result;
        console.log('Database opened successfully');
        
        // Store database connection for later use
        window.bushraDB = db;
        
        // Load initial data if needed
        checkAndLoadInitialData(db);
    };
    
    // Handle database open error
    request.onerror = function(event) {
        console.error('Error opening database:', event.target.error);
        initLocalStorageFallback();
    };
}

// Fallback to localStorage if IndexedDB is not available
function initLocalStorageFallback() {
    console.log('Initializing localStorage fallback...');
    
    // Check if initial data is already loaded
    if (!localStorage.getItem('bushraDB_initialized')) {
        // Load initial data
        loadInitialDataToLocalStorage();
        localStorage.setItem('bushraDB_initialized', 'true');
    }
    
    // Create database API methods that use localStorage
    window.bushraDB = {
        transaction: function(storeNames, mode) {
            return {
                objectStore: function(storeName) {
                    return {
                        getAll: function() {
                            return {
                                onsuccess: function(callback) {
                                    const data = JSON.parse(localStorage.getItem(`bushraDB_${storeName}`) || '[]');
                                    callback({ target: { result: data } });
                                }
                            };
                        },
                        get: function(key) {
                            return {
                                onsuccess: function(callback) {
                                    const data = JSON.parse(localStorage.getItem(`bushraDB_${storeName}`) || '[]');
                                    const item = data.find(item => item.id === key);
                                    callback({ target: { result: item } });
                                }
                            };
                        },
                        add: function(item) {
                            return {
                                onsuccess: function(callback) {
                                    const data = JSON.parse(localStorage.getItem(`bushraDB_${storeName}`) || '[]');
                                    if (!item.id) {
                                        item.id = Date.now(); // Simple auto-increment
                                    }
                                    data.push(item);
                                    localStorage.setItem(`bushraDB_${storeName}`, JSON.stringify(data));
                                    callback();
                                }
                            };
                        },
                        put: function(item) {
                            return {
                                onsuccess: function(callback) {
                                    const data = JSON.parse(localStorage.getItem(`bushraDB_${storeName}`) || '[]');
                                    const index = data.findIndex(i => i.id === item.id);
                                    if (index !== -1) {
                                        data[index] = item;
                                    } else {
                                        if (!item.id) {
                                            item.id = Date.now(); // Simple auto-increment
                                        }
                                        data.push(item);
                                    }
                                    localStorage.setItem(`bushraDB_${storeName}`, JSON.stringify(data));
                                    callback();
                                }
                            };
                        },
                        delete: function(key) {
                            return {
                                onsuccess: function(callback) {
                                    const data = JSON.parse(localStorage.getItem(`bushraDB_${storeName}`) || '[]');
                                    const newData = data.filter(item => item.id !== key);
                                    localStorage.setItem(`bushraDB_${storeName}`, JSON.stringify(newData));
                                    callback();
                                }
                            };
                        },
                        index: function(indexName) {
                            return {
                                getAll: function() {
                                    return {
                                        onsuccess: function(callback) {
                                            const data = JSON.parse(localStorage.getItem(`bushraDB_${storeName}`) || '[]');
                                            callback({ target: { result: data } });
                                        }
                                    };
                                },
                                get: function(key) {
                                    return {
                                        onsuccess: function(callback) {
                                            const data = JSON.parse(localStorage.getItem(`bushraDB_${storeName}`) || '[]');
                                            const item = data.find(item => item[indexName] === key);
                                            callback({ target: { result: item } });
                                        }
                                    };
                                }
                            };
                        }
                    };
                }
            };
        }
    };
}

// Check if initial data needs to be loaded and load it if necessary
function checkAndLoadInitialData(db) {
    const transaction = db.transaction(['users'], 'readonly');
    const usersStore = transaction.objectStore('users');
    const countRequest = usersStore.count();
    
    countRequest.onsuccess = function() {
        if (countRequest.result === 0) {
            console.log('No data found, loading initial data...');
            loadInitialData(db);
        } else {
            console.log('Data already exists, skipping initial load');
        }
    };
    
    countRequest.onerror = function(event) {
        console.error('Error checking data:', event.target.error);
    };
}

// Load initial data into the database
function loadInitialData(db) {
    // Load users
    loadUsers(db);
    
    // Load campaigns
    loadCampaigns(db);
    
    // Load ads
    loadAds(db);
    
    // Load surveys
    loadSurveys(db);
    
    // Load transactions
    loadTransactions(db);
    
    // Load targeting data
    loadTargetingData(db);
    
    console.log('Initial data loaded successfully');
}

// Load initial data into localStorage
function loadInitialDataToLocalStorage() {
    // Sample data for users
    const users = [
        {
            id: 1,
            nationalId: '1234567890',
            name: 'محمد أحمد',
            email: 'mohammed@example.com',
            phone: '0501234567',
            city: 'الرياض',
            gender: 'male',
            age: 32,
            balance: 125.50,
            completedAds: 18,
            completedSurveys: 7,
            interests: ['تقنية', 'سيارات', 'سفر']
        },
        {
            id: 2,
            nationalId: '9876543210',
            name: 'سارة محمد',
            email: 'sarah@example.com',
            phone: '0559876543',
            city: 'جدة',
            gender: 'female',
            age: 28,
            balance: 87.25,
            completedAds: 12,
            completedSurveys: 5,
            interests: ['تسوق', 'سفر', 'طعام']
        }
    ];
    
    // Sample data for campaigns
    const campaigns = [
        {
            id: 1,
            name: 'اكتشف وجهات جديدة مع الخطوط السعودية',
            advertiserId: 1,
            industry: 'airlines',
            type: 'ad',
            status: 'active',
            startDate: '2025-04-01',
            endDate: '2025-05-01',
            budget: 10000,
            spent: 3500,
            userReward: 3.50,
            targeting: {
                ageMin: 25,
                ageMax: 55,
                gender: 'all',
                cities: ['الرياض', 'جدة', 'الدمام'],
                interests: ['سفر', 'سياحة']
            }
        },
        {
            id: 2,
            name: 'استبيان تجربة السفر',
            advertiserId: 1,
            industry: 'airlines',
            type: 'survey',
            status: 'active',
            startDate: '2025-03-15',
            endDate: '2025-04-15',
            budget: 15000,
            spent: 7500,
            userReward: 15.00,
            targeting: {
                ageMin: 21,
                ageMax: 60,
                gender: 'all',
                cities: ['all'],
                interests: ['سفر']
            }
        },
        {
            id: 3,
            name: 'خدمات الجوال المدفوعة مسبقاً',
            advertiserId: 2,
            industry: 'telecom',
            type: 'ad',
            status: 'pending',
            startDate: '2025-05-01',
            endDate: '2025-06-01',
            budget: 15000,
            spent: 0,
            userReward: 3.00,
            targeting: {
                ageMin: 18,
                ageMax: 35,
                gender: 'all',
                cities: ['all'],
                interests: ['تقنية', 'اتصالات']
            }
        }
    ];
    
    // Sample data for ads
    const ads = [
        {
            id: 1,
            campaignId: 1,
            title: 'اكتشف وجهات جديدة مع الخطوط السعودية',
            description: 'استمتع برحلات مميزة إلى أجمل الوجهات العالمية مع الخطوط السعودية',
            imageUrl: 'images/ads/saudia-ad.jpg',
            industry: 'airlines',
            reward: 3.50,
            duration: 30, // seconds
            clicks: 1250,
            impressions: 5000,
            completions: 950
        },
        {
            id: 2,
            campaignId: 3,
            title: 'خدمات الجوال المدفوعة مسبقاً',
            description: 'اشترك الآن في باقات STC المدفوعة مسبقاً واستمتع بمزايا حصرية',
            imageUrl: 'images/ads/stc-ad.jpg',
            industry: 'telecom',
            reward: 3.00,
            duration: 25, // seconds
            clicks: 0,
            impressions: 0,
            completions: 0
        }
    ];
    
    // Sample data for surveys
    const surveys = [
        {
            id: 1,
            campaignId: 2,
            title: 'استبيان تجربة السفر',
            description: 'شاركنا رأيك في تجربة السفر مع الخطوط السعودية',
            imageUrl: 'images/surveys/saudia-survey.jpg',
            industry: 'airlines',
            reward: 15.00,
            estimatedTime: 10, // minutes
            questions: [
                {
                    id: 1,
                    type: 'multiple_choice',
                    text: 'كم مرة تسافر سنوياً؟',
                    options: ['مرة واحدة', '2-3 مرات', '4-6 مرات', 'أكثر من 6 مرات']
                },
                {
                    id: 2,
                    type: 'rating',
                    text: 'كيف تقيم تجربتك مع الخطوط السعودية؟',
                    scale: 5
                },
                {
                    id: 3,
                    type: 'text',
                    text: 'ما هي اقتراحاتك لتحسين خدماتنا؟'
                }
            ],
            completions: 500
        }
    ];
    
    // Sample data for transactions
    const transactions = [
        {
            id: 1,
            userId: 1,
            type: 'ad_reward',
            amount: 3.50,
            date: '2025-04-10T14:30:00',
            description: 'مكافأة مشاهدة إعلان: اكتشف وجهات جديدة مع الخطوط السعودية',
            status: 'completed'
        },
        {
            id: 2,
            userId: 1,
            type: 'survey_reward',
            amount: 15.00,
            date: '2025-04-05T10:15:00',
            description: 'مكافأة إكمال استبيان: استبيان تجربة السفر',
            status: 'completed'
        },
        {
            id: 3,
            userId: 1,
            type: 'withdrawal',
            amount: -50.00,
            date: '2025-04-01T16:45:00',
            description: 'سحب إلى البطاقة المصرفية',
            status: 'completed'
        }
    ];
    
    // Sample targeting data
    const targeting = [
        {
            id: 1,
            type: 'cities',
            data: ['الرياض', 'جدة', 'مكة', 'المدينة', 'الدمام', 'الخبر', 'الطائف', 'تبوك', 'أبها', 'نجران', 'جازان', 'حائل', 'بريدة', 'عرعر', 'سكاكا', 'القريات']
        },
        {
            id: 2,
            type: 'interests',
            data: ['تقنية', 'سيارات', 'سفر', 'رياضة', 'طعام', 'تسوق', 'صحة', 'تعليم', 'ترفيه', 'أزياء', 'عقارات', 'مالية', 'سياحة', 'اتصالات']
        },
        {
            id: 3,
            type: 'demographics',
            data: {
                ageRanges: [
                    { id: 1, label: '13-17', count: 120000 },
                    { id: 2, label: '18-24', count: 450000 },
                    { id: 3, label: '25-34', count: 780000 },
                    { id: 4, label: '35-44', count: 650000 },
                    { id: 5, label: '45-54', count: 420000 },
                    { id: 6, label: '55-64', count: 280000 },
                    { id: 7, label: '65+', count: 150000 }
                ],
                genderDistribution: {
                    male: 1450000,
                    female: 1400000
                },
                cityDistribution: {
                    'الرياض': 850000,
                    'جدة': 650000,
                    'مكة': 350000,
                    'المدينة': 250000,
                    'الدمام': 300000,
                    'other': 450000
                }
            }
        }
    ];
    
    // Store data in localStorage
    localStorage.setItem('bushraDB_users', JSON.stringify(users));
    localStorage.setItem('bushraDB_campaigns', JSON.stringify(campaigns));
    localStorage.setItem('bushraDB_ads', JSON.stringify(ads));
    localStorage.setItem('bushraDB_surveys', JSON.stringify(surveys));
    localStorage.setItem('bushraDB_transactions', JSON.stringify(transactions));
    localStorage.setItem('bushraDB_targeting', JSON.stringify(targeting));
    
    console.log('Initial data loaded to localStorage');
}

// Load users into the database
function loadUsers(db) {
    const transaction = db.transaction(['users'], 'readwrite');
    const usersStore = transaction.objectStore('users');
    
    // Sample users
    const users = [
        {
            id: 1,
            nationalId: '1234567890',
            name: 'محمد أحمد',
            email: 'mohammed@example.com',
            phone: '0501234567',
            city: 'الرياض',
            gender: 'male',
            age: 32,
            balance: 125.50,
            completedAds: 18,
            completedSurveys: 7,
            interests: ['تقنية', 'سيارات', 'سفر']
        },
        {
            id: 2,
            nationalId: '9876543210',
            name: 'سارة محمد',
            email: 'sarah@example.com',
            phone: '0559876543',
            city: 'جدة',
            gender: 'female',
            age: 28,
            balance: 87.25,
            completedAds: 12,
            completedSurveys: 5,
            interests: ['تسوق', 'سفر', 'طعام']
        }
    ];
    
    // Add users to the store
    users.forEach(user => {
        usersStore.add(user);
    });
    
    transaction.oncomplete = function() {
        console.log('Users loaded successfully');
    };
    
    transaction.onerror = function(event) {
        console.error('Error loading users:', event.target.error);
    };
}

// Load campaigns into the database
function loadCampaigns(db) {
    const transaction = db.transaction(['campaigns'], 'readwrite');
    const campaignsStore = transaction.objectStore('campaigns');
    
    // Sample campaigns
    const campaigns = [
        {
            id: 1,
            name: 'اكتشف وجهات جديدة مع الخطوط السعودية',
            advertiserId: 1,
            industry: 'airlines',
            type: 'ad',
            status: 'active',
            startDate: '2025-04-01',
            endDate: '2025-05-01',
            budget: 10000,
            spent: 3500,
            userReward: 3.50,
            targeting: {
                ageMin: 25,
                ageMax: 55,
                gender: 'all',
                cities: ['الرياض', 'جدة', 'الدمام'],
                interests: ['سفر', 'سياحة']
            }
        },
        {
            id: 2,
            name: 'استبيان تجربة السفر',
            advertiserId: 1,
            industry: 'airlines',
            type: 'survey',
            status: 'active',
            startDate: '2025-03-15',
            endDate: '2025-04-15',
            budget: 15000,
            spent: 7500,
            userReward: 15.00,
            targeting: {
                ageMin: 21,
                ageMax: 60,
                gender: 'all',
                cities: ['all'],
                interests: ['سفر']
            }
        },
        {
            id: 3,
            name: 'خدمات الجوال المدفوعة مسبقاً',
            advertiserId: 2,
            industry: 'telecom',
            type: 'ad',
            status: 'pending',
            startDate: '2025-05-01',
            endDate: '2025-06-01',
            budget: 15000,
            spent: 0,
            userReward: 3.00,
            targeting: {
                ageMin: 18,
                ageMax: 35,
                gender: 'all',
                cities: ['all'],
                interests: ['تقنية', 'اتصالات']
            }
        }
    ];
    
    // Add campaigns to the store
    campaigns.forEach(campaign => {
        campaignsStore.add(campaign);
    });
    
    transaction.oncomplete = function() {
        console.log('Campaigns loaded successfully');
    };
    
    transaction.onerror = function(event) {
        console.error('Error loading campaigns:', event.target.error);
    };
}

// Load ads into the database
function loadAds(db) {
    const transaction = db.transaction(['ads'], 'readwrite');
    const adsStore = transaction.objectStore('ads');
    
    // Sample ads
    const ads = [
        {
            id: 1,
            campaignId: 1,
            title: 'اكتشف وجهات جديدة مع الخطوط السعودية',
            description: 'استمتع برحلات مميزة إلى أجمل الوجهات العالمية مع الخطوط السعودية',
            imageUrl: 'images/ads/saudia-ad.jpg',
            industry: 'airlines',
            reward: 3.50,
            duration: 30, // seconds
            clicks: 1250,
            impressions: 5000,
            completions: 950
        },
        {
            id: 2,
            campaignId: 3,
            title: 'خدمات الجوال المدفوعة مسبقاً',
            description: 'اشترك الآن في باقات STC المدفوعة مسبقاً واستمتع بمزايا حصرية',
            imageUrl: 'images/ads/stc-ad.jpg',
            industry: 'telecom',
            reward: 3.00,
            duration: 25, // seconds
            clicks: 0,
            impressions: 0,
            completions: 0
        }
    ];
    
    // Add ads to the store
    ads.forEach(ad => {
        adsStore.add(ad);
    });
    
    transaction.oncomplete = function() {
        console.log('Ads loaded successfully');
    };
    
    transaction.onerror = function(event) {
        console.error('Error loading ads:', event.target.error);
    };
}

// Load surveys into the database
function loadSurveys(db) {
    const transaction = db.transaction(['surveys'], 'readwrite');
    const surveysStore = transaction.objectStore('surveys');
    
    // Sample surveys
    const surveys = [
        {
            id: 1,
            campaignId: 2,
            title: 'استبيان تجربة السفر',
            description: 'شاركنا رأيك في تجربة السفر مع الخطوط السعودية',
            imageUrl: 'images/surveys/saudia-survey.jpg',
            industry: 'airlines',
            reward: 15.00,
            estimatedTime: 10, // minutes
            questions: [
                {
                    id: 1,
                    type: 'multiple_choice',
                    text: 'كم مرة تسافر سنوياً؟',
                    options: ['مرة واحدة', '2-3 مرات', '4-6 مرات', 'أكثر من 6 مرات']
                },
                {
                    id: 2,
                    type: 'rating',
                    text: 'كيف تقيم تجربتك مع الخطوط السعودية؟',
                    scale: 5
                },
                {
                    id: 3,
                    type: 'text',
                    text: 'ما هي اقتراحاتك لتحسين خدماتنا؟'
                }
            ],
            completions: 500
        }
    ];
    
    // Add surveys to the store
    surveys.forEach(survey => {
        surveysStore.add(survey);
    });
    
    transaction.oncomplete = function() {
        console.log('Surveys loaded successfully');
    };
    
    transaction.onerror = function(event) {
        console.error('Error loading surveys:', event.target.error);
    };
}

// Load transactions into the database
function loadTransactions(db) {
    const transaction = db.transaction(['transactions'], 'readwrite');
    const transactionsStore = transaction.objectStore('transactions');
    
    // Sample transactions
    const transactions = [
        {
            id: 1,
            userId: 1,
            type: 'ad_reward',
            amount: 3.50,
            date: '2025-04-10T14:30:00',
            description: 'مكافأة مشاهدة إعلان: اكتشف وجهات جديدة مع الخطوط السعودية',
            status: 'completed'
        },
        {
            id: 2,
            userId: 1,
            type: 'survey_reward',
            amount: 15.00,
            date: '2025-04-05T10:15:00',
            description: 'مكافأة إكمال استبيان: استبيان تجربة السفر',
            status: 'completed'
        },
        {
            id: 3,
            userId: 1,
            type: 'withdrawal',
            amount: -50.00,
            date: '2025-04-01T16:45:00',
            description: 'سحب إلى البطاقة المصرفية',
            status: 'completed'
        }
    ];
    
    // Add transactions to the store
    transactions.forEach(transaction => {
        transactionsStore.add(transaction);
    });
    
    transaction.oncomplete = function() {
        console.log('Transactions loaded successfully');
    };
    
    transaction.onerror = function(event) {
        console.error('Error loading transactions:', event.target.error);
    };
}

// Load targeting data into the database
function loadTargetingData(db) {
    const transaction = db.transaction(['targeting'], 'readwrite');
    const targetingStore = transaction.objectStore('targeting');
    
    // Sample targeting data
    const targeting = [
        {
            id: 1,
            type: 'cities',
            data: ['الرياض', 'جدة', 'مكة', 'المدينة', 'الدمام', 'الخبر', 'الطائف', 'تبوك', 'أبها', 'نجران', 'جازان', 'حائل', 'بريدة', 'عرعر', 'سكاكا', 'القريات']
        },
        {
            id: 2,
            type: 'interests',
            data: ['تقنية', 'سيارات', 'سفر', 'رياضة', 'طعام', 'تسوق', 'صحة', 'تعليم', 'ترفيه', 'أزياء', 'عقارات', 'مالية', 'سياحة', 'اتصالات']
        },
        {
            id: 3,
            type: 'demographics',
            data: {
                ageRanges: [
                    { id: 1, label: '13-17', count: 120000 },
                    { id: 2, label: '18-24', count: 450000 },
                    { id: 3, label: '25-34', count: 780000 },
                    { id: 4, label: '35-44', count: 650000 },
                    { id: 5, label: '45-54', count: 420000 },
                    { id: 6, label: '55-64', count: 280000 },
                    { id: 7, label: '65+', count: 150000 }
                ],
                genderDistribution: {
                    male: 1450000,
                    female: 1400000
                },
                cityDistribution: {
                    'الرياض': 850000,
                    'جدة': 650000,
                    'مكة': 350000,
                    'المدينة': 250000,
                    'الدمام': 300000,
                    'other': 450000
                }
            }
        }
    ];
    
    // Add targeting data to the store
    targeting.forEach(item => {
        targetingStore.add(item);
    });
    
    transaction.oncomplete = function() {
        console.log('Targeting data loaded successfully');
    };
    
    transaction.onerror = function(event) {
        console.error('Error loading targeting data:', event.target.error);
    };
}

// Database service functions

// Get user by national ID
function getUserByNationalId(nationalId, callback) {
    if (!window.bushraDB) {
        console.error('Database not initialized');
        callback(null);
        return;
    }
    
    const transaction = window.bushraDB.transaction(['users'], 'readonly');
    const usersStore = transaction.objectStore('users');
    const index = usersStore.index('nationalId');
    const request = index.get(nationalId);
    
    request.onsuccess = function(event) {
        callback(event.target.result);
    };
    
    request.onerror = function(event) {
        console.error('Error getting user:', event.target.error);
        callback(null);
    };
}

// Get user transactions
function getUserTransactions(userId, callback) {
    if (!window.bushraDB) {
        console.error('Database not initialized');
        callback([]);
        return;
    }
    
    const transaction = window.bushraDB.transaction(['transactions'], 'readonly');
    const transactionsStore = transaction.objectStore('transactions');
    const index = transactionsStore.index('userId');
    const request = index.getAll(userId);
    
    request.onsuccess = function(event) {
        callback(event.target.result);
    };
    
    request.onerror = function(event) {
        console.error('Error getting transactions:', event.target.error);
        callback([]);
    };
}

// Get available ads for user
function getAvailableAdsForUser(user, callback) {
    if (!window.bushraDB) {
        console.error('Database not initialized');
        callback([]);
        return;
    }
    
    const transaction = window.bushraDB.transaction(['ads', 'campaigns'], 'readonly');
    const adsStore = transaction.objectStore('ads');
    const campaignsStore = transaction.objectStore('campaigns');
    
    const adsRequest = adsStore.getAll();
    
    adsRequest.onsuccess = function(event) {
        const allAds = event.target.result;
        const availableAds = [];
        
        // Process each ad
        let processedCount = 0;
        
        if (allAds.length === 0) {
            callback([]);
            return;
        }
        
        allAds.forEach(ad => {
            // Get the campaign for this ad
            const campaignRequest = campaignsStore.get(ad.campaignId);
            
            campaignRequest.onsuccess = function(event) {
                const campaign = event.target.result;
                
                // Check if campaign is active and user matches targeting
                if (campaign && campaign.status === 'active' && userMatchesTargeting(user, campaign.targeting)) {
                    availableAds.push({
                        ...ad,
                        campaign: campaign
                    });
                }
                
                processedCount++;
                
                // If all ads have been processed, return the available ones
                if (processedCount === allAds.length) {
                    callback(availableAds);
                }
            };
            
            campaignRequest.onerror = function(event) {
                console.error('Error getting campaign:', event.target.error);
                processedCount++;
                
                // If all ads have been processed, return the available ones
                if (processedCount === allAds.length) {
                    callback(availableAds);
                }
            };
        });
    };
    
    adsRequest.onerror = function(event) {
        console.error('Error getting ads:', event.target.error);
        callback([]);
    };
}

// Get available surveys for user
function getAvailableSurveysForUser(user, callback) {
    if (!window.bushraDB) {
        console.error('Database not initialized');
        callback([]);
        return;
    }
    
    const transaction = window.bushraDB.transaction(['surveys', 'campaigns'], 'readonly');
    const surveysStore = transaction.objectStore('surveys');
    const campaignsStore = transaction.objectStore('campaigns');
    
    const surveysRequest = surveysStore.getAll();
    
    surveysRequest.onsuccess = function(event) {
        const allSurveys = event.target.result;
        const availableSurveys = [];
        
        // Process each survey
        let processedCount = 0;
        
        if (allSurveys.length === 0) {
            callback([]);
            return;
        }
        
        allSurveys.forEach(survey => {
            // Get the campaign for this survey
            const campaignRequest = campaignsStore.get(survey.campaignId);
            
            campaignRequest.onsuccess = function(event) {
                const campaign = event.target.result;
                
                // Check if campaign is active and user matches targeting
                if (campaign && campaign.status === 'active' && userMatchesTargeting(user, campaign.targeting)) {
                    availableSurveys.push({
                        ...survey,
                        campaign: campaign
                    });
                }
                
                processedCount++;
                
                // If all surveys have been processed, return the available ones
                if (processedCount === allSurveys.length) {
                    callback(availableSurveys);
                }
            };
            
            campaignRequest.onerror = function(event) {
                console.error('Error getting campaign:', event.target.error);
                processedCount++;
                
                // If all surveys have been processed, return the available ones
                if (processedCount === allSurveys.length) {
                    callback(availableSurveys);
                }
            };
        });
    };
    
    surveysRequest.onerror = function(event) {
        console.error('Error getting surveys:', event.target.error);
        callback([]);
    };
}

// Check if user matches targeting criteria
function userMatchesTargeting(user, targeting) {
    // Check age
    if (user.age < targeting.ageMin || user.age > targeting.ageMax) {
        return false;
    }
    
    // Check gender
    if (targeting.gender !== 'all' && user.gender !== targeting.gender) {
        return false;
    }
    
    // Check city
    if (targeting.cities[0] !== 'all' && !targeting.cities.includes(user.city)) {
        return false;
    }
    
    // Check interests (at least one match)
    if (targeting.interests.length > 0) {
        const hasMatchingInterest = user.interests.some(interest => targeting.interests.includes(interest));
        if (!hasMatchingInterest) {
            return false;
        }
    }
    
    return true;
}

// Record ad view
function recordAdView(userId, adId, callback) {
    if (!window.bushraDB) {
        console.error('Database not initialized');
        callback(false);
        return;
    }
    
    // Get the ad
    const adTransaction = window.bushraDB.transaction(['ads'], 'readonly');
    const adsStore = adTransaction.objectStore('ads');
    const adRequest = adsStore.get(adId);
    
    adRequest.onsuccess = function(event) {
        const ad = event.target.result;
        
        if (!ad) {
            console.error('Ad not found');
            callback(false);
            return;
        }
        
        // Update ad stats
        const updateTransaction = window.bushraDB.transaction(['ads'], 'readwrite');
        const updateAdsStore = updateTransaction.objectStore('ads');
        
        ad.impressions++;
        ad.completions++;
        
        const updateRequest = updateAdsStore.put(ad);
        
        updateRequest.onsuccess = function() {
            // Record transaction
            const transactionObj = {
                userId: userId,
                type: 'ad_reward',
                amount: ad.reward,
                date: new Date().toISOString(),
                description: `مكافأة مشاهدة إعلان: ${ad.title}`,
                status: 'completed'
            };
            
            const transactionTransaction = window.bushraDB.transaction(['transactions'], 'readwrite');
            const transactionsStore = transactionTransaction.objectStore('transactions');
            const transactionRequest = transactionsStore.add(transactionObj);
            
            transactionRequest.onsuccess = function() {
                // Update user balance
                const userTransaction = window.bushraDB.transaction(['users'], 'readwrite');
                const usersStore = userTransaction.objectStore('users');
                const userRequest = usersStore.get(userId);
                
                userRequest.onsuccess = function(event) {
                    const user = event.target.result;
                    
                    if (!user) {
                        console.error('User not found');
                        callback(false);
                        return;
                    }
                    
                    user.balance += ad.reward;
                    user.completedAds++;
                    
                    const updateUserRequest = usersStore.put(user);
                    
                    updateUserRequest.onsuccess = function() {
                        callback(true);
                    };
                    
                    updateUserRequest.onerror = function(event) {
                        console.error('Error updating user:', event.target.error);
                        callback(false);
                    };
                };
                
                userRequest.onerror = function(event) {
                    console.error('Error getting user:', event.target.error);
                    callback(false);
                };
            };
            
            transactionRequest.onerror = function(event) {
                console.error('Error recording transaction:', event.target.error);
                callback(false);
            };
        };
        
        updateRequest.onerror = function(event) {
            console.error('Error updating ad:', event.target.error);
            callback(false);
        };
    };
    
    adRequest.onerror = function(event) {
        console.error('Error getting ad:', event.target.error);
        callback(false);
    };
}

// Record survey completion
function recordSurveyCompletion(userId, surveyId, answers, callback) {
    if (!window.bushraDB) {
        console.error('Database not initialized');
        callback(false);
        return;
    }
    
    // Get the survey
    const surveyTransaction = window.bushraDB.transaction(['surveys'], 'readonly');
    const surveysStore = surveyTransaction.objectStore('surveys');
    const surveyRequest = surveysStore.get(surveyId);
    
    surveyRequest.onsuccess = function(event) {
        const survey = event.target.result;
        
        if (!survey) {
            console.error('Survey not found');
            callback(false);
            return;
        }
        
        // Update survey stats
        const updateTransaction = window.bushraDB.transaction(['surveys'], 'readwrite');
        const updateSurveysStore = updateTransaction.objectStore('surveys');
        
        survey.completions++;
        
        const updateRequest = updateSurveysStore.put(survey);
        
        updateRequest.onsuccess = function() {
            // Record transaction
            const transactionObj = {
                userId: userId,
                type: 'survey_reward',
                amount: survey.reward,
                date: new Date().toISOString(),
                description: `مكافأة إكمال استبيان: ${survey.title}`,
                status: 'completed'
            };
            
            const transactionTransaction = window.bushraDB.transaction(['transactions'], 'readwrite');
            const transactionsStore = transactionTransaction.objectStore('transactions');
            const transactionRequest = transactionsStore.add(transactionObj);
            
            transactionRequest.onsuccess = function() {
                // Update user balance
                const userTransaction = window.bushraDB.transaction(['users'], 'readwrite');
                const usersStore = userTransaction.objectStore('users');
                const userRequest = usersStore.get(userId);
                
                userRequest.onsuccess = function(event) {
                    const user = event.target.result;
                    
                    if (!user) {
                        console.error('User not found');
                        callback(false);
                        return;
                    }
                    
                    user.balance += survey.reward;
                    user.completedSurveys++;
                    
                    const updateUserRequest = usersStore.put(user);
                    
                    updateUserRequest.onsuccess = function() {
                        callback(true);
                    };
                    
                    updateUserRequest.onerror = function(event) {
                        console.error('Error updating user:', event.target.error);
                        callback(false);
                    };
                };
                
                userRequest.onerror = function(event) {
                    console.error('Error getting user:', event.target.error);
                    callback(false);
                };
            };
            
            transactionRequest.onerror = function(event) {
                console.error('Error recording transaction:', event.target.error);
                callback(false);
            };
        };
        
        updateRequest.onerror = function(event) {
            console.error('Error updating survey:', event.target.error);
            callback(false);
        };
    };
    
    surveyRequest.onerror = function(event) {
        console.error('Error getting survey:', event.target.error);
        callback(false);
    };
}

// Create new campaign
function createCampaign(campaign, callback) {
    if (!window.bushraDB) {
        console.error('Database not initialized');
        callback(null);
        return;
    }
    
    const transaction = window.bushraDB.transaction(['campaigns'], 'readwrite');
    const campaignsStore = transaction.objectStore('campaigns');
    
    // Set default values
    campaign.status = 'pending';
    campaign.spent = 0;
    
    const request = campaignsStore.add(campaign);
    
    request.onsuccess = function(event) {
        const campaignId = event.target.result;
        
        // Get the created campaign
        const getRequest = campaignsStore.get(campaignId);
        
        getRequest.onsuccess = function(event) {
            callback(event.target.result);
        };
        
        getRequest.onerror = function(event) {
            console.error('Error getting created campaign:', event.target.error);
            callback(null);
        };
    };
    
    request.onerror = function(event) {
        console.error('Error creating campaign:', event.target.error);
        callback(null);
    };
}

// Get campaigns by advertiser
function getCampaignsByAdvertiser(advertiserId, callback) {
    if (!window.bushraDB) {
        console.error('Database not initialized');
        callback([]);
        return;
    }
    
    const transaction = window.bushraDB.transaction(['campaigns'], 'readonly');
    const campaignsStore = transaction.objectStore('campaigns');
    const index = campaignsStore.index('advertiserId');
    const request = index.getAll(advertiserId);
    
    request.onsuccess = function(event) {
        callback(event.target.result);
    };
    
    request.onerror = function(event) {
        console.error('Error getting campaigns:', event.target.error);
        callback([]);
    };
}

// Get campaigns by status
function getCampaignsByStatus(status, callback) {
    if (!window.bushraDB) {
        console.error('Database not initialized');
        callback([]);
        return;
    }
    
    const transaction = window.bushraDB.transaction(['campaigns'], 'readonly');
    const campaignsStore = transaction.objectStore('campaigns');
    const index = campaignsStore.index('status');
    const request = index.getAll(status);
    
    request.onsuccess = function(event) {
        callback(event.target.result);
    };
    
    request.onerror = function(event) {
        console.error('Error getting campaigns:', event.target.error);
        callback([]);
    };
}

// Update campaign status
function updateCampaignStatus(campaignId, status, callback) {
    if (!window.bushraDB) {
        console.error('Database not initialized');
        callback(false);
        return;
    }
    
    const transaction = window.bushraDB.transaction(['campaigns'], 'readwrite');
    const campaignsStore = transaction.objectStore('campaigns');
    const request = campaignsStore.get(campaignId);
    
    request.onsuccess = function(event) {
        const campaign = event.target.result;
        
        if (!campaign) {
            console.error('Campaign not found');
            callback(false);
            return;
        }
        
        campaign.status = status;
        
        const updateRequest = campaignsStore.put(campaign);
        
        updateRequest.onsuccess = function() {
            callback(true);
        };
        
        updateRequest.onerror = function(event) {
            console.error('Error updating campaign:', event.target.error);
            callback(false);
        };
    };
    
    request.onerror = function(event) {
        console.error('Error getting campaign:', event.target.error);
        callback(false);
    };
}

// Get targeting data
function getTargetingData(callback) {
    if (!window.bushraDB) {
        console.error('Database not initialized');
        callback(null);
        return;
    }
    
    const transaction = window.bushraDB.transaction(['targeting'], 'readonly');
    const targetingStore = transaction.objectStore('targeting');
    const request = targetingStore.getAll();
    
    request.onsuccess = function(event) {
        const targetingData = event.target.result;
        const result = {
            cities: [],
            interests: [],
            demographics: null
        };
        
        targetingData.forEach(item => {
            if (item.type === 'cities') {
                result.cities = item.data;
            } else if (item.type === 'interests') {
                result.interests = item.data;
            } else if (item.type === 'demographics') {
                result.demographics = item.data;
            }
        });
        
        callback(result);
    };
    
    request.onerror = function(event) {
        console.error('Error getting targeting data:', event.target.error);
        callback(null);
    };
}

// Export database functions
window.bushraDatabase = {
    init: initDatabase,
    getUserByNationalId,
    getUserTransactions,
    getAvailableAdsForUser,
    getAvailableSurveysForUser,
    recordAdView,
    recordSurveyCompletion,
    createCampaign,
    getCampaignsByAdvertiser,
    getCampaignsByStatus,
    updateCampaignStatus,
    getTargetingData
};
