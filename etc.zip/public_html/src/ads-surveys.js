// Personalized ads and surveys functionality for Bushra website
// This script handles loading and displaying personalized content for logged-in users

// Store references to DOM elements and data
let userAds = [];
let userSurveys = [];
let allAds = [];
let allSurveys = [];
let currentUser = null;

// Initialize the ads and surveys functionality
function initAdsAndSurveys() {
  // Check if user is logged in
  currentUser = window.bushraAuth ? window.bushraAuth.getCurrentUser() : null;
  
  // Load ads and surveys data
  loadAdsAndSurveys();
  
  // Set up event listeners for filters if they exist
  setupFilterListeners();
  
  // Update UI based on login status
  updateUIBasedOnLoginStatus();
}

// Load ads and surveys data
async function loadAdsAndSurveys() {
  try {
    // Fetch ads data
    const adsResponse = await fetch('../data/ads.json');
    const adsData = await adsResponse.json();
    allAds = adsData.ads;
    
    // If user is logged in, get their personalized ads
    if (currentUser && currentUser.loggedIn) {
      const userAdIds = adsData.user_ads[currentUser.id] || [];
      userAds = allAds.filter(ad => userAdIds.includes(ad.id));
      
      // Display personalized content
      displayPersonalizedContent();
    } else {
      // Display general content for non-logged in users
      displayGeneralContent();
    }
    
    console.log('Ads and surveys data loaded successfully');
  } catch (error) {
    console.error('Error loading ads and surveys data:', error);
    // Display general content as fallback
    displayGeneralContent();
  }
}

// Display personalized content for logged-in users
function displayPersonalizedContent() {
  const contentContainer = document.getElementById('content-container');
  if (!contentContainer) return;
  
  // Clear existing content
  contentContainer.innerHTML = '';
  
  // Add welcome message with user's name
  const welcomeSection = document.createElement('div');
  welcomeSection.className = 'welcome-section';
  welcomeSection.innerHTML = `
    <h2>مرحباً ${currentUser.name}!</h2>
    <p>إليك الإعلانات والاستبيانات المخصصة لك بناءً على اهتماماتك.</p>
  `;
  contentContainer.appendChild(welcomeSection);
  
  // Display user's personalized ads
  if (userAds.length > 0) {
    const adsSection = document.createElement('div');
    adsSection.className = 'content-section';
    adsSection.innerHTML = `
      <h3 class="section-title"><i class="fas fa-ad"></i> الإعلانات المخصصة لك</h3>
      <div class="content-grid" id="personalized-ads-grid"></div>
    `;
    contentContainer.appendChild(adsSection);
    
    const adsGrid = adsSection.querySelector('#personalized-ads-grid');
    userAds.forEach(ad => {
      adsGrid.appendChild(createAdCard(ad));
    });
  }
  
  // Display recommended content
  const recommendedSection = document.createElement('div');
  recommendedSection.className = 'content-section';
  recommendedSection.innerHTML = `
    <h3 class="section-title"><i class="fas fa-star"></i> محتوى قد يهمك</h3>
    <div class="content-grid" id="recommended-content-grid"></div>
  `;
  contentContainer.appendChild(recommendedSection);
  
  const recommendedGrid = recommendedSection.querySelector('#recommended-content-grid');
  
  // Get some random ads that aren't in the user's personalized list
  const otherAds = allAds.filter(ad => !userAds.some(userAd => userAd.id === ad.id));
  const recommendedAds = otherAds.sort(() => 0.5 - Math.random()).slice(0, 4);
  
  recommendedAds.forEach(ad => {
    recommendedGrid.appendChild(createAdCard(ad));
  });
}

// Display general content for non-logged in users
function displayGeneralContent() {
  const contentContainer = document.getElementById('content-container');
  if (!contentContainer) return;
  
  // Clear existing content
  contentContainer.innerHTML = '';
  
  // Display featured content
  const featuredSection = document.createElement('div');
  featuredSection.className = 'featured-section';
  featuredSection.innerHTML = `
    <div class="featured-card">
      <img src="https://via.placeholder.com/600x400/4e54c8/ffffff" alt="Featured content" class="featured-image">
      <div class="featured-content">
        <span class="featured-badge">مميز</span>
        <h2 class="featured-title">سجل الآن واكسب المزيد</h2>
        <p class="featured-description">سجل في منصة بشرى واحصل على إعلانات واستبيانات مخصصة لك تناسب اهتماماتك. اكسب المزيد من المال من خلال مشاهدة الإعلانات والمشاركة في الاستبيانات.</p>
        <div class="featured-meta">
          <span class="featured-reward">+50 ريال</span>
          <span class="featured-time"><i class="far fa-clock"></i> مكافأة التسجيل</span>
        </div>
        <a href="login.html" class="btn btn-primary">سجل الآن</a>
      </div>
    </div>
  `;
  contentContainer.appendChild(featuredSection);
  
  // Display categories
  const categories = ['الطيران', 'الاتصالات', 'حكومي', 'سيارات'];
  
  categories.forEach(category => {
    const categoryAds = allAds.filter(ad => ad.category === category).slice(0, 2);
    if (categoryAds.length > 0) {
      const categorySection = document.createElement('div');
      categorySection.className = 'content-section';
      categorySection.innerHTML = `
        <h3 class="section-title">${category}</h3>
        <div class="content-grid" id="${category}-grid"></div>
      `;
      contentContainer.appendChild(categorySection);
      
      const categoryGrid = categorySection.querySelector(`#${category}-grid`);
      categoryAds.forEach(ad => {
        categoryGrid.appendChild(createAdCard(ad));
      });
    }
  });
}

// Create an ad card element
function createAdCard(ad) {
  const card = document.createElement('div');
  card.className = 'content-card';
  card.innerHTML = `
    <img src="https://via.placeholder.com/300x180/${getRandomColor()}/ffffff" alt="${ad.title}" class="content-image">
    <span class="content-badge">${ad.category === 'استبيان' ? 'استبيان' : 'إعلان'}</span>
    <div class="content-details">
      <h3 class="content-title">${ad.title}</h3>
      <p class="content-description">${ad.description}</p>
      <div class="content-meta">
        <div class="content-reward">${ad.reward} <span>ريال</span></div>
        <div class="content-time"><i class="far fa-clock"></i> ${ad.duration} ثانية</div>
      </div>
      <button class="btn btn-primary btn-block view-ad-btn" data-ad-id="${ad.id}">مشاهدة الإعلان</button>
    </div>
  `;
  
  // Add event listener to the view button
  const viewButton = card.querySelector('.view-ad-btn');
  viewButton.addEventListener('click', () => viewAd(ad.id));
  
  return card;
}

// Get a random color for placeholder images
function getRandomColor() {
  const colors = ['4e54c8', '3498db', '2ecc71', 'e74c3c', 'f39c12', '9b59b6'];
  return colors[Math.floor(Math.random() * colors.length)];
}

// Handle viewing an ad
function viewAd(adId) {
  // If user is not logged in, redirect to login page
  if (!currentUser || !currentUser.loggedIn) {
    window.location.href = 'login.html';
    return;
  }
  
  // Otherwise, show the ad
  console.log(`Viewing ad with ID: ${adId}`);
  // Implement ad viewing functionality here
}

// Set up event listeners for filters
function setupFilterListeners() {
  const contentTypeFilter = document.getElementById('content-type-filter');
  const industryFilter = document.getElementById('industry-filter');
  const sortByFilter = document.getElementById('sort-by-filter');
  
  // Add event listeners if filters exist
  if (contentTypeFilter) {
    contentTypeFilter.addEventListener('change', applyFilters);
  }
  
  if (industryFilter) {
    industryFilter.addEventListener('change', applyFilters);
  }
  
  if (sortByFilter) {
    sortByFilter.addEventListener('change', applyFilters);
  }
}

// Apply filters to content
function applyFilters() {
  // This would be implemented if we were keeping the filters
  // Since we're removing them as per user request, this is just a placeholder
}

// Update UI based on login status
function updateUIBasedOnLoginStatus() {
  // Update header UI
  const loginButton = document.querySelector('.login-button');
  const userMenu = document.querySelector('.user-menu');
  
  if (currentUser && currentUser.loggedIn) {
    // User is logged in
    if (loginButton) loginButton.style.display = 'none';
    if (userMenu) {
      userMenu.style.display = 'flex';
      const userNameElement = userMenu.querySelector('.user-name');
      if (userNameElement) {
        userNameElement.textContent = currentUser.name;
      }
    }
    
    // Show wallet balance if available
    const walletBalance = document.getElementById('wallet-balance');
    if (walletBalance) {
      // In a real implementation, we would fetch the user's actual wallet balance
      walletBalance.textContent = '450.75 ريال';
    }
  } else {
    // User is not logged in
    if (loginButton) loginButton.style.display = 'block';
    if (userMenu) userMenu.style.display = 'none';
  }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', initAdsAndSurveys);

// Export functions for use in other scripts
window.bushraAdsAndSurveys = {
  initAdsAndSurveys,
  loadAdsAndSurveys,
  displayPersonalizedContent,
  displayGeneralContent
};
